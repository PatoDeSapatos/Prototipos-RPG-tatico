class_name PaperSkeletonGizmoPlugin
extends EditorNode3DGizmoPlugin

func _init():
	_setup_materials()

func _setup_materials() -> void:
	create_material("paper_gizmo", Color(1, 1, 1, 0.9))
	
	var icon_svg := FileAccess.get_file_as_string("uid://papersklbico")
	var icon_img := Image.new()
	icon_img.load_svg_from_string(icon_svg, 3.0)
	icon_img.fix_alpha_edges()
	var icon_tex := ImageTexture.create_from_image(icon_img)
	
	create_icon_material("skeleton_icon", icon_tex)

func _get_gizmo_name() -> String:
	return "PaperSkeleton"

func _has_gizmo(node: Node3D) -> bool:
	return node is PaperSkeleton

func _redraw(gizmo: EditorNode3DGizmo) -> void:
	gizmo.clear()
	var skel: PaperSkeleton = gizmo.get_node_3d()
	var bounds := _calculate_bounds(skel)
	
	if bounds and not bounds.size.is_equal_approx(Vector3.ZERO):
		_create_gizmo_visualization(gizmo, bounds)
	else:
		_create_gizmo_billboard(gizmo)

func _calculate_bounds(skel: PaperSkeleton) -> AABB:
	var aabb := AABB()
	var first := true
	
	for r: Node in skel._renderables:
		var mi: MeshInstance3D = null
		var apply_skin: bool = false
		if r is PaperPolygon2D:
			mi = (r as PaperPolygon2D)._mesh_instance_3d
		else:
			mi = (r as PaperSprite2D)._mesh_instance_3d
			apply_skin = true
		if not mi: continue
		
		var local_aabb := _skinned_aabb_in_skeleton_space(mi, skel) if apply_skin else mi.get_aabb()
		
		if first:
			aabb = local_aabb
			first = false
		else:
			aabb = aabb.merge(local_aabb)
	
	return aabb

func _skinned_aabb_in_skeleton_space(mi: MeshInstance3D, skel: PaperSkeleton) -> AABB:
	var src := mi.get_aabb()
	if src.size.is_equal_approx(Vector3.ZERO): return src
	
	var skin := mi.skin
	if not skin or not skin.get_bind_count(): return src
	
	var corners := _get_aabb_corners(src)
	var out_aabb := AABB()
	var first := true
	
	for i: int in skin.get_bind_count():
		var bone_idx := skin.get_bind_bone(i)
		var inverse_bind: Transform3D = skin.get_bind_pose(i)
		var bone_global: Transform3D = skel.get_bone_global_rest(bone_idx)
		
		var to_skeleton_local := bone_global * inverse_bind
		for c: Vector3 in corners:
			var p := to_skeleton_local * c
			if first:
				out_aabb = AABB(p, Vector3.ZERO)
				first = false
			else:
				out_aabb = out_aabb.expand(p)
	return out_aabb

func _get_transformed_aabb(mesh_instance: MeshInstance3D) -> AABB:
	var mesh_aabb := mesh_instance.get_aabb()
	var corners := _get_aabb_corners(mesh_aabb)
	
	return _create_aabb_from_corners(corners)

func _get_aabb_corners(aabb: AABB) -> PackedVector3Array:
	var p := aabb.position
	var s := aabb.size
	var x2 := p.x + s.x
	var y2 := p.y + s.y
	var z2 := p.z + s.z
	
	return PackedVector3Array([
		p,
		Vector3( x2, p.y, p.z),
		Vector3(p.x,  y2, p.z),
		Vector3( x2,  y2, p.z),
		Vector3(p.x, p.y,  z2),
		Vector3( x2, p.y,  z2),
		Vector3(p.x,  y2,  z2),
		Vector3( x2,  y2,  z2),
	])

func _create_aabb_from_corners(corners: PackedVector3Array) -> AABB:
	if corners.is_empty():
		return AABB()
	
	var aabb := AABB(corners[0], Vector3.ZERO)
	for i: int in range(1, corners.size()):
		aabb = aabb.expand(corners[i])
	return aabb

func _create_gizmo_visualization(gizmo: EditorNode3DGizmo, aabb: AABB) -> void:
	aabb = aabb.grow(0.05)  # Expand slightly
	var material := get_material("paper_gizmo", gizmo)
	
	var lines := _create_boundary_lines(aabb)
	var collision_mesh := _create_collision_mesh(aabb)
	
	gizmo.add_lines(lines, material)
	gizmo.add_collision_triangles(collision_mesh.generate_triangle_mesh())

func _create_gizmo_billboard(gizmo: EditorNode3DGizmo) -> void:
	var icon_material := get_material("skeleton_icon", gizmo)
	gizmo.add_unscaled_billboard(icon_material, 0.03)

func _create_boundary_lines(aabb: AABB) -> PackedVector3Array:
	var p := aabb.position
	var s := aabb.size
	
	var x2 := p.x + s.x
	var y2 := p.y + s.y
	var z2 := p.z + s.z
	
	# Define corners
	var c: PackedVector3Array = [
		p,                      # 0
		Vector3( x2, p.y, p.z), # 1
		Vector3( x2, p.y,  z2), # 2
		Vector3(p.x, p.y,  z2), # 3
		Vector3(p.x,  y2, p.z), # 4
		Vector3( x2,  y2, p.z), # 5
		Vector3( x2,  y2,  z2), # 6
		Vector3(p.x,  y2,  z2), # 7
	]
	
	return PackedVector3Array([
		# Bottom square
		c[0], c[1], c[1], c[2], c[2], c[3], c[3], c[0],
		# Top square
		c[4], c[5], c[5], c[6], c[6], c[7], c[7], c[4],
		# Vertical lines
		c[0], c[4], c[1], c[5], c[2], c[6], c[3], c[7],
	])

func _create_collision_mesh(aabb: AABB) -> ImmediateMesh:
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	
	_add_face_vertices(mesh, aabb)
	
	mesh.surface_end()
	return mesh

func _add_face_vertices(mesh: ImmediateMesh, aabb: AABB) -> void:
	var pos := aabb.position
	var size := aabb.size
	
	var x := Vector3(size.x,    0.0,    0.0)
	var y := Vector3(   0.0, size.y,    0.0)
	var z := Vector3(   0.0,    0.0, size.z)
	
	# Front face
	_add_quad_vertices(mesh, pos,     x, y)
	# Back face
	_add_quad_vertices(mesh, pos + z, x, y)
	# Left face
	_add_quad_vertices(mesh, pos,     y, z)
	# Right face
	_add_quad_vertices(mesh, pos + x, y, z)
	# Top face
	_add_quad_vertices(mesh, pos + y, x, z)
	# Bottom face
	_add_quad_vertices(mesh, pos,     x, z)

func _add_quad_vertices(mesh: ImmediateMesh, start: Vector3, u: Vector3, v: Vector3) -> void:
	var p1 := start
	var p2 := p1 + u
	var p3 := p2 + v
	var p4 := p1 + v
	
	mesh.surface_add_vertex(p1)
	mesh.surface_add_vertex(p2)
	mesh.surface_add_vertex(p3)
	mesh.surface_add_vertex(p1)
	mesh.surface_add_vertex(p3)
	mesh.surface_add_vertex(p4)
