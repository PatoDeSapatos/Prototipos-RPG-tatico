@tool
extends EditorInspectorPlugin

class DisplayEntryProperty extends EditorProperty:
	var option: OptionButton
	var btn_save: Button
	var btn_add: Button
	var btn_rename: Button
	var btn_remove: Button
	var btn_up: Button
	var btn_down: Button
	var rename_dialog: ConfirmationDialog
	var rename_line: LineEdit
	
	func _init() -> void:
		PaperConstants._display_entry_property_editor = self
		name = &"DisplayEntryProperty"
		var vbox := VBoxContainer.new()
		add_child(vbox)
		add_focusable(vbox)
		
		var option_row := HBoxContainer.new()
		vbox.add_child(option_row)
		
		option = OptionButton.new()
		option.size_flags_horizontal = SIZE_EXPAND_FILL
		option.item_selected.connect(_on_selected)
		option.allow_reselect = true
		option_row.add_child(option)
		
		var button_row := HBoxContainer.new()
		vbox.add_child(button_row)
		
		btn_save   = _create_and_add_button(option_row, &"Save",     "Save Entry",      _on_save,      0.5, SIZE_SHRINK_END)
		btn_add    = _create_and_add_button(button_row, &"Add",      "Add Entry",       _on_add           )
		btn_rename = _create_and_add_button(button_row, &"Rename",   "Rename Entry",    _on_rename        )
		btn_remove = _create_and_add_button(button_row, &"Remove",   "Remove Entry",    _on_remove        )
		btn_up     = _create_and_add_button(button_row, &"MoveUp",   "Move Entry Up",   _on_move_up,   1.5)
		btn_down   = _create_and_add_button(button_row, &"MoveDown", "Move Entry Down", _on_move_down, 1.5)
		
		_setup_rename_dialog()
	
	func _enter_tree() -> void:
		_connect_undo_manager()
	
	func _exit_tree() -> void:
		_disconnect_undo_manager()
	
	static func _create_and_add_button(button_parent: Control, icon_name: StringName, tooltip: String, callback: Callable, stretch := 1.0, size_flag := Control.SIZE_EXPAND_FILL) -> Button:
		var btn := _create_button(icon_name, tooltip, callback, stretch, size_flag)
		button_parent.add_child(btn)
		return btn
	
	static func _create_button(icon_name: StringName, tooltip: String, callback: Callable, stretch := 1.0, size_flag := Control.SIZE_EXPAND_FILL) -> Button:
		var btn := Button.new()
		btn.icon = EditorInterface.get_base_control().get_theme_icon(icon_name, &"EditorIcons")
		btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		btn.tooltip_text = tooltip
		btn.pressed.connect(callback)
		btn.size_flags_stretch_ratio = stretch
		btn.size_flags_horizontal = size_flag
		return btn
	
	func _setup_rename_dialog() -> void:
		rename_dialog = ConfirmationDialog.new()
		rename_dialog.title = "Rename Display Entry"
		rename_dialog.get_ok_button().text = "Rename"
		rename_dialog.confirmed.connect(_on_rename_confirmed)
		
		rename_line = LineEdit.new()
		rename_line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rename_dialog.add_child(rename_line)
		
		EditorInterface.get_base_control().add_child(rename_dialog)
	
	static func _get_undo_redo() -> EditorUndoRedoManager:
		return EditorInterface.get_editor_undo_redo()
	
	static func _get_renderable_type(obj: Object) -> int:
		return PaperPolygon2D._TYPE if (obj is PaperPolygon2D) else PaperSprite2D._TYPE
	
	var _ur_connected := false
	
	func _connect_undo_manager() -> void:
		if _ur_connected: return
		var ur := _get_undo_redo()
		if not ur: return
		ur.version_changed.connect(_on_undo_redo_changed, CONNECT_DEFERRED)
		_ur_connected = true
	
	func _disconnect_undo_manager() -> void:
		if not _ur_connected: return
		var ur := _get_undo_redo()
		if not ur: return
		ur.version_changed.disconnect(_on_undo_redo_changed)
		_ur_connected = false
	
	func _on_undo_redo_changed() -> void:
		var obj := get_edited_object()
		if not obj: return
		obj.notify_property_list_changed()
		_update_property()
	
	static func _snapshot_meta(obj: Object) -> Dictionary:
		return {
			"data":  (obj._display_entry_data as Dictionary).duplicate(true),
			"order": (obj._display_entry_order as Array).duplicate(),
			"value": obj.get_display_entry()
		}
	
	static func _snapshot_props(obj: Object) -> Array:
		return PaperConstants._capture_display_entry_data(obj, _get_renderable_type(obj))
	
	static func _add_ops(ur: EditorUndoRedoManager, obj: Object, snap: Dictionary, props: Array, is_do: bool, apply_props: bool) -> void:
		if is_do:
			ur.add_do_property(obj, &"_display_entry_data", snap.data)
			ur.add_do_property(obj, &"_display_entry_order", snap.order)
			if apply_props:
				ur.add_do_method(obj, &"set_display_entry", snap.value)
				ur.add_do_method(PaperConstants, &"apply_display_entry", obj, _get_renderable_type(obj), props)
			else:
				ur.add_do_property(obj, &"_display_entry_value", snap.value)
		else:
			ur.add_undo_property(obj, &"_display_entry_data", snap.data)
			ur.add_undo_property(obj, &"_display_entry_order", snap.order)
			if apply_props:
				ur.add_undo_method(obj, &"set_display_entry", snap.value)
				ur.add_undo_method(PaperConstants, &"apply_display_entry", obj, _get_renderable_type(obj), props)
			else:
				ur.add_undo_property(obj, &"_display_entry_value", snap.value)
	
	static func _commit(obj: Object, action_name: String, before_meta: Dictionary, before_props: Array, after_meta: Dictionary, after_props: Array, apply_props: bool) -> void:
		var ur := _get_undo_redo()
		if not ur: return
		
		var meta_same := before_meta == after_meta
		var props_same := before_props == after_props
		
		if meta_same and (not apply_props or props_same): return
		
		ur.create_action(action_name)
		_add_ops(ur, obj, after_meta, after_props, true, apply_props)
		_add_ops(ur, obj, before_meta, before_props, false, apply_props)
		ur.commit_action(false)
	
	func _update_property() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var order: Array[StringName] = obj._display_entry_order
		var current: StringName = obj.get_display_entry()
		var has_entries := not order.is_empty()
		
		if has_entries:
			option.disabled = false
			_populate_options(order, current)
		else:
			option.clear()
			option.add_item("No Entries")
			option.set_item_metadata(0, &"")
			option.select(0)
			option.disabled = true
		
		var dirty: bool = has_entries and obj.is_display_entry_dirty()
		
		_update_button_states(order.size(), option.selected, dirty)
	
	func _populate_options(order: Array[StringName], current: StringName) -> void:
		option.clear()
		var sel := 0
		for i: int in order.size():
			option.add_item(String(order[i]))
			option.set_item_metadata(i, order[i])
			if order[i] == current: sel = i
		option.select(sel)
	
	func _update_button_states(count: int, select_idx: int, dirty: bool) -> void:
		btn_remove.disabled = count <= 0
		btn_rename.disabled = count <= 0
		btn_up.disabled = (count <= 1) or (select_idx <= 0)
		btn_down.disabled = (count <= 1) or (select_idx >= count - 1)
		_update_button_save(dirty)
	
	func _update_button_save(dirty: bool) -> void:
		btn_save.disabled = not dirty
	
	func _on_selected(idx: int) -> void:
		if option.disabled: return
		var meta := option.get_item_metadata(idx) as StringName
		if meta == &"": return
		_change_display_entry(get_edited_object(), meta)
	
	func _change_display_entry(obj: Object, new_value: StringName) -> void:
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		var before_props := _snapshot_props(obj)
		obj.set_display_entry(new_value)
		var after_meta := _snapshot_meta(obj)
		var after_props := _snapshot_props(obj)
		
		_commit(obj, "Change Display Entry", before_meta, before_props, after_meta, after_props, true)
		update_property()
	
	func _on_save() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		obj.save_display_entry()
		var after_meta := _snapshot_meta(obj)
		
		_commit(obj, "Save Display Entry", before_meta, [], after_meta, [], false)
		update_property()
	
	func _on_add() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		var before_props := _snapshot_props(obj)
		obj.add_display_entry()
		var after_meta := _snapshot_meta(obj)
		var after_props := _snapshot_props(obj)
		
		_commit(obj, "Add Display Entry", before_meta, before_props, after_meta, after_props, true)
		update_property()
	
	func _on_rename() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var current: StringName = obj.get_display_entry()
		rename_line.text = String(current)
		rename_dialog.popup_centered()
	
	func _on_rename_confirmed() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		var old_name: StringName = obj.get_display_entry()
		var new_name: StringName = StringName(rename_line.text.strip_edges())
		if obj.rename_display_entry(old_name, new_name):
			var after_meta := _snapshot_meta(obj)
			_commit(obj, "Rename Display Entry", before_meta, [], after_meta, [], false)
			update_property()
	
	func _on_remove() -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		var before_props := _snapshot_props(obj)
		obj.remove_display_entry(obj.get_display_entry())
		var after_meta := _snapshot_meta(obj)
		var after_props := _snapshot_props(obj)
		
		_commit(obj, "Remove Display Entry", before_meta, before_props, after_meta, after_props, true)
		update_property()
	
	func _on_move_up() -> void: _move_entry(-1)
	
	func _on_move_down() -> void: _move_entry(1)
	
	func _move_entry(direction: int) -> void:
		var obj := get_edited_object()
		if not obj: return
		
		var before_meta := _snapshot_meta(obj)
		obj.move_display_entry(obj.get_display_entry(), direction)
		var after_meta := _snapshot_meta(obj)
		
		_commit(obj, "Move Display Entry", before_meta, [], after_meta, [], false)
		update_property()

func _can_handle(object: Object) -> bool:
	return object is PaperSprite2D or object is PaperPolygon2D

func _parse_property(_object: Object, _type: Variant.Type, name: String, _hint: PropertyHint, _hint_text: String, _usage: PropertyUsageFlags, _wide: bool) -> bool:
	if name == "display_entry": 
		add_property_editor(name, DisplayEntryProperty.new())
		return true
	return false
