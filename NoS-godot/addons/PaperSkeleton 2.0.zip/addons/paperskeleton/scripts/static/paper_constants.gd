@tool
extends Object
class_name PaperConstants

## Utility class for storing certain PaperSkeleton constants, static values, and static functions.
## This class is mainly used internally, so you [i]probably[/i] won't need to access anything in here yourself.

#region Project Setting / Default Shader
## [ProjectSettings] key used to override the default Paper shader (expects a UID string).
const DEFAULT_SHADER_PS_KEY := "paper_skeleton/default_shader"

## UID fallback used when the [ProjectSettings] entry is missing or empty.
const DEFAULT_SHADER_UID := "uid://shdrbrbnprps"

static var _default_shader_cache: Shader = null
static var _default_shader_uid_cache: String = ""
#endregion

#region Shader Parameter Schema
## Uniform names for shaders build with [PaperSkeleton] in mind.
## Used alongside [enum PaperParam].
const PAPER_PARAMS: Array[StringName] = [
	&"PAPER_ALBEDO",             # PaperParam.TEXTURE
	&"PAPER_ALBEDO_EXISTS",      # PaperParam.TEXTURE_EXISTS
	&"PAPER_ALBEDO_FLIP",        # PaperParam.FLIP_TEXTURE
	&"PAPER_ALBEDO_FLIP_EXISTS", # PaperParam.FLIP_TEXTURE_EXISTS
	&"PAPER_COLOR",              # PaperParam.COLOR
	&"PAPER_UV_SCALE",           # PaperParam.SCALE
	&"PAPER_UV_OFFSET",          # PaperParam.OFFSET
	&"PAPER_UV_ROTATION",        # PaperParam.ROTATION
	&"PAPER_UV_MASK",            # PaperParam.MASK
	&"PAPER_USE_UV_MASK",        # PaperParam.USE_MASK
]

static var _PAPER_PARAM_TO_INDEX: Dictionary[StringName, int] = {}

## Indices pointing to shader uniform names within [constant PAPER_PARAMS].
## [br][br]
## Can also be used to manually update stale shader uniforms with
## [method PaperPolygon2D.update_material_paper_param]/[method PaperSprite2D.update_material_paper_param].
enum PaperParam {
	TEXTURE,             ## [Texture2D] - &"PAPER_ALBEDO":[br]　The renderable's texture.
	TEXTURE_EXISTS,      ## [bool] - &"PAPER_ALBEDO_EXISTS":[br]　Whether or not the renderable's texture has been set.
	FLIP_TEXTURE,        ## [Texture2D] - &"PAPER_ALBEDO_FLIP":[br]　The renderable's optional "flip" texture.
	FLIP_TEXTURE_EXISTS, ## [bool] - &"PAPER_ALBEDO_FLIP_EXISTS":[br]　Whether or not the renderable's "flip" texture has been set.
	COLOR,               ## [Color] - &"PAPER_COLOR":[br]　Modulates the texture.
	SCALE,               ## [Vector2] - &"PAPER_UV_SCALE":[br]　Scales the texture's UVs.
	OFFSET,              ## [Vector2] - &"PAPER_UV_OFFSET":[br]　Offsets the texture's UVs.
	ROTATION,            ## [float] - &"PAPER_UV_ROTATION":[br]　Rotates the texture's UVs.
	MASK,                ## [Vector4] - &"PAPER_UV_MASK":[br]　Masks off certain parts of the texture.
	USE_MASK             ## [bool] - &"PAPER_USE_UV_MASK":[br]　Whether or not the mask should be used.
}

## Renderable kind for polymorphic API.
enum RenderableType {
	POLYGON, ## [PaperPolygon2D]
	SPRITE   ## [PaperSprite2D]
}

static func _is_polygon_type(type: RenderableType) -> bool: return type == RenderableType.POLYGON

## Per-renderable mesh slots [PaperSkeleton] manages.
enum RenderSlot { 
	BASE,   ## [member PaperSkeleton.material]
	BORDER, ## [member PaperSkeleton.border_material]
	GROUP   ## [member PaperSkeleton.group_material]
}

## Internal call-selector enum for [member _RENDERABLE_CALLS].
enum CallType {
	ACTIVE_PM,           ## get_active_material()
	GET_SHADER_OVR,      ## shader_material_override getter
	SET_SHADER_OVR,      ## shader_material_override setter
	GET_EFFECTIVE_PM,    ## _effective_paper_material getter
	SET_EFFECTIVE_PM,    ## _effective_paper_material setter
	MESH_INST,           ## _mesh_instance_3d getter
	MAT_PARAM_UPDATE,    ## _update_material_param_at_pass()
	MAT_STRUCT_UPDATE,   ## _on_mat_pass_structure_changed()
	REBULD_SHADER_CHAIN, ## _rebuild_shader_chain_from()
	GET_SHADER_PASS      ## _shader_material_at_pass()
}

## [enum PaperParam]s used to update values relevant to a renderable's main texture.
const TEX_MAIN_PARAMS: PackedByteArray = [PaperParam.TEXTURE, PaperParam.TEXTURE_EXISTS]
## [enum PaperParam]s used to update values relevant to a renderable's flip texture.
const TEX_FLIP_PARAMS: PackedByteArray = [PaperParam.FLIP_TEXTURE, PaperParam.FLIP_TEXTURE_EXISTS]
## [enum PaperParam]s used to update values relevant to a renderable's main & flip texture.
const TEX_ALL_PARAMS: PackedByteArray = TEX_MAIN_PARAMS + TEX_FLIP_PARAMS
## [enum PaperParam]s relevant to a [PaperSprite2D]'s region and nested [AtlasTexture]s.
const REGION_PARAMS: PackedByteArray = [PaperParam.OFFSET, PaperParam.MASK]
## [enum PaperParam]s relevant to [member Sprite2D.flip_h]/[member Sprite2D.flip_v] (scale + offset).
const UV_FLIP_PARAMS: PackedByteArray = [PaperParam.SCALE, PaperParam.OFFSET]

## All the parameters that [const TEX_ALL_PARAMS] points to.
const TEX_PARAM_NAMES: Array[StringName] = [
	PaperConstants.PAPER_PARAMS[PaperConstants.TEX_ALL_PARAMS[0]],
	PaperConstants.PAPER_PARAMS[PaperConstants.TEX_ALL_PARAMS[1]],
	PaperConstants.PAPER_PARAMS[PaperConstants.TEX_ALL_PARAMS[2]],
	PaperConstants.PAPER_PARAMS[PaperConstants.TEX_ALL_PARAMS[3]]
]

#endregion

#region Override Mode
## Enum used in [member PaperPolygon2D.override_mode] and [member PaperSprite2D.override_mode]
enum OverrideMode {
	## Uses proprietary [PaperMaterial]s for override. Recommended for general use cases.
	## To reduce overhead, [ShaderMaterial] overrides are not saved in the scene when set to this mode.
	PAPER_MATERIAL,
	## Uses [ShaderMaterial]s for override.
	## Meant for more advanced usage, as any changes (including modifications to textures) will apply
	## to every other mesh using it. Recommended for static parts of rigs not subject to texture changes.
	SHADER_MATERIAL
}
#endregion

#region Uniform Type Enum
## Shader uniform types for material parameter overrides.
enum UniformType {
	TEXTURE, ## [Texture]
	BOOL,    ## [bool]
	INT,     ## [int]
	FLOAT,   ## [float]
	VEC2,    ## [Vector2]
	VEC3,    ## [Vector3]
	VEC4,    ## [Vector4]
	COLOR,   ## [Color]
	IVEC2,   ## [Vector2i]
	IVEC3,   ## [Vector3i]
	IVEC4,   ## [Vector4i]
	BVEC2,   ## [int] (bit-packed: bit0=x, bit1=y)
	BVEC3,   ## [int] (bit-packed: bit0=x, bit1=y, bit2=z)
	BVEC4,   ## [int] (bit-packed: bit0=x, bit1=y, bit2=z, bit3=w)
	MAT2,    ## [Transform2D]
	MAT3,    ## [Basis]
	MAT4,    ## [Transform3D]
}

## Mapping of [enum UniformType] entries to their array equivalents.
const TYPE_TO_ARRAY_TYPE: PackedByteArray = [
	TYPE_ARRAY,                ## UniformType.TEXTURE
	TYPE_ARRAY,                ## UniformType.BOOL
	TYPE_PACKED_INT32_ARRAY,   ## UniformType.INT
	TYPE_PACKED_FLOAT32_ARRAY, ## UniformType.FLOAT
	TYPE_PACKED_VECTOR2_ARRAY, ## UniformType.VEC2
	TYPE_PACKED_VECTOR3_ARRAY, ## UniformType.VEC3
	TYPE_PACKED_VECTOR4_ARRAY, ## UniformType.VEC4
	TYPE_PACKED_COLOR_ARRAY,   ## UniformType.COLOR
	TYPE_ARRAY,                ## UniformType.IVEC2
	TYPE_ARRAY,                ## UniformType.IVEC3
	TYPE_ARRAY,                ## UniformType.IVEC4
	TYPE_PACKED_BYTE_ARRAY,    ## UniformType.BVEC2
	TYPE_PACKED_BYTE_ARRAY,    ## UniformType.BVEC3
	TYPE_PACKED_BYTE_ARRAY,    ## UniformType.BVEC4
	TYPE_ARRAY,                ## UniformType.MAT2
	TYPE_ARRAY,                ## UniformType.MAT3
	TYPE_ARRAY,                ## UniformType.MAT4
]
#endregion

#region Process Priorities
## Enum used to determine the process priority of certain classes.
## Largely used for billboarding updates, as a means to make sure the transform is only updated once per frame
## while not updating with stale values.
enum ProcessPriority {
	SKELETON = 1619,
	CAM_WATCHER = 1618,
	VPC_BUS = 1617
}
#endregion

#region Material Parameter Overrides
## Root material parameter override label.
const MAT_PARAM_OVERRIDE_PATH_ROOT := "material_parameter_override_"
## Property suffix used for variable storage entries.
const MAT_PARAM_OVERRIDE_PATH_VAL := "value"
## Property suffix used for name storage entries.
const MAT_PARAM_OVERRIDE_PATH_NAME := "name"
## Property suffix used for type storage entries.
const MAT_PARAM_OVERRIDE_PATH_TYPE := "type"
## Property suffix used for instance-uniform toggle entries.
const MAT_PARAM_OVERRIDE_PATH_INSTANCE := "instance"
## Property suffix used for instance-uniform toggle entries.
const MAT_PARAM_OVERRIDE_PATH_ARRAY := "array"
## Maximum number of material parameter overrides supported.[br]
## (If you're allocating more than 256 material parameter overrides on a single renderable, you're probably doing something wrong.)
const OVERRIDE_PARAM_MAX := 256
#endregion

#region Packed Renderable Calls
## Internal packed call-table used to reduce branching and keep hot-path logic minimal.
static var _RENDERABLE_CALLS: Array[Callable] = [
	# ACTIVE_PM - PaperPolygon2D
	func(p: PaperPolygon2D) -> PaperMaterial: return p.get_active_material(), # BASE
	func(p: PaperPolygon2D) -> PaperMaterial: return p.get_active_border_material(), # BORDER
	func(p: PaperPolygon2D) -> PaperMaterial: return p.get_active_group_material(), # GROUP
	# ACTIVE_PM - PaperSprite2D
	func(s: PaperSprite2D) -> PaperMaterial: return s.get_active_material(), # BASE
	func(s: PaperSprite2D) -> PaperMaterial: return s.get_active_border_material(), # BORDER
	func(s: PaperSprite2D) -> PaperMaterial: return s.get_active_group_material(), # GROUP
	
	# GET_SHADER_OVR - PaperPolygon2D
	func(p: PaperPolygon2D) -> ShaderMaterial: return p.shader_material_override, # BASE
	func(p: PaperPolygon2D) -> ShaderMaterial: return p.border_shader_material_override, # BORDER
	func(p: PaperPolygon2D) -> ShaderMaterial: return p.group_shader_material_override, # GROUP
	# GET_SHADER_OVR - PaperSprite2D
	func(s: PaperSprite2D) -> ShaderMaterial: return s.shader_material_override, # BASE
	func(s: PaperSprite2D) -> ShaderMaterial: return s.border_shader_material_override, # BORDER
	func(s: PaperSprite2D) -> ShaderMaterial: return s.group_shader_material_override, # GROUP
	
	# SET_SHADER_OVR - PaperPolygon2D
	func(p: PaperPolygon2D, m: ShaderMaterial) -> void: p.set_shader_material_override(m), # BASE
	func(p: PaperPolygon2D, m: ShaderMaterial) -> void: p.set_border_shader_material_override(m), # BORDER
	func(p: PaperPolygon2D, m: ShaderMaterial) -> void: p.set_group_shader_material_override(m), # GROUP
	# SET_SHADER_OVR - PaperSprite2D
	func(s: PaperSprite2D, m: ShaderMaterial) -> void: s.set_shader_material_override(m), # BASE
	func(s: PaperSprite2D, m: ShaderMaterial) -> void: s.set_border_shader_material_override(m), # BORDER
	func(s: PaperSprite2D, m: ShaderMaterial) -> void: s.set_group_shader_material_override(m), # GROUP
	
	# GET_EFFECTIVE_PM - PaperPolygon2D
	func(p: PaperPolygon2D) -> PaperMaterial: return p._effective_paper_material, # BASE
	func(p: PaperPolygon2D) -> PaperMaterial: return p._effective_border_paper_material, # BORDER
	func(p: PaperPolygon2D) -> PaperMaterial: return p._effective_group_paper_material, # GROUP
	# GET_EFFECTIVE_PM - PaperSprite2D
	func(s: PaperSprite2D) -> PaperMaterial: return s._effective_paper_material, # BASE
	func(s: PaperSprite2D) -> PaperMaterial: return s._effective_border_paper_material, # BORDER
	func(s: PaperSprite2D) -> PaperMaterial: return s._effective_group_paper_material, # GROUP
	
	# SET_EFFECTIVE_PM - PaperPolygon2D
	func(p: PaperPolygon2D, m: PaperMaterial) -> void: p._effective_paper_material = m, # BASE
	func(p: PaperPolygon2D, m: PaperMaterial) -> void: p._effective_border_paper_material = m, # BORDER
	func(p: PaperPolygon2D, m: PaperMaterial) -> void: p._effective_group_paper_material = m, # GROUP
	# SET_EFFECTIVE_PM - PaperSprite2D
	func(s: PaperSprite2D, m: PaperMaterial) -> void: s._effective_paper_material = m, # BASE
	func(s: PaperSprite2D, m: PaperMaterial) -> void: s._effective_border_paper_material = m, # BORDER
	func(s: PaperSprite2D, m: PaperMaterial) -> void: s._effective_group_paper_material = m, # GROUP
	
	# MESH_INST - PaperPolygon2D
	func(p: PaperPolygon2D) -> MeshInstance3D: return p._mesh_instance_3d, # BASE
	func(p: PaperPolygon2D) -> MeshInstance3D: return p._border_mesh_instance_3d, # BORDER
	func(p: PaperPolygon2D) -> MeshInstance3D: return p._group_mesh_instance_3d, # GROUP
	# MESH_INST - PaperSprite2D
	func(s: PaperSprite2D) -> MeshInstance3D: return s._mesh_instance_3d, # BASE
	func(s: PaperSprite2D) -> MeshInstance3D: return s._border_mesh_instance_3d, # BORDER
	func(s: PaperSprite2D) -> MeshInstance3D: return s._group_mesh_instance_3d, # GROUP
	
	# MAT_PARAM_UPDATE - PaperPolygon2D
	func(p: PaperPolygon2D) -> Callable: return p._update_material_param_at_pass, # BASE
	func(p: PaperPolygon2D) -> Callable: return p._update_border_material_param_at_pass, # BORDER
	func(p: PaperPolygon2D) -> Callable: return p._update_group_material_param_at_pass, # GROUP
	# MAT_PARAM_UPDATE - PaperSprite2D
	func(s: PaperSprite2D) -> Callable: return s._update_material_param_at_pass, # BASE
	func(s: PaperSprite2D) -> Callable: return s._update_border_material_param_at_pass, # BORDER
	func(s: PaperSprite2D) -> Callable: return s._update_group_material_param_at_pass, # GROUP
	
	# MAT_STRUCT_UPDATE - PaperPolygon2D
	func(p: PaperPolygon2D) -> Callable: return p._on_mat_pass_structure_changed, # BASE
	func(p: PaperPolygon2D) -> Callable: return p._on_border_mat_pass_structure_changed, # BORDER
	func(p: PaperPolygon2D) -> Callable: return p._on_group_mat_pass_structure_changed, # GROUP
	# MAT_STRUCT_UPDATE - PaperSprite2D
	func(s: PaperSprite2D) -> Callable: return s._on_mat_pass_structure_changed, # BASE
	func(s: PaperSprite2D) -> Callable: return s._on_border_mat_pass_structure_changed, # BORDER
	func(s: PaperSprite2D) -> Callable: return s._on_group_mat_pass_structure_changed, # GROUP
	
	# REBULD_SHADER_CHAIN - PaperPolygon2D
	func(p: PaperPolygon2D, i: int) -> void: p._rebuild_shader_chain_from(i), # BASE
	func(p: PaperPolygon2D, i: int) -> void: p._rebuild_border_shader_chain_from(i), # BORDER
	func(p: PaperPolygon2D, i: int) -> void: p._rebuild_group_shader_chain_from(i), # GROUP
	# REBULD_SHADER_CHAIN - PaperSprite2D
	func(s: PaperSprite2D, i: int) -> void: s._rebuild_shader_chain_from(i), # BASE
	func(s: PaperSprite2D, i: int) -> void: s._rebuild_border_shader_chain_from(i), # BORDER
	func(s: PaperSprite2D, i: int) -> void: s._rebuild_group_shader_chain_from(i), # GROUP
	
	# GET_SHADER_PASS - PaperPolygon2D
	func(p: PaperPolygon2D, i: int) -> ShaderMaterial: return p._shader_material_at_pass(i), # BASE
	func(p: PaperPolygon2D, i: int) -> ShaderMaterial: return p._border_shader_material_at_pass(i), # BORDER
	func(p: PaperPolygon2D, i: int) -> ShaderMaterial: return p._group_shader_material_at_pass(i), # GROUP
	# GET_SHADER_PASS - PaperSprite2D
	func(s: PaperSprite2D, i: int) -> ShaderMaterial: return s._shader_material_at_pass(i), # BASE
	func(s: PaperSprite2D, i: int) -> ShaderMaterial: return s._border_shader_material_at_pass(i), # BORDER
	func(s: PaperSprite2D, i: int) -> ShaderMaterial: return s._group_shader_material_at_pass(i), # GROUP
]:
	set(value): return
#endregion

#region Static Initialization
static func _static_init() -> void:
	if not ProjectSettings.settings_changed.is_connected(_process_settings_change):
		ProjectSettings.settings_changed.connect(_process_settings_change, CONNECT_DEFERRED)
	for i: int in PAPER_PARAMS.size():
		_PAPER_PARAM_TO_INDEX[PAPER_PARAMS[i]] = i
	_RENDERABLE_CALLS.make_read_only()
	_ARRAY_DEFAULTS.make_read_only()
	for i: int in UniformType.size():
		if TYPE_TO_ARRAY_TYPE[i] == TYPE_ARRAY:
			(_ARRAY_DEFAULTS[i] as Array).make_read_only()
#endregion

#region Default Shader Lookup
## Returns the default shader, fetching and caching it if needed.
static func get_default_shader() -> Shader:
	return _default_shader_cache if _default_shader_cache else _retrieve_and_cache_default_shader()

static func _retrieve_and_cache_default_shader() -> Shader:
	_default_shader_cache = _retrieve_default_shader()
	return _default_shader_cache

static func _retrieve_default_shader(uid: String = _retrieve_default_shader_uid()) -> Shader:
	_default_shader_uid_cache = uid
	if uid:
		var res := load(uid)
		if res is Shader:
			return res
		else:
			if ResourceUID.has_id(ResourceUID.text_to_id(uid)):
				push_error("PaperSkeleton: Could not load shader from '%s' path." % ResourceUID.uid_to_path(uid))
			else:
				push_error("PaperSkeleton: Could not load shader from invalid UID '%s'." % uid)
	elif ResourceUID.has_id(ResourceUID.text_to_id(DEFAULT_SHADER_UID)):
		return load(DEFAULT_SHADER_UID)
	
	push_error("PaperSkeleton: ProjectSetting '%s' is empty, with no fallback shader." % DEFAULT_SHADER_PS_KEY)
	return null

## Returns the UID string stored in [ProjectSettings] for [constant DEFAULT_SHADER_PS_KEY] (or empty string).
static func _retrieve_default_shader_uid() -> String:
	if ProjectSettings.has_setting(DEFAULT_SHADER_PS_KEY):
		var value = ProjectSettings.get_setting(DEFAULT_SHADER_PS_KEY)
		if value is String: return value
	return ""

## Listener for [ProjectSettings] changes that updates the cached shader if the UID changed.
static func _process_settings_change() -> void:
	var shader_uid := _retrieve_default_shader_uid()
	if _default_shader_uid_cache != shader_uid:
		_default_shader_cache = _retrieve_default_shader(shader_uid)
#endregion

#region Material Parameter Overrides
## Builds inspector property entries for material parameter overrides for a given size.
static func get_material_parameter_override_properties(mpo_size: int, override_types: PackedByteArray) -> Array[Dictionary]:
	var props: Array[Dictionary] = []
	props.resize(mpo_size * 6)
	var prop_idx: int = 0
	for i: int in mpo_size:
		var prefix: String = MAT_PARAM_OVERRIDE_PATH_ROOT + ("%d_" % i)
		props[prop_idx] = {
			"name": "Override #%d" % i,
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_SUBGROUP,
			"hint_string": prefix,
		}
		prop_idx += 1
		props[prop_idx] = {
			"name": prefix + MAT_PARAM_OVERRIDE_PATH_TYPE,
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_ENUM,
			"hint_string": "Texture,Bool,Int,Float,Vector2,Vector3,Vector4,Color,Vector2i,Vector3i,Vector4i,BVec2,BVec3,BVec4,Mat2,Mat3,Mat4",
		}
		prop_idx += 1
		props[prop_idx] = {
			"name": prefix + MAT_PARAM_OVERRIDE_PATH_NAME,
			"type": TYPE_STRING_NAME,
			"usage": PROPERTY_USAGE_EDITOR,
		}
		prop_idx += 1
		props[prop_idx] = {
			"name": prefix + MAT_PARAM_OVERRIDE_PATH_INSTANCE,
			"type": TYPE_BOOL,
			"usage": PROPERTY_USAGE_EDITOR,
		}
		prop_idx += 1
		props[prop_idx] = {
			"name": prefix + MAT_PARAM_OVERRIDE_PATH_ARRAY,
			"type": TYPE_BOOL,
			"usage": PROPERTY_USAGE_EDITOR,
		}
		prop_idx += 1
		props[prop_idx] = _build_value_property(prefix, _mpo_uniform_type(override_types[i]), _mpo_is_array(override_types[i]))
		prop_idx += 1
	return props

## Builds the value property dictionary based on uniform type.
static func _build_value_property(prefix: String, utype: UniformType, is_array: bool = false) -> Dictionary:
	var prop_name := prefix + MAT_PARAM_OVERRIDE_PATH_VAL
	const UNIFORM_TO_PROPERTY: Array[Dictionary] = [
		{   # UniformType.TEXTURE
			"type": TYPE_OBJECT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "Texture2D,Texture2DArray,Texture3D,Cubemap,CubemapArray,ExternalTexture",
		},{ # UniformType.BOOL
			"type": TYPE_BOOL,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.INT
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.FLOAT
			"type": TYPE_FLOAT,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.VEC2
			"type": TYPE_VECTOR2,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.VEC3
			"type": TYPE_VECTOR3,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.VEC4
			"type": TYPE_VECTOR4,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.COLOR
			"type": TYPE_COLOR,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.IVEC2
			"type": TYPE_VECTOR2I,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.IVEC3
			"type": TYPE_VECTOR3I,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.IVEC4
			"type": TYPE_VECTOR4I,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.BVEC2
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_FLAGS,
			"hint_string": "x,y"
		},{ # UniformType.BVEC3
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_FLAGS,
			"hint_string": "x,y,z"
		},{ # UniformType.BVEC4
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_FLAGS,
			"hint_string": "x,y,z,w"
		},{ # UniformType.MAT2
			"type": TYPE_TRANSFORM2D,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.MAT3
			"type": TYPE_BASIS,
			"usage": PROPERTY_USAGE_EDITOR
		},{ # UniformType.MAT4
			"type": TYPE_TRANSFORM3D,
			"usage": PROPERTY_USAGE_EDITOR
		}
	]
	
	var prop := UNIFORM_TO_PROPERTY[utype].duplicate()
	prop.name = prop_name
	
	# Handle array types
	if is_array:
		var elem_type = prop.type
		
		# Fall back to regular Array with TYPE_HINT_STRING
		var elem_hint = prop.get("hint", -1)
		var elem_hint_string = prop.get("hint_string", "")
		
		prop.type = TYPE_TO_ARRAY_TYPE[utype]
		prop.hint = PROPERTY_HINT_TYPE_STRING
		
		# Build the hint string based on whether element has hints
		if elem_hint != -1 and elem_hint_string != "":
			prop.hint_string = "%d/%d:%s" % [elem_type, elem_hint, elem_hint_string]
		else:
			prop.hint_string = "%d:" % [elem_type]
	
	return prop

static func _get_mpo_arrays_and_mode(renderable: Object, type: RenderableType) -> Array:
	if _is_polygon_type(type):
		var pp: PaperPolygon2D = renderable
		return [pp.material_parameter_overrides, pp.material_parameter_override_names, \
				pp.material_parameter_override_types, pp.override_mode]
	else:
		var spr: PaperSprite2D = renderable
		return [spr.material_parameter_overrides, spr.material_parameter_override_names, \
				spr.material_parameter_override_types, spr.override_mode]

static func _get_paper_override_mask(renderable: Object, type: RenderableType) -> int:
	return (renderable as PaperPolygon2D)._paper_param_override_flags \
		   if _is_polygon_type(type) else \
		   (renderable as PaperSprite2D)._paper_param_override_flags

static func _set_paper_override_mask(renderable: Object, type: RenderableType, mask: int) -> void:
	if _is_polygon_type(type): (renderable as PaperPolygon2D)._paper_param_override_flags = mask
	else: (renderable as PaperSprite2D)._paper_param_override_flags = mask

static func _set_paper_override_mask_for_param(renderable: Object, type: RenderableType, param_name: StringName, has_value: bool) -> void:
	var bit: int = _PAPER_PARAM_TO_INDEX.get(param_name, -1)
	if bit == -1: return
	var mask := _get_paper_override_mask(renderable, type)
	var new_mask := (mask | (1 << bit)) if has_value else (mask & ~(1 << bit))
	if new_mask != mask:
		_set_paper_override_mask(renderable, type, new_mask)

static func _update_or_reset_uniform(renderable: Object, type: RenderableType, param_name: StringName,
									 value: Variant, raw_type: int, override_mode: OverrideMode) -> void:
	if not param_name: return
	
	var is_instance := _mpo_is_instance(raw_type)
	
	_set_paper_override_mask_for_param(renderable, type, param_name, value != null)
	
	var paper_idx: int = _PAPER_PARAM_TO_INDEX.get(param_name, -1)
	
	if value == null and paper_idx != -1:
		update_paper_param(renderable, paper_idx, type)
		return
	
	if is_instance:
		if paper_idx != -1 and paper_idx < PaperParam.COLOR:
			update_param_for_all_slots(renderable, param_name, value, type)
		else:
			set_instance_param_for_all_slots(renderable, param_name, value, type)
		return
	
	if value != null or override_mode == OverrideMode.SHADER_MATERIAL:
		update_param_for_all_slots(renderable, param_name, value, type)
	else:
		reset_param_for_all_slots(renderable, param_name, type)

static func _is_shader_override(renderable: Object, type: RenderableType) -> bool:
	return (renderable as PaperPolygon2D)._is_shader_override_mode() \
		   if _is_polygon_type(type) else \
		   (renderable as PaperSprite2D)._is_shader_override_mode()

static func _recompute_paper_param_override_flag_for_renderable(renderable: Object, type: RenderableType) -> void:
	var override_values: Array
	var override_names: Array[StringName]
	if _is_polygon_type(type):
		var pp: PaperPolygon2D = renderable
		override_values = pp.material_parameter_overrides
		override_names = pp.material_parameter_override_names
	else:
		var spr: PaperSprite2D = renderable
		override_values = spr.material_parameter_overrides
		override_names = spr.material_parameter_override_names
	
	var mask := 0
	for i: int in override_values.size():
		if override_values[i] == null: continue
		var bit: int = _PAPER_PARAM_TO_INDEX.get(override_names[i], -1)
		if bit != -1: mask |= (1 << bit)
	_set_paper_override_mask(renderable, type, mask)

## Changes the size of the provided material parameter override arrays, clearing removed uniforms via [param mat_update].
static func set_material_parameter_overrides_size(size: int, renderable: Object, type: RenderableType) -> void:
	if size > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override size %d exceeds limit %d." % [size, OVERRIDE_PARAM_MAX])
		return
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var new_size := maxi(0, size)
	var old_size := override_values.size()
	if new_size == old_size: return
	
	if new_size < old_size:
		for idx: int in range(new_size, old_size):
			var old_name: StringName = override_names[idx]
			if old_name:
				_update_or_reset_uniform(renderable, type, old_name, null, override_types[idx], override_mode)
	
	override_values.resize(new_size)
	override_names.resize(new_size)
	override_types.resize(new_size)
	
	renderable.notify_property_list_changed()

## Sets a material parameter override at [param idx] and propagates its uniform via [param mat_update].
## Returns true if size grew to accommodate the index.
static func set_material_parameter_override(idx: int, value: Variant, renderable: Object, type: RenderableType) -> bool:
	var idx_limit := absi(idx) + 1
	if idx_limit > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override index %d exceeds limit %d." % [idx, OVERRIDE_PARAM_MAX])
		return false
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var size_changed := idx_limit > override_values.size()
	if size_changed:
		override_values.resize(idx_limit)
		override_names.resize(idx_limit)
		override_types.resize(idx_limit)
	
	if override_values[idx] != value:
		override_values[idx] = value
		_update_or_reset_uniform(renderable, type, override_names[idx], value, override_types[idx], override_mode)
	
	return size_changed

## Sets a material parameter override name at [param idx].
## Returns true if size grew to accommodate the index.
static func set_material_parameter_override_name(idx: int, name: StringName, renderable: Object, type: RenderableType) -> bool:
	var idx_abs := absi(idx)
	var idx_limit := idx_abs + 1
	if idx_limit > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override name index %d exceeds limit %d." % [idx, OVERRIDE_PARAM_MAX])
		return false
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var old_name := &""
	var is_name_new := true
	if idx_abs < override_names.size():
		old_name = override_names[idx]
		is_name_new = old_name != name
		if is_name_new and name and name in override_names:
			push_error("Material parameter override name \"%s\" matches existing name." % name)
			return false
	
	var size_changed := idx_limit > override_values.size()
	if size_changed:
		override_values.resize(idx_limit)
		override_names.resize(idx_limit)
		override_types.resize(idx_limit)
	
	if is_name_new:
		override_names[idx] = name
		
		if old_name:
			_update_or_reset_uniform(renderable, type, old_name, null, override_types[idx], override_mode)
		
		var param_value = override_values[idx]
		_update_or_reset_uniform(renderable, type, name, param_value, override_types[idx], override_mode)
	
	return size_changed

## Sets a material parameter override type at [param idx].
## Returns true if size grew to accommodate the index.
static func set_material_parameter_override_type(idx: int, utype: UniformType, renderable: Object, type: RenderableType) -> bool:
	var idx_limit := absi(idx) + 1
	if idx_limit > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override type index %d exceeds limit %d." % [idx, OVERRIDE_PARAM_MAX])
		return false
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var size_changed := idx_limit > override_values.size()
	if size_changed:
		override_values.resize(idx_limit)
		override_names.resize(idx_limit)
		override_types.resize(idx_limit)
	
	var old_raw: int = override_types[idx]
	var new_raw: int = (utype & _MPO_TYPE_MASK) | (old_raw & ~_MPO_TYPE_MASK)
	
	if old_raw != new_raw:
		var param_name := override_names[idx]
		if param_name:
			_update_or_reset_uniform(renderable, type, param_name, null, old_raw, override_mode)
		
		override_types[idx] = new_raw
		override_values[idx] = get_default_for_uniform_type(utype, _mpo_is_array(new_raw))
		
		if param_name:
			var value = override_values[idx]
			_update_or_reset_uniform(renderable, type, param_name, value, new_raw, override_mode)
	
	return size_changed

## Sets a material parameter override instance toggle at [param idx].
## Returns true if size grew to accommodate the index.
static func set_material_parameter_override_instance(idx: int, flag: bool, renderable: Object, type: RenderableType) -> bool:
	var idx_limit := absi(idx) + 1
	if idx_limit > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override instance index %d exceeds limit %d." % [idx, OVERRIDE_PARAM_MAX])
		return false
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var size_changed := idx_limit > override_values.size()
	if size_changed:
		override_values.resize(idx_limit)
		override_names.resize(idx_limit)
		override_types.resize(idx_limit)
	
	var old_raw := override_types[idx]
	var old_flag := _mpo_is_instance(old_raw)
	if old_flag == flag:
		return size_changed
	
	var param_name := override_names[idx]
	if param_name:
		_update_or_reset_uniform(renderable, type, param_name, null, old_raw, override_mode)
	
	var new_raw := _mpo_with_instance(old_raw, flag)
	override_types[idx] = new_raw
	
	if param_name:
		_update_or_reset_uniform(renderable, type, param_name, override_values[idx], new_raw, override_mode)
	
	return size_changed

## Sets a material parameter override array toggle at [param idx].
## Returns true if size grew to accommodate the index.
static func set_material_parameter_override_array(idx: int, flag: bool, renderable: Object, type: RenderableType) -> bool:
	var idx_limit := absi(idx) + 1
	if idx_limit > OVERRIDE_PARAM_MAX:
		push_error("Material parameter override array index %d exceeds limit %d." % [idx, OVERRIDE_PARAM_MAX])
		return false
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	var override_values: Array = data[0]
	var override_names: Array[StringName] = data[1]
	var override_types: PackedByteArray = data[2]
	var override_mode: OverrideMode = data[3]
	
	var size_changed := idx_limit > override_values.size()
	if size_changed:
		override_values.resize(idx_limit)
		override_names.resize(idx_limit)
		override_types.resize(idx_limit)
	
	var old_raw := override_types[idx]
	var old_flag := _mpo_is_array(old_raw)
	if old_flag == flag:
		return size_changed
	
	var utype := _mpo_uniform_type(old_raw)
	
	var param_name := override_names[idx]
	if param_name:
		_update_or_reset_uniform(renderable, type, param_name, null, old_raw, override_mode)
	
	var new_raw := _mpo_with_array(old_raw, flag)
	override_types[idx] = new_raw
	override_values[idx] = get_default_for_uniform_type(utype, flag)
	
	if param_name:
		_update_or_reset_uniform(renderable, type, param_name, override_values[idx], new_raw, override_mode)
	
	renderable.notify_property_list_changed()
	return size_changed

static var _ARRAY_DEFAULTS: Array = [
	# UniformType.TEXTURE
	Array([], TYPE_OBJECT, "Texture2D,Texture2DArray,Texture3D,Cubemap,CubemapArray,ExternalTexture", null),
	# UniformType.BOOL
	Array([], TYPE_BOOL, "", null),
	# UniformType.INT
	PackedInt32Array(),
	# UniformType.FLOAT
	PackedFloat32Array(),
	# UniformType.VEC2
	PackedVector2Array(),
	# UniformType.VEC3
	PackedVector3Array(),
	# UniformType.VEC4
	PackedVector4Array(),
	# UniformType.COLOR
	PackedColorArray(),
	# UniformType.IVEC2
	Array([], TYPE_VECTOR2I, "", null),
	# UniformType.IVEC3
	Array([], TYPE_VECTOR3I, "", null),
	# UniformType.IVEC4
	Array([], TYPE_VECTOR4I, "", null),
	# UniformType.BVEC2
	PackedByteArray(),
	# UniformType.BVEC3
	PackedByteArray(),
	# UniformType.BVEC4
	PackedByteArray(),
	# UniformType.MAT2
	Array([], TYPE_TRANSFORM2D, "", null),
	# UniformType.MAT3
	Array([], TYPE_BASIS, "", null),
	# UniformType.MAT4
	Array([], TYPE_TRANSFORM3D, "", null),
]
## Returns the default value for a given [enum UniformType].
static func get_default_for_uniform_type(utype: UniformType, is_array: bool = false) -> Variant:
	if is_array: return _ARRAY_DEFAULTS[utype]
	const UNIFORM_DEFAULTS: Array = [
		null,                 # UniformType.TEXTURE
		false,                # UniformType.BOOL
		0,                    # UniformType.INT
		0.0,                  # UniformType.FLOAT
		Vector2.ZERO,         # UniformType.VEC2
		Vector3.ZERO,         # UniformType.VEC3
		Vector4.ZERO,         # UniformType.VEC4
		Color.WHITE,          # UniformType.COLOR
		Vector2i.ZERO,        # UniformType.IVEC2
		Vector3i.ZERO,        # UniformType.IVEC3
		Vector4i.ZERO,        # UniformType.IVEC4
		0,                    # UniformType.BVEC2
		0,                    # UniformType.BVEC3
		0,                    # UniformType.BVEC4
		Transform2D.IDENTITY, # UniformType.MAT2
		Basis.IDENTITY,       # UniformType.MAT3
		Transform3D.IDENTITY, # UniformType.MAT4
	]
	return UNIFORM_DEFAULTS[utype]

## Inspector getter route for material parameter override properties.
static func get_mpo(property: StringName, override_values: Array, override_names: Array[StringName], override_types: PackedByteArray) -> Variant:
	var parsed := _parse_mpo_property_cached(property)
	var kind: int = _decode_mpo_kind(parsed)
	if kind == _MPOKind.NONE: return null
	var idx: int = _decode_mpo_idx(parsed)
	if kind == _MPOKind.VALUE:
		return override_values[idx] if absi(idx) < override_values.size() else null
	elif kind == _MPOKind.NAME:
		return override_names[idx] if absi(idx) < override_names.size() else &""
	elif kind == _MPOKind.TYPE:
		return _mpo_uniform_type(override_types[idx]) if absi(idx) < override_types.size() else UniformType.TEXTURE
	elif kind == _MPOKind.INSTANCE:
		return _mpo_is_instance(override_types[idx]) if absi(idx) < override_types.size() else false
	elif kind == _MPOKind.ARRAY:
		return _mpo_is_array(override_types[idx]) if absi(idx) < override_types.size() else false
	return null

## Inspector setter route for material parameter override properties.
static func set_mpo(property: StringName, value: Variant, renderable: Object, type: RenderableType) -> bool:
	var parsed := _parse_mpo_property_cached(property)
	var kind: int = _decode_mpo_kind(parsed)
	if kind == _MPOKind.NONE: return false
	var idx: int = _decode_mpo_idx(parsed)
	if kind == _MPOKind.VALUE:
		set_material_parameter_override(idx, value, renderable, type)
		return true
	elif kind == _MPOKind.NAME:
		set_material_parameter_override_name(idx, value, renderable, type)
		return true
	elif kind == _MPOKind.TYPE:
		set_material_parameter_override_type(idx, value, renderable, type)
		renderable.notify_property_list_changed()
		return true
	elif kind == _MPOKind.INSTANCE:
		set_material_parameter_override_instance(idx, value, renderable, type)
		return true
	elif kind == _MPOKind.ARRAY:
		set_material_parameter_override_array(idx, value, renderable, type)
		return true
	return false

## Inspector revertability detection for material parameter override properties.
static func can_revert_mpo(property: StringName, override_values: Array, override_names: Array[StringName], override_types: PackedByteArray) -> bool:
	var parsed := _parse_mpo_property_cached(property)
	var kind: int = _decode_mpo_kind(parsed)
	if kind == _MPOKind.NONE: return false
	var idx: int = _decode_mpo_idx(parsed)
	if kind == _MPOKind.VALUE: return override_values[idx] != get_default_for_uniform_type(_mpo_uniform_type(override_types[idx]), _mpo_is_array(override_types[idx]))
	elif kind == _MPOKind.NAME: return override_names[idx] != &""
	elif kind == _MPOKind.TYPE: return _mpo_uniform_type(override_types[idx]) != UniformType.TEXTURE
	elif kind == _MPOKind.INSTANCE: return _mpo_is_instance(override_types[idx])
	elif kind == _MPOKind.ARRAY: return _mpo_is_array(override_types[idx])
	return false

## Inspector revert value for material parameter override properties.
static func get_revert_mpo(property: StringName, override_types: PackedByteArray) -> Variant:
	var parsed := _parse_mpo_property_cached(property)
	var kind: int = _decode_mpo_kind(parsed)
	if kind == _MPOKind.NONE: return null
	var idx: int = _decode_mpo_idx(parsed)
	if kind == _MPOKind.VALUE: return get_default_for_uniform_type(_mpo_uniform_type(override_types[idx]), _mpo_is_array(override_types[idx]))
	elif kind == _MPOKind.NAME: return &""
	elif kind == _MPOKind.TYPE: return UniformType.TEXTURE
	elif kind == _MPOKind.INSTANCE: return false
	elif kind == _MPOKind.ARRAY: return false
	return null
#endregion

#region Material Parameter Override Type/Instance Encoding/Decoding
const _MPO_TYPE_MASK := 0x1F
const _MPO_FLAG_ARRAY := 1 << 6
const _MPO_FLAG_INSTANCE := 1 << 7

static func _mpo_uniform_type(raw: int) -> UniformType:
	return (raw & _MPO_TYPE_MASK) as UniformType

static func _mpo_is_instance(raw: int) -> bool:
	return (raw & _MPO_FLAG_INSTANCE) != 0

static func _mpo_is_array(raw: int) -> bool:
	return (raw & _MPO_FLAG_ARRAY) != 0

static func _mpo_with_instance(raw: int, flag: bool) -> int:
	return (raw | _MPO_FLAG_INSTANCE) if flag else (raw & ~_MPO_FLAG_INSTANCE)

static func _mpo_with_array(raw: int, flag: bool) -> int:
	return (raw | _MPO_FLAG_ARRAY) if flag else (raw & ~_MPO_FLAG_ARRAY)
#endregion

#region Material Parameter Override Property Cache
enum _MPOKind { VALUE = 0, NAME = 1, TYPE = 2, INSTANCE = 3, ARRAY = 4, NONE = 5 }

static var _mpo_cache: Dictionary[StringName, int] = {}

static func _decode_mpo_idx(code: int) -> int:
	return code >> 3

static func _decode_mpo_kind(code: int) -> _MPOKind:
	return (code & 0x7) as _MPOKind

static func _encode_mpo(idx: int, kind: _MPOKind) -> int:
	return (idx << 3) | (kind & 0x7)

static func _is_mpo_none(code: int) -> bool:
	return _decode_mpo_kind(code) == _MPOKind.NONE

static func _parse_mpo_property_cached(property: StringName) -> int:
	const NONE_PROPERTY: int = (0 << 3) | (_MPOKind.NONE & 0x7)
	if not property: return NONE_PROPERTY
	
	var cached: int = _mpo_cache.get(property, -1)
	if cached != -1: return cached
	
	var prop_str := String(property)
	if not prop_str.begins_with(MAT_PARAM_OVERRIDE_PATH_ROOT): return NONE_PROPERTY
	
	var start := MAT_PARAM_OVERRIDE_PATH_ROOT.length()
	var sep := prop_str.find("_", start)
	if sep == -1: return NONE_PROPERTY
	
	var idx_str := prop_str.substr(start, sep - start)
	var idx := idx_str.to_int()
	
	var kind := _MPOKind.NONE
	if prop_str.ends_with(MAT_PARAM_OVERRIDE_PATH_VAL):
		kind = _MPOKind.VALUE
	elif prop_str.ends_with(MAT_PARAM_OVERRIDE_PATH_NAME):
		kind = _MPOKind.NAME
	elif prop_str.ends_with(MAT_PARAM_OVERRIDE_PATH_TYPE):
		kind = _MPOKind.TYPE
	elif prop_str.ends_with(MAT_PARAM_OVERRIDE_PATH_INSTANCE):
		kind = _MPOKind.INSTANCE
	elif prop_str.ends_with(MAT_PARAM_OVERRIDE_PATH_ARRAY):
		kind = _MPOKind.ARRAY
	else:
		return NONE_PROPERTY
	
	var encoded_mpo := _encode_mpo(idx, kind)
	_mpo_cache[property] = encoded_mpo
	return encoded_mpo
#endregion

#region ShaderMaterial Builders / Chain Helpers
## Builds a default [ShaderMaterial] for a renderable with the default shader
## and fills textures uniforms from the renderable's current state.
static func build_default_shader_material(renderable: Object, type: RenderableType) -> ShaderMaterial:
	var pair := _get_param_calls_and_maps(renderable, type)
	var calls: Array[Callable] = pair[0]
	var override_values: Array = pair[1]
	var override_names: Array[StringName] = pair[2]
	var override_types: PackedByteArray = pair[3]
	
	var mat := ShaderMaterial.new()
	mat.shader = get_default_shader()
	
	for i: int in TEX_ALL_PARAMS:
		mat.set_shader_parameter(PAPER_PARAMS[i], calls[i].call(renderable))
	
	for i: int in override_values.size():
		var param_name := override_names[i]
		var param_value = override_values[i]
		if param_name and param_value != null and not _mpo_is_instance(override_types[i]):
			mat.set_shader_parameter(param_name, param_value)
	
	return mat

## Writes instance shader uniforms [code](COLOR..MASK)[/code] to the given MeshInstance3D.
static func apply_paper_instance_uniforms(mi: MeshInstance3D, renderable: Object, type: RenderableType) -> void:
	if not mi or not renderable: return
	var calls := _get_param_calls(type)
	var i: int = PaperParam.COLOR
	while i < PaperParam.size():
		var pname: StringName = PAPER_PARAMS[i]
		var value = calls[i].call(renderable)
		mi.set_instance_shader_parameter(pname, value)
		i += 1
	
	var override_values: Array
	var override_names: Array[StringName]
	var override_types: PackedByteArray
	if _is_polygon_type(type):
		var pp: PaperPolygon2D = renderable
		override_values = pp.material_parameter_overrides
		override_names = pp.material_parameter_override_names
		override_types = pp.material_parameter_override_types
	else:
		var spr: PaperSprite2D = renderable
		override_values = spr.material_parameter_overrides
		override_names = spr.material_parameter_override_names
		override_types = spr.material_parameter_override_types
	
	for idx: int in override_values.size():
		var name := override_names[idx]
		if not name: continue
		if _mpo_is_instance(override_types[idx]):
			mi.set_instance_shader_parameter(name, override_values[idx])

## Applies a renderable's texture uniforms to a [ShaderMaterial] chain (root and all next_pass).
static func apply_paper_textures_over_chain(root: ShaderMaterial, renderable: Object, type: RenderableType) -> void:
	if not root or not renderable: return
	var pair := _get_param_calls_and_maps(renderable, type)
	var calls: Array[Callable] = pair[0]
	var override_values: Array = pair[1]
	var override_names: Array[StringName] = pair[2]
	
	var current := root
	while current:
		for i: int in TEX_ALL_PARAMS:
			current.set_shader_parameter(PAPER_PARAMS[i], calls[i].call(renderable))
		for i: int in override_values.size():
			var param_name := override_names[i]
			if param_name:
				current.set_shader_parameter(param_name, override_values[i])
		current = current.next_pass as ShaderMaterial

## Updates a single uniform across a [ShaderMaterial] chain (root and all next_pass).
static func update_param_at_all_passes(root: ShaderMaterial, param_name: StringName, value: Variant) -> void:
	var current := root
	while current:
		current.set_shader_parameter(param_name, value)
		current = current.next_pass as ShaderMaterial

## Updates a map of uniforms across a [ShaderMaterial] chain (root and all next_pass).
static func update_params_map_over_chain(root: ShaderMaterial, param_values: Dictionary[StringName, Variant]) -> void:
	var current := root
	if not current: return
	while current:
		for key: StringName in param_values:
			current.set_shader_parameter(key, param_values[key])
		current = current.next_pass as ShaderMaterial

## Returns the material at a given [param pass_idx] within a chain (0=root, 1=next, ...), or null.
static func get_material_at_pass(root: Material, pass_idx: int) -> Material:
	var current := root
	for _i in pass_idx:
		if current and current.next_pass:
			current = current.next_pass
		else:
			return null
	return current
#endregion

#region Param Call Accessors / Call-table
static func _get_param_calls(type: RenderableType) -> Array[Callable]:
	return PaperPolygon2D._PARAM_CALLS if _is_polygon_type(type) else PaperSprite2D._PARAM_CALLS

static func _get_param_calls_and_maps(renderable: Object, type: RenderableType) -> Array:
	var calls: Array[Callable]
	var override_values: Array
	var override_names: Array[StringName]
	var override_types: PackedByteArray
	if _is_polygon_type(type):
		calls = PaperPolygon2D._PARAM_CALLS
		var pp: PaperPolygon2D = renderable
		override_values = pp.material_parameter_overrides
		override_names = pp.material_parameter_override_names
		override_types = pp.material_parameter_override_types
	else:
		calls = PaperSprite2D._PARAM_CALLS
		var spr: PaperSprite2D = renderable
		override_values = spr.material_parameter_overrides
		override_names = spr.material_parameter_override_names
		override_types = spr.material_parameter_override_types
	return [calls, override_values, override_names, override_types]

static func _call_index(call_type: CallType, type: RenderableType, slot: RenderSlot) -> int:
	return (call_type * RenderableType.size() + type) * RenderSlot.size() + slot

static func _get_call(call_type: CallType, type: RenderableType, slot: RenderSlot) -> Callable:
	return _RENDERABLE_CALLS[_call_index(call_type, type, slot)]
#endregion

#region Slot-wide convenience getters/setters
## Returns MeshInstance3D for a given slot of a renderable.
static func get_slot_mesh_instance(renderable: Object, slot: RenderSlot, type: RenderableType) -> MeshInstance3D:
	return _get_call(CallType.MESH_INST, type, slot).call(renderable)

## Returns root ShaderMaterial for a given renderable slot.
static func get_slot_root_material(renderable: Object, slot: RenderSlot, type: RenderableType) -> ShaderMaterial:
	var mi := get_slot_mesh_instance(renderable, slot, type)
	return mi.material_override if mi else null

## Returns ShaderMaterial at a given pass index within a slot chain.
static func get_slot_material_at_pass(renderable: Object, slot: RenderSlot, pass_idx: int, type: RenderableType) -> ShaderMaterial:
	var root := get_slot_root_material(renderable, slot, type)
	return get_material_at_pass(root, pass_idx)

## Updates a uniform across all slots and all passes.
static func update_param_for_all_slots(renderable: Object, param_name: StringName, value: Variant, type: RenderableType) -> void:
	for slot: int in RenderSlot.size():
		var mat := get_slot_root_material(renderable, slot, type)
		if mat: update_param_at_all_passes(mat, param_name, value)

## Resets a uniform across all slots and all passes to match its [PaperMaterial].
static func reset_param_for_all_slots(renderable: Object, param_name: StringName, type: RenderableType) -> void:
	var paper_param := TEX_PARAM_NAMES.find(param_name)
	if paper_param != -1:
		update_paper_param(renderable, paper_param, type)
		return
	
	for slot: int in RenderSlot.size():
		var mat := get_slot_root_material(renderable, slot, type)
		if mat:
			var current: ShaderMaterial = mat
			var current_paper: PaperMaterial = _get_call(CallType.ACTIVE_PM, type, slot).call(renderable)
			while current:
				var param_value = null
				if current_paper:
					param_value = current_paper.get_shader_parameter(param_name)
					current_paper = current_paper.next_pass
				
				current.set_shader_parameter(param_name, param_value)
				current = current.next_pass as ShaderMaterial

## Updates a dictionary of uniforms across all slots and all passes.
static func update_params_map_for_all_slots(renderable: Object, param_values: Dictionary[StringName, Variant], type: RenderableType) -> void:
	for slot: int in RenderSlot.size():
		var mat := get_slot_root_material(renderable, slot, type)
		if mat: update_params_map_over_chain(mat, param_values)

## Sets an instance uniform across all slots.
static func set_instance_param_for_all_slots(renderable: Object, param_name: StringName, value: Variant, type: RenderableType) -> void:
	for slot: int in RenderSlot.size():
		var mesh := get_slot_mesh_instance(renderable, slot, type)
		if mesh: mesh.set_instance_shader_parameter(param_name, value)
#endregion


#region PaperParam update entry points (public)
## Updates one [enum PaperParam] from the renderable state.
static func update_paper_param(renderable: Object, paper_param: PaperParam, type: RenderableType) -> void:
	var calls := _get_param_calls(type)
	var pname: StringName = PAPER_PARAMS[paper_param]
	var value = calls[paper_param].call(renderable)
	
	var mask := _get_paper_override_mask(renderable, type)
	if (mask & 1 << paper_param) != 0: return
	
	if paper_param < PaperParam.COLOR:
		update_param_for_all_slots(renderable, pname, value, type)
	else:
		set_instance_param_for_all_slots(renderable, pname, value, type)

## Updates multiple [enum PaperParam] indices from the renderable state.
static func update_paper_params(renderable: Object, paper_params: PackedByteArray, type: RenderableType) -> void:
	var calls := _get_param_calls(type)
	
	var base := get_slot_mesh_instance(renderable, RenderSlot.BASE, type)
	var border := get_slot_mesh_instance(renderable, RenderSlot.BORDER, type)
	var group := get_slot_mesh_instance(renderable, RenderSlot.GROUP, type)
	
	var mask := _get_paper_override_mask(renderable, type)
	
	for paper_param: int in paper_params:
		if (mask & 1 << paper_param) != 0: continue
		
		var pname := PAPER_PARAMS[paper_param]
		var value = calls[paper_param].call(renderable)
		if paper_param < PaperParam.COLOR:
			if base: update_param_at_all_passes(base.material_override, pname, value)
			if border: update_param_at_all_passes(border.material_override, pname, value)
			if group: update_param_at_all_passes(group.material_override, pname, value)
		else:
			if base: base.set_instance_shader_parameter(pname, value)
			if border: border.set_instance_shader_parameter(pname, value)
			if group: group.set_instance_shader_parameter(pname, value)
#endregion

#region Pass chain rebuild / structure changes
## Rebuilds a slot material chain starting from a changed pass.
static func rebuild_chain_for_slot_from_pass(renderable: Object, slot: RenderSlot, pass_idx: int, effective: PaperMaterial, type: RenderableType) -> void:
	if not effective: return
	var mi := get_slot_mesh_instance(renderable, slot, type)
	if not mi: return
	
	var paper_pass := effective.get_pass(pass_idx)
	if not paper_pass:
		if pass_idx == 0:
			mi.material_override = null
		else:
			var prev := get_material_at_pass(mi.material_override, pass_idx - 1)
			if prev: prev.next_pass = null
		return
	
	var rebuilt := paper_pass._create_shader_material_for_renderable(renderable, type)
	if pass_idx == 0:
		mi.material_override = rebuilt
	else:
		var prev := get_material_at_pass(mi.material_override, pass_idx - 1)
		if prev: prev.next_pass = rebuilt
	
	apply_paper_textures_over_chain(mi.material_override, renderable, type)

## Applies structure-change bits to a single pass within a renderable slot.
static func handle_pass_structure_changed(renderable: Object, slot: RenderSlot, pass_idx: int, bits: int, effective: PaperMaterial, type: RenderableType) -> void:
	if bits & (PaperMaterial.Struct.SHADER | PaperMaterial.Struct.NEXT_PASS):
		rebuild_chain_for_slot_from_pass(renderable, slot, pass_idx, effective, type)
	elif bits & PaperMaterial.Struct.RENDER_PRIORITY:
		var target := get_slot_material_at_pass(renderable, slot, pass_idx, type)
		if target and effective:
			var pm := effective.get_pass(pass_idx)
			if pm: target.render_priority = pm.render_priority

## Updates a single uniform on a specific slot/pass (no chain).
static func update_param_at_slot_pass(renderable: Object, slot: RenderSlot, pass_idx: int, param_name: StringName, value: Variant, type: RenderableType) -> void:
	var target := get_slot_material_at_pass(renderable, slot, pass_idx, type)
	if target: target.set_shader_parameter(param_name, value)
#endregion

#region Effective PaperMaterial binding/unbinding (per-slot)
static func _connect_effective_material_signals(renderable: Object, slot: RenderSlot, pm: PaperMaterial, type: RenderableType) -> void:
	if not pm or not renderable: return
	var param_cb: Callable = _get_call(CallType.MAT_PARAM_UPDATE, type, slot).call(renderable)
	var struct_cb: Callable = _get_call(CallType.MAT_STRUCT_UPDATE, type, slot).call(renderable)
	if not pm.pass_parameter_changed.is_connected(param_cb):
		pm.pass_parameter_changed.connect(param_cb)
	if not pm.pass_structure_changed.is_connected(struct_cb):
		pm.pass_structure_changed.connect(struct_cb)

static func _disconnect_effective_material_signals(renderable: Object, slot: RenderSlot, pm: PaperMaterial, type: RenderableType) -> void:
	if not pm or not renderable: return
	var param_cb: Callable = _get_call(CallType.MAT_PARAM_UPDATE, type, slot).call(renderable)
	var struct_cb: Callable = _get_call(CallType.MAT_STRUCT_UPDATE, type, slot).call(renderable)
	if pm.pass_parameter_changed.is_connected(param_cb):
		pm.pass_parameter_changed.disconnect(param_cb)
	if pm.pass_structure_changed.is_connected(struct_cb):
		pm.pass_structure_changed.disconnect(struct_cb)

## Binds the effective [PaperMaterial] or [ShaderMaterial] override to a slot,
## wiring signals and setting [member MeshInstance3D.material_override].
static func bind_effective_material_for_slot(renderable: Object, slot: RenderSlot, type: RenderableType) -> void:
	if not renderable: return
	
	var mi: MeshInstance3D = get_slot_mesh_instance(renderable, slot, type)
	var get_eff_call := _get_call(CallType.GET_EFFECTIVE_PM, type, slot)
	
	var shader_mode := _is_shader_override(renderable, type)
	
	if shader_mode:
		# In shader override mode, clear effective PaperMaterial and use the override chain.
		var cur_eff: PaperMaterial = get_eff_call.call(renderable)
		if cur_eff:
			_disconnect_effective_material_signals(renderable, slot, cur_eff, type)
		_get_call(CallType.SET_EFFECTIVE_PM, type, slot).call(renderable, null)
		
		if mi:
			var ovr: ShaderMaterial = _get_call(CallType.GET_SHADER_OVR, type, slot).call(renderable)
			if not ovr:
				var shader_material := mi.material_override
				if not shader_material:
					var active: PaperMaterial = _get_call(CallType.ACTIVE_PM, type, slot).call(renderable)
					if active:
						shader_material = active._create_shader_material_for_renderable(renderable, type)
					else:
						shader_material = build_default_shader_material(renderable, type)
				_get_call(CallType.SET_SHADER_OVR, type, slot).call(renderable, shader_material)
				ovr = shader_material
			mi.material_override = ovr
		return
	
	# PaperMaterial mode: rebind effective material and signals
	var new_eff: PaperMaterial = _get_call(CallType.ACTIVE_PM, type, slot).call(renderable)
	var old_eff: PaperMaterial = get_eff_call.call(renderable)
	if old_eff != new_eff:
		if old_eff: _disconnect_effective_material_signals(renderable, slot, old_eff, type)
		_get_call(CallType.SET_EFFECTIVE_PM, type, slot).call(renderable, new_eff)
		if new_eff: _connect_effective_material_signals(renderable, slot, new_eff, type)
	
	if mi:
		var eff: PaperMaterial = get_eff_call.call(renderable)
		mi.material_override = (
			eff._create_shader_material_for_renderable(renderable, type)
			if eff else build_default_shader_material(renderable, type)
		)

## Unbinds effective [PaperMaterial] from a slot, disconnecting signals.
static func unbind_effective_material_for_slot(renderable: Object, slot: RenderSlot, type: RenderableType) -> void:
	if not renderable: return
	var get_eff_call := _get_call(CallType.GET_EFFECTIVE_PM, type, slot)
	var set_eff_call := _get_call(CallType.SET_EFFECTIVE_PM, type, slot)
	var eff: PaperMaterial = get_eff_call.call(renderable)
	if eff: _disconnect_effective_material_signals(renderable, slot, eff, type)
	set_eff_call.call(renderable, null)
#endregion

#region Renderable Override Entries
const _DISPLAY_ENTRY_NEW := &"Entry"
enum _DisplayEntryProp { MAIN, MPO_VALUES, MPO_NAMES, MPO_TYPES }

static var _display_entry_apply_lock := false

static func _get_display_entry_all(renderable: Object, type: RenderableType) -> Array:
	if _is_polygon_type(type):
		var p: PaperPolygon2D = renderable
		return [p._display_entry_data, p._display_entry_order, p._display_entry_value]
	else:
		var s: PaperSprite2D = renderable
		return [s._display_entry_data, s._display_entry_order, s._display_entry_value]

static func _get_display_entry_data_ref(renderable: Object, type: RenderableType) -> Dictionary[StringName, Array]:
	return (renderable as PaperPolygon2D)._display_entry_data \
		   if _is_polygon_type(type) else \
		   (renderable as PaperSprite2D)._display_entry_data

static func _set_display_entry_data_ref(renderable: Object, type: RenderableType, data: Dictionary[StringName, Array]) -> void:
	if _is_polygon_type(type): (renderable as PaperPolygon2D)._display_entry_data = data
	else: (renderable as PaperSprite2D)._display_entry_data = data

static func _get_display_entry_order_ref(renderable: Object, type: RenderableType) -> Array[StringName]:
	return (renderable as PaperPolygon2D)._display_entry_order \
		   if _is_polygon_type(type) else \
		   (renderable as PaperSprite2D)._display_entry_order

static func _set_display_entry_order_ref(renderable: Object, type: RenderableType, order: Array[StringName]) -> void:
	if _is_polygon_type(type): (renderable as PaperPolygon2D)._display_entry_order = order
	else: (renderable as PaperSprite2D)._display_entry_order = order

static func _get_display_entry_value(renderable: Object, type: RenderableType) -> StringName:
	return (renderable as PaperPolygon2D)._display_entry_value \
		   if _is_polygon_type(type) else \
		   (renderable as PaperSprite2D)._display_entry_value

static func _set_display_entry_value(renderable: Object, type: RenderableType, value: StringName) -> void:
	if _is_polygon_type(type): (renderable as PaperPolygon2D)._display_entry_value = value
	else: (renderable as PaperSprite2D)._display_entry_value = value

static func _get_display_entry_properties(type: RenderableType) -> Dictionary[StringName, Variant]:
	return PaperPolygon2D.DISPLAY_ENTRY_PROPERTIES if _is_polygon_type(type) else PaperSprite2D.DISPLAY_ENTRY_PROPERTIES

static func _clear_display_entry_storage(renderable: Object, type: RenderableType) -> void:
	_set_display_entry_data_ref(renderable, type, {})
	_set_display_entry_order_ref(renderable, type, [])
	_set_display_entry_value(renderable, type, &"")

static var _display_entry_property_editor = null
static func _on_display_entry_property_changed(renderable: Object, type: RenderableType) -> void:
	if not Engine.is_editor_hint() or _display_entry_apply_lock or \
	   not _display_entry_property_editor or \
	   _display_entry_property_editor.get_edited_object() != renderable: return
	
	var dirty := is_display_entry_dirty(renderable, type)
	_display_entry_property_editor._update_button_save(dirty)

static func _capture_display_entry_data(renderable: Object, type: RenderableType) -> Array:
	var props: Dictionary[StringName, Variant] = {}
	var display_entry_properties := _get_display_entry_properties(type)
	for k: StringName in display_entry_properties:
		var prop_value = renderable.get(k)
		if display_entry_properties[k] != prop_value:
			props[k] = prop_value
	
	var data := _get_mpo_arrays_and_mode(renderable, type)
	return [
		props,
		(data[0] as Array).duplicate(true),
		(data[1] as Array[StringName]).duplicate(),
		(data[2] as PackedByteArray).duplicate()
	]

## Returns [code]true[/code] if the current visual properties differ from the currently selected entry
## for the renderable.
## [br][br]
## Useful to detect when a snapshot needs saving.
static func is_display_entry_dirty(renderable: Object, type: RenderableType) -> bool:
	var data := _get_display_entry_data_ref(renderable, type)
	if data.is_empty(): return false
	
	var current := _get_display_entry_value(renderable, type)
	if current.is_empty() or not data.has(current): return false
	
	var entry: Array = data[current]
	if entry.size() < 4: return true
	
	var cur := _capture_display_entry_data(renderable, type)
	return entry != cur

## Saves the current visual properties into the active display entry for the renderable.
## [br][br]
## Use this after editing properties to persist the snapshot.
static func save_display_entry(renderable: Object, type: RenderableType) -> bool:
	var data := _get_display_entry_data_ref(renderable, type)
	if data.is_empty(): return false
	var current := _get_display_entry_value(renderable, type)
	if current.is_empty() or not data.has(current): return false
	data[current] = _capture_display_entry_data(renderable, type)
	return true

## Abstracted setter for [member PaperPolygon2D.display_entry]/[member PaperSprite2D.display_entry].
static func set_display_entry(renderable: Object, type: RenderableType, value: StringName) -> void:
	var data: Dictionary[StringName, Array] = _get_display_entry_data_ref(renderable, type)
	if data.is_empty():
		_set_display_entry_value(renderable, type, &"")
		return
	
	if value == &"" or not data.has(value):
		var order: Array[StringName] = _get_display_entry_order_ref(renderable, type)
		value = order[0] if not order.is_empty() else &""
	
	_set_display_entry_value(renderable, type, value)
	
	if value != &"":
		_display_entry_apply_lock = true
		apply_display_entry(renderable, type, data[value])
		_display_entry_apply_lock = false

## Helper function used by [method set_display_entry] to apply the display entry data to the renderable.
## Not normally intended to be used by itself.
static func apply_display_entry(renderable: Object, type: RenderableType, entry: Array) -> void:
	if entry.size() < 4: return
	
	# Main visual properties
	var props: Dictionary[StringName, Variant] = entry[_DisplayEntryProp.MAIN]
	var display_entry_properties := _get_display_entry_properties(type)
	
	for k: StringName in display_entry_properties:
		var target = props.get(k, display_entry_properties[k])
		if renderable.get(k) != target:
			renderable.set(k, target)
	
	# Material parameter overrides
	var values: Array = entry[_DisplayEntryProp.MPO_VALUES]
	var names: Array[StringName] = entry[_DisplayEntryProp.MPO_NAMES]
	var types: PackedByteArray = entry[_DisplayEntryProp.MPO_TYPES]
	
	var current = _get_mpo_arrays_and_mode(renderable, type)
	var cur_values: Array = current[0]
	var cur_names: Array[StringName] = current[1]
	var cur_types: PackedByteArray = current[2]
	var override_mode: OverrideMode = current[3]
	
	var new_size := values.size()
	var old_size := cur_values.size()
	
	var any_changed := false
	var plist_dirty := false
	
	# Handle resize with manual cleanup
	if new_size != old_size:
		if new_size < old_size:
			for idx: int in range(new_size, old_size):
				var old_name: StringName = cur_names[idx]
				if old_name:
					_update_or_reset_uniform(renderable, type, old_name, null, cur_types[idx], override_mode)
		
		cur_values.resize(new_size)
		cur_names.resize(new_size)
		cur_types.resize(new_size)
		
		any_changed = true
		plist_dirty = true
	
	# Apply diffs only
	for i: int in new_size:
		var new_name: StringName = names[i]
		var new_raw: int = types[i]
		var new_val = values[i]
		
		var old_name: StringName = cur_names[i]
		var old_raw: int = cur_types[i]
		var old_val = cur_values[i]
		
		if old_name == new_name and old_raw == new_raw and old_val == new_val: continue
		
		# Clear old uniform if name or raw type/flags changed
		if old_name and (old_name != new_name or old_raw != new_raw):
			_update_or_reset_uniform(renderable, type, old_name, null, old_raw, override_mode)
		
		# Write new data
		cur_names[i] = new_name
		cur_types[i] = new_raw
		cur_values[i] = new_val
		
		# Apply new uniform if any
		if new_name:
			_update_or_reset_uniform(renderable, type, new_name, new_val, new_raw, override_mode)
		
		if not any_changed:
			any_changed = true
		if not plist_dirty and old_raw != new_raw:
			plist_dirty = true
	
	if any_changed:
		_recompute_paper_param_override_flag_for_renderable(renderable, type)
	
	if plist_dirty:
		renderable.notify_property_list_changed()

## Snapshots a renderable and creates a new display entry for it and selects it.
## [br][br]
## If [param entry_name] already exists as an entry, a numbered suffix is appended (or incremented, if one already exists).
## The snapshot includes the display properties and material parameter overrides for this renderable.
static func add_display_entry(renderable: Object, type: RenderableType, entry_name: StringName) -> bool:
	var display_entry_all := _get_display_entry_all(renderable, type)
	var data: Dictionary[StringName, Array] = display_entry_all[0]
	var order: Array[StringName] = display_entry_all[1]
	
	var base_name: StringName = entry_name if entry_name != &"" else _DISPLAY_ENTRY_NEW
	var final_name: StringName = base_name
	
	if data.has(base_name):
		var base_str := String(base_name)
		var suffix_idx := base_str.rfind(" ")
		if suffix_idx != -1:
			var tail := base_str.substr(suffix_idx + 1)
			if tail.is_valid_int():
				base_str = base_str.substr(0, suffix_idx)
				final_name = StringName(base_str)
			else:
				final_name = base_name
		else:
			final_name = base_name
		
		if final_name == base_name or data.has(final_name):
			var i := 1
			var candidate := StringName("%s %d" % [base_str, i])
			
			while data.has(candidate):
				i += 1
				candidate = StringName("%s %d" % [base_str, i])
			
			final_name = candidate
	else:
		final_name = base_name
	
	data[final_name] = _capture_display_entry_data(renderable, type)
	var current: StringName = display_entry_all[2]
	
	if data.size() == 1 and order.is_empty():
		order.append(final_name)
		renderable.notify_property_list_changed()
	else:
		var idx := order.find(current)
		if idx == -1: order.append(final_name)
		else: order.insert(idx + 1, final_name)
	set_display_entry(renderable, type, final_name)
	
	return true

## Removes a display entry for a renderable by name.
## [br][br]
## If the removed entry was active, the first available entry is then automatically selected.
static func remove_display_entry(renderable: Object, type: RenderableType, entry_name: StringName) -> bool:
	var display_entry_all := _get_display_entry_all(renderable, type)
	var data: Dictionary[StringName, Array] = display_entry_all[0]
	var order: Array[StringName] = display_entry_all[1]
	if data.is_empty() or not data.has(entry_name): return false
	data.erase(entry_name)
	
	var idx := order.find(entry_name)
	if idx != -1: order.remove_at(idx)
	
	var current: StringName = display_entry_all[2]
	if data.is_empty():
		_clear_display_entry_storage(renderable, type)
		renderable.notify_property_list_changed()
		return true
	
	if current == entry_name:
		set_display_entry(renderable, type, order[0] if not order.is_empty() else &"")
	
	return true

## Renames an existing display entry for a renderable.
## [br][br]
## Returns [code]false[/code] if [param new_name] is empty or already exists.
static func rename_display_entry(renderable: Object, type: RenderableType, old_name: StringName, new_name: StringName) -> bool:
	var display_entry_all := _get_display_entry_all(renderable, type)
	var data: Dictionary[StringName, Array] = display_entry_all[0]
	var order: Array[StringName] = display_entry_all[1]
	
	if data == null or new_name == &"" or data.is_empty() or data.has(new_name) or not data.has(old_name):
		return false
	
	var entry := data[old_name]
	data.erase(old_name)
	data[new_name] = entry
	
	var idx := order.find(old_name)
	if idx != -1: order[idx] = new_name
	
	var current: StringName = display_entry_all[2]
	if current == old_name:
		_display_entry_apply_lock = true
		_set_display_entry_value(renderable, type, new_name)
		_display_entry_apply_lock = false
	return true

## Moves a display entry for a renderable up or down in the list by [param dir].
## [br][br]
## Use [code]-1[/code] to move up, [code]1[/code] to move down.
static func move_display_entry(renderable: Object, type: RenderableType, entry_name: StringName, dir: int) -> bool:
	var order := _get_display_entry_order_ref(renderable, type)
	if order.is_empty(): return false
	
	var idx := order.find(entry_name)
	if idx == -1: return false
	
	var new_idx := clampi(idx + dir, 0, order.size() - 1)
	if new_idx == idx: return false
	
	order.remove_at(idx)
	order.insert(new_idx, entry_name)
	
	return true
#endregion

#region Renderable Property List
const _PROP_TOOL_BTN_REBUILD := &"defer_3d_mesh_reconstruction"

const _PROP_DISPLAY_ENTRY := &"display_entry"
const _PROP_SUBDIVISION   := &"subdivision_level"
const _PROP_FLIP_TEX      := &"flip_texture"
const _PROP_UV_MASKING    := &"uv_masking"

const _PROP_OVERRIDE_MODE := &"override_mode"
const _PROP_PM_OVERRIDE   := &"paper_material_override"
const _PROP_SM_OVERRIDE   := &"shader_material_override"

const _PROP_BORDER_ENABLED := &"border_mesh_enabled"
const _PROP_BORDER_PM      := &"border_paper_material_override"
const _PROP_BORDER_SM      := &"border_shader_material_override"

const _PROP_GROUP_ENABLED := &"group_mesh_enabled"
const _PROP_GROUP_PM      := &"group_paper_material_override"
const _PROP_GROUP_SM      := &"group_shader_material_override"

const _PROP_INDEX_TARGET        := &"index_target"
const _PROP_GROUP_INDEX_TARGET  := &"group_index_target"

const _PROP_MPO_SIZE   := &"material_parameter_overrides_size"

static func get_renderable_property_list(r: Object, type: RenderableType) -> Array[Dictionary]:
	var display_order: Array[StringName]
	var shader_mode: bool
	var border_enabled: bool
	var group_enabled: bool
	var subdiv_limit: int
	var idx_target_hint: String
	var mpo_size: int
	var mpo_types: PackedByteArray
	
	if _is_polygon_type(type):
		var p: PaperPolygon2D = r
		display_order   = p._display_entry_order
		shader_mode     = p._is_shader_override_mode()
		border_enabled  = p.border_mesh_enabled
		group_enabled   = p.group_mesh_enabled
		subdiv_limit    = 5
		idx_target_hint = "PaperPolygon2D,PaperSprite2D"
		mpo_size        = p.material_parameter_overrides_size
		mpo_types       = p.material_parameter_override_types
	else:
		var s: PaperSprite2D = r
		display_order   = s._display_entry_order
		shader_mode     = s._is_shader_override_mode()
		border_enabled  = s.border_mesh_enabled
		group_enabled   = s.group_mesh_enabled
		subdiv_limit    = 8
		idx_target_hint = "PaperSprite2D,PaperPolygon2D"
		mpo_size        = s.material_parameter_overrides_size
		mpo_types       = s.material_parameter_override_types
	
	var any_display_entries := not display_order.is_empty()
	var add_entry_hint := Engine.is_editor_hint() and any_display_entries
	
	var props: Array[Dictionary] = [
		{
			"name": _PROP_TOOL_BTN_REBUILD,
			"type": TYPE_CALLABLE,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_TOOL_BUTTON,
			"hint_string": "Reconstruct 3D Mesh,MeshInstance3D"
		},
		
		{
			"name": _PROP_DISPLAY_ENTRY,
			"type": TYPE_STRING_NAME,
			"usage": PROPERTY_USAGE_EDITOR if any_display_entries else PROPERTY_USAGE_EDITOR | PROPERTY_USAGE_READ_ONLY,
			"hint": PROPERTY_HINT_ENUM if add_entry_hint else PROPERTY_HINT_NONE,
			"hint_string": ",".join(display_order) if add_entry_hint else "",
		},{
			"name": _PROP_SUBDIVISION,
			"type": TYPE_INT,
			"usage": _get_revert_usage(_PROP_SUBDIVISION, r),
			"hint": PROPERTY_HINT_RANGE,
			"hint_string": "0,%d,1" % subdiv_limit,
		},{
			"name": _PROP_FLIP_TEX,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_FLIP_TEX, r),
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "Texture2D",
		},{
			"name": _PROP_UV_MASKING,
			"type": TYPE_BOOL,
			"usage": _get_revert_usage(_PROP_UV_MASKING, r),
		},
		
		{
			"name": "Material Override",
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_GROUP,
		},{
			"name": _PROP_OVERRIDE_MODE,
			"type": TYPE_INT,
			"usage": _get_revert_usage(_PROP_OVERRIDE_MODE, r),
			"hint": PROPERTY_HINT_ENUM,
			"hint_string": "PaperMaterial,ShaderMaterial",
		},{
			"name": _PROP_PM_OVERRIDE,
			"type": TYPE_OBJECT,
			"usage": PROPERTY_USAGE_NO_EDITOR if shader_mode else _get_revert_usage(_PROP_PM_OVERRIDE, r),
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "PaperMaterial",
		},{
			"name": _PROP_SM_OVERRIDE,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_SM_OVERRIDE, r) if shader_mode else PROPERTY_USAGE_NONE,
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "ShaderMaterial",
		},
		
		{
			"name": "Border Effect",
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_SUBGROUP,
			"hint_string": "border_",
		},{
			"name": _PROP_BORDER_ENABLED,
			"type": TYPE_BOOL,
			"usage": _get_revert_usage(_PROP_BORDER_ENABLED, r),
			"hint": PROPERTY_HINT_GROUP_ENABLE,
		},{
			"name": _PROP_BORDER_PM,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_BORDER_PM, r, border_enabled and not shader_mode),
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "PaperMaterial",
		},{
			"name": _PROP_BORDER_SM,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_BORDER_SM, r, border_enabled) if shader_mode else PROPERTY_USAGE_NONE,
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "ShaderMaterial",
		},
		
		{
			"name": "Group Effect",
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_SUBGROUP,
			"hint_string": "group_",
		},{
			"name": _PROP_GROUP_ENABLED,
			"type": TYPE_BOOL,
			"usage": _get_revert_usage(_PROP_GROUP_ENABLED, r),
			"hint": PROPERTY_HINT_GROUP_ENABLE,
		},{
			"name": _PROP_GROUP_PM,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_GROUP_PM, r, group_enabled and not shader_mode),
			"hint": PROPERTY_HINT_RESOURCE_TYPE,
			"hint_string": "PaperMaterial",
		},{
			"name": _PROP_GROUP_SM,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_GROUP_SM, r, group_enabled) if shader_mode else PROPERTY_USAGE_NONE,
			"hint": PROPERTY_HINT_RESOURCE_TYPE, "hint_string": "ShaderMaterial",
		},
		
		{
			"name": "Index Pointers",
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_GROUP,
		},{
			"name": _PROP_INDEX_TARGET,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_INDEX_TARGET, r),
			"hint": PROPERTY_HINT_NODE_TYPE,
			"hint_string": idx_target_hint,
		},{
			"name": _PROP_GROUP_INDEX_TARGET,
			"type": TYPE_OBJECT,
			"usage": _get_revert_usage(_PROP_GROUP_INDEX_TARGET, r),
			"hint": PROPERTY_HINT_NODE_TYPE,
			"hint_string": idx_target_hint,
		},
		
		{
			"name": "Material Parameter Overrides",
			"type": TYPE_NIL,
			"usage": PROPERTY_USAGE_GROUP,
			"hint_string": "material_parameter_overrides_",
		},{
			"name": _PROP_MPO_SIZE,
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
		},
	]
	
	props.append_array(get_material_parameter_override_properties(mpo_size, mpo_types))
	return props

const _DEFAULT_REVERT_MAP: Dictionary[StringName, Variant] = {
	_PROP_SUBDIVISION:    0,    _PROP_FLIP_TEX:           null,
	_PROP_UV_MASKING:     true, _PROP_OVERRIDE_MODE:      OverrideMode.PAPER_MATERIAL,
	_PROP_PM_OVERRIDE:    null, _PROP_SM_OVERRIDE:        null,
	_PROP_BORDER_ENABLED: true, _PROP_BORDER_PM:          null,
	_PROP_BORDER_SM:      null, _PROP_GROUP_ENABLED:      true,
	_PROP_GROUP_PM:       null, _PROP_GROUP_SM:           null,
	_PROP_INDEX_TARGET:   null, _PROP_GROUP_INDEX_TARGET: null,
	_PROP_MPO_SIZE:       0,
}

static func _get_revert_usage(property: StringName, r: Object, editor: bool = true) -> int:
	var differs: bool = r.get(property) != _DEFAULT_REVERT_MAP[property]
	return (PROPERTY_USAGE_STORAGE if differs else PROPERTY_USAGE_NONE) | \
		   (PROPERTY_USAGE_EDITOR  if editor  else PROPERTY_USAGE_NONE)

static func can_revert_renderable_property(property: StringName, r: Object, type: RenderableType) -> bool:
	if property == _PROP_DISPLAY_ENTRY: return false
	elif _DEFAULT_REVERT_MAP.has(property): return r.get(property) != _DEFAULT_REVERT_MAP[property]
	else:
		var data := _get_mpo_arrays_and_mode(r, type)
		return can_revert_mpo(property, data[0], data[1], data[2])

static func get_revert_renderable_property(property: StringName, r: Object, type: RenderableType) -> Variant:
	if property == _PROP_DISPLAY_ENTRY: return null
	elif _DEFAULT_REVERT_MAP.has(property): return _DEFAULT_REVERT_MAP[property]
	else:
		var mpo_types := (r as PaperPolygon2D).material_parameter_override_types \
						 if _is_polygon_type(type) else \
						 (r as PaperSprite2D).material_parameter_override_types
		return get_revert_mpo(property, mpo_types)
#endregion

#region Hash Signing Functions
## 64-bit FNV-1a offset basis.
const FNV64_OFFSET := 1469598103934665603
## 64-bit FNV-1a prime.
const FNV64_PRIME  := 1099511628211

## Mixes an integer value into an existing 64-bit FNV-1a hash.
## If no hash is provided, starts from [constant FNV64_OFFSET].
static func h64(v: int, h: int = FNV64_OFFSET) -> int:
	return (h ^ v) * FNV64_PRIME

## Quantizes a float into a stable integer representation.
## Values are scaled to 1e-6 precision to reduce floating-point noise.
static func quantize(v: float) -> int:
	return roundi(v * 1e-6)

## Generates a deterministic 64-bit hash signature from a [Transform2D].
static func t2d_sig(t: Transform2D) -> int:
	var h := FNV64_OFFSET
	h = h64(quantize(t.x.x), h); h = h64(quantize(t.x.y), h)
	h = h64(quantize(t.y.x), h); h = h64(quantize(t.y.y), h)
	h = h64(quantize(t.origin.x), h); h = h64(quantize(t.origin.y), h)
	return h
#endregion
