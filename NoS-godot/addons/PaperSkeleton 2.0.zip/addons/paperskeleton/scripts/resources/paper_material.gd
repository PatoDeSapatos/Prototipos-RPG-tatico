@tool
@icon("uid://papermaticon")
extends Resource
class_name PaperMaterial

## [Resource] specifically designed to mimic [ShaderMaterial]'s functionality in a way that more
## cleanly integrates with [PaperSkeleton]. Through the use of rather complex signal connections,
## the [PaperSkeleton] setup manually updates to match any changes to the [PaperMaterial]'s configurations.
## Only supports spatial [Shader]s.
## [br][br]
## It should be noted that this is not a true [Material]. It's just a utility designed to synchronize the
## management of multiple [ShaderMaterial]s in [PaperSkeleton] rigs, as each mesh requires their own material
## to account for different materials.
## [br][br]
## If you would prefer to forgo this system (whether partly or entirely) to squeeze out some extra optimization,
## at the cost of having more limited texture swapping capabilities, feel free to change your renderables' override mode 
## ([member PaperPolygon2D.override_mode] or [member PaperSprite2D.override_mode]) to
## [enum PaperConstants.OverrideMode.SHADER_MATERIAL] to allow yourself to manually define your meshes' [ShaderMaterial]s.

signal shader_changed(shader: Shader)
signal next_pass_changed(next_pass: PaperMaterial)
signal render_priority_changed(priority: int)
signal parameter_changed(param_name: StringName, new_value: Variant)
signal pass_parameter_changed(pass_index: int, param_name: StringName, new_value: Variant)
signal pass_structure_changed(pass_index: int, bits: int)

## Structure change bits
enum Struct { SHADER = 1 << 0, NEXT_PASS = 1 << 1, RENDER_PRIORITY = 1 << 2, PARAM_SCHEMA = 1 << 3 }

const _PARAMS_PROP_PREFIX := "shader_parameter/"

## The [Shader] program used to render this material.
## [br][br]
## Equivalent to [member ShaderMaterial.shader]
@export var shader: Shader:
	set = set_shader, get = get_shader

## Sets the [PaperMaterial] to be used for the next pass.
## [br][br]
## Equivalent to [member Material.next_pass]
@export var next_pass: PaperMaterial:
	set = set_next_pass, get = get_next_pass

## Sets the render priority for objects in 3D scenes.
## [br][br]
## Equivalent to [member Material.render_priority]
@export_range(Material.RENDER_PRIORITY_MIN, Material.RENDER_PRIORITY_MAX)
var render_priority: int = 0:
	set = set_render_priority, get = get_render_priority

# Internals for aggregated pass wiring
var _chain: Array[PaperMaterial] = []
var _bound_param_cbs: Array[Callable] = []
var _bound_shader_cbs: Array[Callable] = []
var _bound_next_cbs: Array[Callable] = []
var _bound_priority_cbs: Array[Callable] = []

# "shader_parameter/<prop>" -> "<uniform_name>"
var _remap_cache: Dictionary[StringName, StringName] = {}
# "<uniform_name>" -> Variant
var _param_cache: Dictionary[StringName, Variant] = {}

func _init(s: Shader = null) -> void:
	if s != null: shader = s
	_rebuild_chain()

func _get(property: StringName) -> Variant:
	if shader:
		var uniform_name: StringName = _remap_cache.get(property, &"")
		if uniform_name:
			return get_shader_parameter(uniform_name)
	return null

func _set(property: StringName, value: Variant) -> bool:
	if not shader: return false
	
	var uniform_name: StringName = _remap_cache.get(property, &"")
	if uniform_name:
		set_shader_parameter(uniform_name, value)
		return true
	
	var prop: String = property
	if prop.begins_with(_PARAMS_PROP_PREFIX):
		uniform_name = StringName(prop.substr(_PARAMS_PROP_PREFIX.length()))
		_remap_cache[property] = uniform_name
		set_shader_parameter(uniform_name, value)
		return true
	
	return false

func _get_property_list() -> Array[Dictionary]:
	var properties: Array[Dictionary] = []
	
	if not shader: return properties
	
	properties.append({
		"name": "Shader Parameters",
		"type": TYPE_NIL,
		"usage": PROPERTY_USAGE_GROUP,
		"hint_string": _PARAMS_PROP_PREFIX,
	})
	
	var uniform_list: Array = shader.get_shader_uniform_list(true)
	var filtered_uniforms: Array = []
	filtered_uniforms.resize(uniform_list.size())
	
	var write_idx := 0
	for u: Dictionary in uniform_list:
		var prop: String = u.name
		
		if int(u.usage) & (PROPERTY_USAGE_GROUP | PROPERTY_USAGE_SUBGROUP):
			u.name = prop.replace("::", "/").capitalize()
			u.usage = PROPERTY_USAGE_SUBGROUP
			u.hint_string = _PARAMS_PROP_PREFIX
			filtered_uniforms[write_idx] = u
			write_idx += 1
			continue
		
		var uniform_name: StringName = prop
		var is_paper_texture := PaperConstants.TEX_PARAM_NAMES.has(uniform_name)
		
		if is_paper_texture: continue
		
		var prefixed_prop: String = _PARAMS_PROP_PREFIX + prop
		u.name = prefixed_prop
		u.usage = PROPERTY_USAGE_DEFAULT
		
		var cached_val = _param_cache.get(uniform_name)
		if cached_val != null:
			var type: int = u.type
			var type_cached: int = typeof(cached_val)
			var type_ok := true
			
			if type_cached != type:
				type_ok = false
				
				if type == TYPE_PACKED_VECTOR4_ARRAY and type_cached == TYPE_PACKED_FLOAT32_ARRAY:
					var arr: PackedFloat32Array = cached_val
					var arr_size := arr.size()
					var varray := PackedVector4Array()
					var i := 0
					while i + 3 < arr_size:
						varray.append(Vector4(arr[i], arr[i + 1], arr[i + 2], arr[i + 3]))
						i += 4
					_param_cache[uniform_name] = varray
					type_ok = true
			
			if type_ok and type == TYPE_OBJECT and type_cached == TYPE_OBJECT:
				var hint_class: String = u.get("hint_string", "")
				if hint_class and not (cached_val as Object).is_class(hint_class):
					type_ok = false
			
			if not type_ok:
				_param_cache[uniform_name] = _get_default_param(uniform_name)
		
		_remap_cache[StringName(prefixed_prop)] = uniform_name
		
		filtered_uniforms[write_idx] = u
		write_idx += 1
	
	filtered_uniforms.resize(write_idx)
	properties.append_array(filtered_uniforms)
	
	return properties

func _property_can_revert(property: StringName) -> bool:
	if not shader: return false
	if _remap_cache.has(property): return true
	return property == &"render_priority" or property == &"next_pass"

func _property_get_revert(property: StringName) -> Variant:
	if not shader: return null
	
	var uniform_name: StringName = _remap_cache.get(property, &"")
	if uniform_name: return _get_default_param(uniform_name)
	if property == &"render_priority": return 0
	if property == &"next_pass": return null
	return null

func _validate_property(property: Dictionary) -> void:
	if not shader and property.name in [&"next_pass", &"render_priority"]:
		property.usage = PROPERTY_USAGE_NO_EDITOR

func _get_default_param(param_name: StringName) -> Variant:
	if shader: return RenderingServer.shader_get_parameter_default(shader.get_rid(), param_name)
	return null

#region Getters and Setters
func set_shader(value: Shader) -> void:
	if shader == value: return
	if value and value.get_mode() != Shader.Mode.MODE_SPATIAL:
		push_error("Cannot set 'shader' in PaperMaterial: Only spatial shaders may be assigned.")
		return
	
	if shader and Engine.is_editor_hint():
		shader.changed.disconnect(notify_property_list_changed)
	shader = value
	if shader and Engine.is_editor_hint():
		shader.changed.connect(notify_property_list_changed)
	
	shader_changed.emit(shader)
	notify_property_list_changed()

func get_shader() -> Shader: return shader

func set_next_pass(value: PaperMaterial) -> void:
	if next_pass == value: return
	
	var pass_child: PaperMaterial = value
	while pass_child != null:
		if pass_child == self:
			push_error("Cannot set 'next_pass' in PaperMaterial: Circular reference.")
			return
		pass_child = pass_child.get_next_pass()
	
	next_pass = value
	next_pass_changed.emit(next_pass)

func get_next_pass() -> PaperMaterial: return next_pass

func set_render_priority(value: int) -> void:
	var new_priority = clampi(value, Material.RENDER_PRIORITY_MIN, Material.RENDER_PRIORITY_MAX)
	if render_priority == new_priority: return
	render_priority = new_priority
	render_priority_changed.emit(render_priority)

func get_render_priority() -> int: return render_priority
#endregion

#region Public API
## Returns the set value for the associated shader parameter, or the default one if not set.
## [br][br]
## Equivalent to [method ShaderMaterial.get_shader_parameter].
func get_shader_parameter(param_name: StringName) -> Variant:
	var value = _param_cache.get(param_name)
	if value == null:
		value = _get_default_param(param_name)
	return value

## Sets the value for the associated shader parameter, or clears it if [param value] is [code]null[/code].
## [br][br]
## Equivalent to [method ShaderMaterial.set_shader_parameter].
func set_shader_parameter(param_name: StringName, value: Variant) -> void:
	if value == null:
		if _param_cache.erase(param_name):
			parameter_changed.emit(param_name, null)
	else:
		_param_cache[param_name] = value 
		parameter_changed.emit(param_name, value)

## Gets the [PaperMaterial] within a pass chain.
## Setting [param index] to [code]0[/code] returns the root [PaperMaterial],
## [code]1[/code] returns [member next_pass], [code]2[/code] returns
## [member next_pass]'s [member next_pass], and so on.
func get_pass(index: int) -> PaperMaterial:
	return _chain[index] if absi(index) < _chain.size() else null

## Returns a duplicate of the [PaperMaterial].
## Enabling [param deep] duplicates the [member next_pass] chain if there is one.
func duplicate_material(deep: bool = false) -> PaperMaterial:
	var duped := PaperMaterial.new()
	duped.shader = shader
	duped.render_priority = render_priority
	duped._param_cache = _param_cache.duplicate(true)
	duped._remap_cache = _remap_cache.duplicate(true)
	duped.next_pass = (next_pass.duplicate_material(true) if (deep and next_pass) else next_pass)
	return duped
#endregion

# Build shader material chain for a PaperPolygon2D or PaperSprite2D 
func _create_shader_material_for_renderable(r: Object, type: PaperConstants.RenderableType) -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = shader
	material.render_priority = render_priority
	
	for param_name: StringName in _param_cache:
		var v = _param_cache[param_name]
		material.set_shader_parameter(param_name, v)
	
	if r:
		var calls: Array[Callable]
		var override_values: Array
		var override_names: Array[StringName]
		var override_types: PackedByteArray
		if type == PaperPolygon2D._TYPE:
			var pp: PaperPolygon2D = r
			calls = PaperPolygon2D._PARAM_CALLS
			override_values = pp.material_parameter_overrides
			override_names = pp.material_parameter_override_names
			override_types = pp.material_parameter_override_types
		else:
			var spr: PaperSprite2D = r
			calls = PaperSprite2D._PARAM_CALLS
			override_values = spr.material_parameter_overrides
			override_names = spr.material_parameter_override_names
			override_types = spr.material_parameter_override_types
		
		for i: int in PaperConstants.TEX_ALL_PARAMS:
			material.set_shader_parameter(PaperConstants.PAPER_PARAMS[i], calls[i].call(r))
		for i: int in override_values.size():
			if PaperConstants._mpo_is_instance(override_types[i]): continue
			material.set_shader_parameter(override_names[i], override_values[i])
	
	if next_pass:
		material.next_pass = next_pass._create_shader_material_for_renderable(r, type)
	return material

#region Aggregated Pass Wiring
func _rebuild_chain() -> void:
	# Disconnect any previous bound callables
	for i: int in _chain.size():
		var p: PaperMaterial = _chain[i]
		if is_instance_valid(p):
			var c: Callable
			if i < _bound_param_cbs.size():
				c = _bound_param_cbs[i]
				if c and p.parameter_changed.is_connected(c):
					p.parameter_changed.disconnect(c)
			if i < _bound_shader_cbs.size():
				c = _bound_shader_cbs[i]
				if c and p.shader_changed.is_connected(c):
					p.shader_changed.disconnect(c)
			if i < _bound_next_cbs.size():
				c = _bound_next_cbs[i]
				if c and p.next_pass_changed.is_connected(c):
					p.next_pass_changed.disconnect(c)
			if i < _bound_priority_cbs.size():
				c = _bound_priority_cbs[i]
				if c and p.render_priority_changed.is_connected(c):
					p.render_priority_changed.disconnect(c)
	_chain.clear()
	_bound_param_cbs.clear()
	_bound_shader_cbs.clear()
	_bound_next_cbs.clear()
	_bound_priority_cbs.clear()
	
	# Build fresh chain
	var current: PaperMaterial = self
	var idx := 0
	while is_instance_valid(current):
		if current == self and idx != 0:
			push_error("PaperMaterial `next_pass` chain has a cycle. Stopping aggregation.")
			break
		_chain.append(current)
		
		# Bind with pass index baked in
		var c_param := _on_pass_param_changed.bind(idx)
		var c_shader := _on_pass_shader_changed.bind(idx)
		var c_next := _on_pass_next_pass_changed.bind(idx)
		var c_prio := _on_pass_render_priority_changed.bind(idx)
		
		current.parameter_changed.connect(c_param)
		current.shader_changed.connect(c_shader)
		current.next_pass_changed.connect(c_next)
		current.render_priority_changed.connect(c_prio)
		
		_bound_param_cbs.append(c_param)
		_bound_shader_cbs.append(c_shader)
		_bound_next_cbs.append(c_next)
		_bound_priority_cbs.append(c_prio)
		
		current = current.next_pass
		idx += 1

func _on_pass_param_changed(param_name: StringName, value: Variant, pass_idx: int) -> void:
	pass_parameter_changed.emit(pass_idx, param_name, value)

func _on_pass_shader_changed(_shader: Shader, pass_idx: int) -> void:
	pass_structure_changed.emit(pass_idx, Struct.SHADER | Struct.PARAM_SCHEMA)

func _on_pass_next_pass_changed(_next_pass: PaperMaterial, pass_idx: int) -> void:
	pass_structure_changed.emit(pass_idx, Struct.NEXT_PASS)
	_rebuild_chain()

func _on_pass_render_priority_changed(_priority: int, pass_idx: int) -> void:
	pass_structure_changed.emit(pass_idx, Struct.RENDER_PRIORITY)
#endregion
