@tool
extends Resource
class_name Transform3DInterface

## Specialized resource that abstracts away from [Transform3D]'s default interface in the inspector,
## allowing more intuitive euler, [Quaternion], and [Basis] control.
##
## [b]Note:[/b] When stored in [Node]s or other kinds of [Object]s, it's recommended to use
##              [method Resource.duplicate] and/or enable [method Resource.resource_local_to_scene]
##              to avoid scenarios where the same [Transform3DInterface] is accidentally shared
##              between multiple instances.

enum _Dirty { NONE = 0, LOCAL_TRANSFORM = 1, EULER_ROTATION_AND_SCALE = 2 }

static var _DISPLAY_PROPERTIES: Dictionary[StringName, Callable] = {
	&"position":           func(_rem: int) -> bool: return true,
	&"rotation":           func(rem: int)  -> bool: return rem == Node3D.ROTATION_EDIT_MODE_EULER,
	&"quaternion":         func(rem: int)  -> bool: return rem == Node3D.ROTATION_EDIT_MODE_QUATERNION,
	&"basis":              func(rem: int)  -> bool: return rem == Node3D.ROTATION_EDIT_MODE_BASIS,
	&"scale":              func(rem: int)  -> bool: return rem != Node3D.ROTATION_EDIT_MODE_BASIS,
	&"rotation_order":     func(rem: int)  -> bool: return rem == Node3D.ROTATION_EDIT_MODE_EULER,
	&"rotation_edit_mode": func(_rem: int) -> bool: return true,
}:
	set(value): return
static var _DISPLAY_KEYS: Array[StringName] = _DISPLAY_PROPERTIES.keys():
	set(value): return
static var _DISPLAY_CALLS: Array[Callable] = _DISPLAY_PROPERTIES.values():
	set(value): return

@export_storage var _dirty: int = _Dirty.NONE
@export_storage var _transform := Transform3D.IDENTITY
@export_storage var _rotation := Vector3.ZERO
@export_storage var _scale := Vector3.ONE
@export_storage var _rotation_order := EULER_ORDER_YXZ
@export_storage var _rotation_edit_mode := Node3D.ROTATION_EDIT_MODE_EULER

## The [Transform3D] value of this resource.
## Represents this resource's combined [member position], [member rotation], and [member scale].
var transform := Transform3D.IDENTITY:
	set = set_transform, get = get_transform

## Position (translation) of [member transform], equivalent to [member Transform3D.origin].
var position := Vector3.ZERO:
	set = set_position, get = get_position

## Rotation of [member transform] as [url=https://en.wikipedia.org/wiki/Euler_angles]Euler angles[/url], in radians.
## This value is obtained from [member basis]'s rotation.
## [br][br]
## 　• The [member Vector3.x] is the angle around the local X axis (pitch);
## [br]
## 　• The [member Vector3.y] is the angle around the local Y axis (yaw);
## [br]
## 　• The [member Vector3.z] is the angle around the local Z axis (roll).
## [br][br]
## The order of each consecutive rotation can be changed with [member rotation_order] (see [enum EulerOrder] constants).
## By default, the YXZ convention is used ([enum EulerOrder.EULER_ORDER_YXZ]).
## [br][br]
## [b]Note:[/b] This property is edited in degrees in the inspector.
##              If you want to use degrees in a script, use [member rotation_degrees].
var rotation := Vector3.ZERO:
	set = set_rotation, get = get_rotation

## The [member rotation] property, in degrees instead of radians.
## [br][br]
## [b]Note:[/b] This is [b]not[/b] the property available in the Inspector dock.
var rotation_degrees := Vector3.ZERO:
	set = set_rotation_degrees, get = get_rotation_degrees

## Rotation of [member transform] represented as a [Quaternion].
## This value is obtained from [member basis]'s rotation.
## [br][br]
## [b]Note:[/b] Quaternions are much more suitable for 3D math but are less intuitive.
##              Setting this property can be useful for interpolation (see [method Quaternion.slerp]).
var quaternion := Quaternion.IDENTITY:
	set = set_quaternion, get = get_quaternion

## Basis of the [member transform] property.
## Represents the rotation, scale, and shear of this resource.
var basis := Basis.IDENTITY:
	set = set_basis, get = get_basis

## Scale of this resource's [member transform] property.
## This value is obtained from [member basis]'s scale.
var scale := Vector3.ONE:
	set = set_scale, get = get_scale

## How the rotation and scale are displayed in the Inspector dock.
var rotation_edit_mode := Node3D.ROTATION_EDIT_MODE_EULER:
	set = set_rotation_edit_mode, get = get_rotation_edit_mode

## The axis [member rotation] order of the rotation property.
## The final orientation is calculated by rotating around the local X, Y, and Z axis in this order.
var rotation_order := EULER_ORDER_YXZ:
	set = set_rotation_order, get = get_rotation_order

static func _static_init() -> void:
	_DISPLAY_PROPERTIES.make_read_only()
	_DISPLAY_KEYS.make_read_only()
	_DISPLAY_CALLS.make_read_only()

#region Private Helpers

#region Update Functions
func _update_transform() -> void:
	_transform.basis = Basis.from_euler(_rotation, _rotation_order) * Basis().scaled(_scale)
	_clear_dirty_bits(_Dirty.LOCAL_TRANSFORM)

func _update_rotation_and_scale() -> void:
	_scale = _transform.basis.get_scale()
	_rotation = _get_euler_normalized(_transform.basis, _rotation_order)
	_clear_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE)

func _test_dirty_bits(bits: int) -> bool:
	return (_dirty & bits) != 0

func _set_dirty_bits(bits: int) -> void:
	_dirty |= bits

func _clear_dirty_bits(bits: int) -> void:
	_dirty &= ~bits

func _replace_dirty_mask(mask: int) -> void:
	_dirty = mask
#endregion

#region Basis Math
static func _get_euler_normalized(b: Basis, p_order: EulerOrder) -> Vector3:
	var m := b.orthonormalized();
	
	var det := m.determinant()
	if det < 0.0: m = m.scaled(Vector3(-1, -1, -1));
	
	return m.get_euler(p_order)

static func _basis_from_quaternion(q: Quaternion, p_scale := Vector3.ONE) -> Basis:
	var b := Basis(q)
	b.x *= p_scale.x
	b.y *= p_scale.y
	b.z *= p_scale.z
	return b
#endregion

#endregion

#region Getters and Setters

#region Transform
func set_transform(value: Transform3D) -> void:
	if _transform == value: return
	_transform = value
	_replace_dirty_mask(_Dirty.EULER_ROTATION_AND_SCALE)
	emit_changed()

func get_transform() -> Transform3D:
	if _test_dirty_bits(_Dirty.LOCAL_TRANSFORM):
		_update_transform()
	return _transform
#endregion

#region Position
func set_position(value: Vector3) -> void:
	if _transform.origin == value: return
	_transform.origin = value
	emit_changed()

func get_position() -> Vector3:
	return _transform.origin
#endregion

#region Rotation (Euler)
func set_rotation(value: Vector3) -> void:
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_scale = _transform.basis.get_scale()
		_clear_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE)
	
	_rotation = value
	_replace_dirty_mask(_Dirty.LOCAL_TRANSFORM)
	emit_changed()

func get_rotation() -> Vector3:
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_update_rotation_and_scale()
	return _rotation

func set_rotation_degrees(value: Vector3) -> void:
	var rad := Vector3(
		deg_to_rad(value.x),
		deg_to_rad(value.y),
		deg_to_rad(value.z)
	)
	set_rotation(rad)

func get_rotation_degrees() -> Vector3:
	var rad := get_rotation()
	return Vector3(
		rad_to_deg(rad.x),
		rad_to_deg(rad.y),
		rad_to_deg(rad.z)
	)
#endregion

#region Quaternion
func set_quaternion(value: Quaternion) -> void:
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_scale = _transform.basis.get_scale()
		_clear_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE)
	
	_transform.basis = _basis_from_quaternion(value.normalized(), _scale)
	
	_rotation = _get_euler_normalized(_transform.basis, _rotation_order)
	
	_replace_dirty_mask(_Dirty.NONE)
	emit_changed()

func get_quaternion() -> Quaternion:
	return get_transform().basis.get_rotation_quaternion()
#endregion

#region Basis
func set_basis(value: Basis) -> void:
	if _transform.basis == value: return
	_transform.basis = value
	_replace_dirty_mask(_Dirty.EULER_ROTATION_AND_SCALE)
	emit_changed()

func get_basis() -> Basis:
	return get_transform().basis
#endregion

#region Scale
func set_scale(value: Vector3) -> void:
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_rotation = _get_euler_normalized(_transform.basis, _rotation_order)
		_clear_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE)
	
	const EPS := 0.0001
	_scale = Vector3(value.x if absf(value.x) > EPS else (EPS if value.x >= 0.0 else -EPS),
					 value.y if absf(value.y) > EPS else (EPS if value.y >= 0.0 else -EPS),
					 value.z if absf(value.z) > EPS else (EPS if value.z >= 0.0 else -EPS))
	
	_replace_dirty_mask(_Dirty.LOCAL_TRANSFORM)
	emit_changed()

func get_scale() -> Vector3:
	if _rotation_edit_mode == Node3D.ROTATION_EDIT_MODE_BASIS:
		return get_transform().basis.get_scale()
	
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_update_rotation_and_scale()
	return _scale
#endregion

#region Rotation Order
func set_rotation_order(value: EulerOrder) -> void:
	if _rotation_order == value: return
	
	var transform_changed := false
	
	if _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_update_rotation_and_scale()
	elif _test_dirty_bits(_Dirty.LOCAL_TRANSFORM):
		_rotation = _get_euler_normalized(Basis.from_euler(_rotation, _rotation_order), value)
		transform_changed = true
	else:
		_set_dirty_bits(_Dirty.LOCAL_TRANSFORM)
		transform_changed = true
	
	_rotation_order = value
	
	if transform_changed: emit_changed()

func get_rotation_order() -> EulerOrder:
	return _rotation_order
#endregion

#region Rotation Edit Mode
func set_rotation_edit_mode(value: Node3D.RotationEditMode) -> void:
	if _rotation_edit_mode == value: return
	
	var was_basis := (_rotation_edit_mode == Node3D.ROTATION_EDIT_MODE_BASIS)
	var transform_changed := false
	
	if was_basis and not _test_dirty_bits(_Dirty.LOCAL_TRANSFORM):
		var scl := _transform.basis.get_scale()
		var b := _transform.basis.orthonormalized()
		_transform.basis = b.scaled_local(scl)
		transform_changed = true
	
	_rotation_edit_mode = value
	
	if value == Node3D.ROTATION_EDIT_MODE_EULER and _test_dirty_bits(_Dirty.EULER_ROTATION_AND_SCALE):
		_update_rotation_and_scale()
	
	if transform_changed: emit_changed()
	
	notify_property_list_changed()

func get_rotation_edit_mode() -> Node3D.RotationEditMode:
	return _rotation_edit_mode
#endregion

#endregion

#region Property Management

func _validate_property(property: Dictionary) -> void:
	_validate_property_from_name(property, property.name)

func _validate_property_from_name(property: Dictionary, prop_name: StringName) -> void:
	var prop_call = _DISPLAY_PROPERTIES.get(prop_name)
	if prop_call is Callable:
		if prop_name == &"rotation":
			property.hint = PROPERTY_HINT_RANGE
			property.hint_string = "-360,360,0.1,or_greater,or_less,radians_as_degrees"
		elif prop_name == &"rotation_order":
			property.hint = PROPERTY_HINT_ENUM
			property.hint_string = "XYZ,XZY,YXZ,YZX,ZXY,ZYX"
		elif prop_name == &"rotation_edit_mode":
			property.hint = PROPERTY_HINT_ENUM
			property.hint_string = "Euler,Quaternion,Basis"
		property.usage = (
			PROPERTY_USAGE_EDITOR
			if ((prop_call as Callable).call(_rotation_edit_mode) as bool)
			else PROPERTY_USAGE_NONE
		)

func _property_can_revert(property: StringName) -> bool:
	var revert_property = _property_get_revert(property)
	if revert_property != null: return get(property) != revert_property
	return false

func _property_get_revert(property: StringName) -> Variant:
	const DISPLAY_REVERT: Dictionary[StringName, Variant] = {
		&"position":           Vector3.ZERO,
		&"rotation":           Vector3.ZERO,
		&"quaternion":         Quaternion.IDENTITY,
		&"basis":              Basis.IDENTITY,
		&"scale":              Vector3.ONE,
		&"rotation_order":     EULER_ORDER_YXZ,
		&"rotation_edit_mode": Node3D.ROTATION_EDIT_MODE_EULER
	}
	return DISPLAY_REVERT.get(property)

## Retrieves a custom property list designed for more easily integrating with custom
## classes that utilize [method Object._get_property_list].
## [br][br]
## There's also an optional [param prefix] that can be added to the properties' 
## [code]name[/code] entry.
func get_display_property_list(prefix: String = "") -> Array[Dictionary]:
	var properties: Array[Dictionary] = []
	properties.resize(get_display_property_list_size())
	
	var p: int = 0
	for prop_name: StringName in _DISPLAY_KEYS:
		var property := {}
		_validate_property_from_name(property, prop_name)
		
		if (property.usage as int == PROPERTY_USAGE_EDITOR):
			property.name = prefix + str(prop_name)
			property.type = typeof(get(prop_name))
			properties[p] = property
			p += 1
	
	return properties

## Retrieves the amount of entries that would be output by [method get_display_property_list].
## Useful for pre-allocation.
func get_display_property_list_size() -> int:
	var size: int = 0
	for show: Callable in _DISPLAY_CALLS:
		if (show.call(_rotation_edit_mode) as bool): size += 1
	return size

#endregion
