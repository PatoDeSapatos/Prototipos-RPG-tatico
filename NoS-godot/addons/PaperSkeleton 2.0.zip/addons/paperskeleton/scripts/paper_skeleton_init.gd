@tool
extends EditorPlugin

const SkeletonGizmo = preload("uid://paperskelgiz")
const RenderableInspector = preload("uid://paperskelins")
var gizmo_plugin: EditorNode3DGizmoPlugin = SkeletonGizmo.new()
var renderable_inspector: EditorInspectorPlugin = RenderableInspector.new()

func _enter_tree() -> void:
	_register_project_settings()
	add_custom_type("PaperSkeleton", "Skeleton3D", preload("uid://papersklbgds"), preload("uid://papersklbico"))
	add_custom_type("PaperPolygon2D", "Polygon2D", preload("uid://paperpolygds"), preload("uid://paperpolyico"))
	add_custom_type("PaperSprite2D", "Sprite2D", preload("uid://papersprtgds"), preload("uid://papersprtico"))
	add_custom_type("PaperBoneAttachment3D", "Node3D", preload("uid://paperatchgds"), preload("uid://paperatchico"))
	add_custom_type("PaperMaterial", "Resource", preload("uid://paperskelmat"), preload("uid://papermaticon"))
	add_custom_type("SimplePaperBoneModifier3D", "SkeletonModifier3D", preload("uid://papermdfsgds"), preload("uid://papermdfsico"))
	add_node_3d_gizmo_plugin(gizmo_plugin)
	add_inspector_plugin(renderable_inspector)

func _exit_tree() -> void:
	remove_custom_type("PaperSkeleton")
	remove_custom_type("PaperPolygon2D")
	remove_custom_type("PaperSprite2D")
	remove_custom_type("PaperBoneAttachment3D")
	remove_custom_type("PaperMaterial")
	remove_custom_type("SimplePaperBoneModifier3D")
	remove_node_3d_gizmo_plugin(gizmo_plugin)
	remove_inspector_plugin(renderable_inspector)

static func _register_project_settings() -> void:
	ProjectSettings.add_property_info({
		"name": PaperConstants.DEFAULT_SHADER_PS_KEY,
		"type": TYPE_STRING,
		"hint": PROPERTY_HINT_FILE,
		"hint_string": "*.gdshader,*.tres"
	})
	
	if not ProjectSettings.has_setting(PaperConstants.DEFAULT_SHADER_PS_KEY):
		ProjectSettings.set_setting(PaperConstants.DEFAULT_SHADER_PS_KEY, PaperConstants.DEFAULT_SHADER_UID)
	ProjectSettings.set_initial_value(PaperConstants.DEFAULT_SHADER_PS_KEY, PaperConstants.DEFAULT_SHADER_UID)
