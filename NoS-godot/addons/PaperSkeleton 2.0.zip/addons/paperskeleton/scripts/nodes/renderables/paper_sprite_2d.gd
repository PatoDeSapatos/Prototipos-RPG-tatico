@tool
@icon("uid://papersprtico")
extends Sprite2D
class_name PaperSprite2D

## An extended version of [Sprite2D] designed to integrate with [PaperSkeleton].
## This node mirrors the 2D sprite as a skinned 3D quad within a [MeshInstance3D] and keeps shader
## parameters in sync in real time.
## [br][br]
## Like [PaperPolygon2D], GDScript cannot override native setters, so this class exposes a set of
## [code]set_[VALUE]_and_update()[/code] helpers that you should use from code to ensure the 3D
## shader parameters and generated mesh stay synchronized with engine properties.
## The editor property setters are already wired to use these helpers for you.
## [br][br]
## [b]NOTE:[/b] Unlike [PaperPolygon2D], changing the size of [member Sprite2D.texture] will
##              necessitate a quick mesh reconstruction to match the new bounds of the sprite.
##              This can be avoided by either using a strictly defined size for all texture changes,
##              or setting [member Sprite2D.region_enabled] to true and setting the
##              [member Sprite2D.region_rect] to your preferred size.
## [br][br]
## See also:[br]
## 　• [PaperPolygon2D] for polygonal sprites with arbitrary topology.[br]
## 　• [PaperSkeleton] for overall rig management and 2D→3D plumbing.[br]
## 　• [PaperMaterial] for multi-pass [ShaderMaterial] control.

const _TYPE := PaperConstants.RenderableType.SPRITE

static var _PARAM_CALLS : Array[Callable] = [
	## PAPER_ALBEDO
	func(s: PaperSprite2D) -> Texture2D: return s.texture if not s._chain_base_texture else s._chain_base_texture,
	## PAPER_ALBEDO_EXISTS
	func(s: PaperSprite2D) -> bool:      return s.texture != null,
	## PAPER_ALBEDO_FLIP
	func(s: PaperSprite2D) -> Texture2D: return s.flip_texture,
	## PAPER_ALBEDO_FLIP_EXISTS
	func(s: PaperSprite2D) -> bool:      return s.flip_texture != null,
	## PAPER_COLOR
	func(s: PaperSprite2D) -> Color:     return s.modulate * s.self_modulate,
	## PAPER_UV_SCALE
	func(s: PaperSprite2D) -> Vector2:   return Vector2(-1.0 if s.flip_h else 1.0,
														-1.0 if s.flip_v else 1.0),
	## PAPER_UV_OFFSET
	func(s: PaperSprite2D) -> Vector2:   return s.get_uv_offset(),
	## PAPER_UV_ROTATION
	func(_s: PaperSprite2D) -> float:    return 0.0,
	## PAPER_UV_MASK
	func(s: PaperSprite2D) -> Vector4:   return s.get_uv_mask(),
	## PAPER_USE_UV_MASK
	func(s: PaperSprite2D) -> bool:      return s.get_uv_masking()
]:
	set(value): return

## Collection of properties that are stored by display entries.
## Exists as a [Dictionary] pointing to revert values to prevent cluttered serialization.
const DISPLAY_ENTRY_PROPERTIES: Dictionary[StringName, Variant] = {
	&"modulate":       Color.WHITE,
	&"self_modulate":  Color.WHITE,
	&"flip_h":         false, 
	&"flip_v":         false,
	&"uv_masking":     true,
	&"texture":        null,
	&"flip_texture":   null,
	&"region_enabled": false,
	&"region_rect":    Rect2(),
	&"hframes":        1,
	&"vframes":        1,
	&"frame":          0,
	&"centered":       true,
	&"offset":         Vector2.ZERO
}

static var _SETTER_OVERRIDES: Dictionary[StringName, Callable] = {
	&"modulate":       func(s: PaperSprite2D, value): s.set_modulate_and_update(value),
	&"self_modulate":  func(s: PaperSprite2D, value): s.set_self_modulate_and_update(value),
	&"flip_h":         func(s: PaperSprite2D, value): s.set_flip_h_and_update(value), 
	&"flip_v":         func(s: PaperSprite2D, value): s.set_flip_v_and_update(value),
	&"texture":        func(s: PaperSprite2D, value): s.set_texture_and_update(value),
	&"region_enabled": func(s: PaperSprite2D, value): s.set_region_enabled_and_update(value),
	&"region_rect":    func(s: PaperSprite2D, value): s.set_region_rect_and_update(value),
	&"hframes":        func(s: PaperSprite2D, value): s.set_hframes_and_update(value),
	&"vframes":        func(s: PaperSprite2D, value): s.set_vframes_and_update(value),
	&"frame":          func(s: PaperSprite2D, value): s.set_frame_and_update(value),
	&"centered":       func(s: PaperSprite2D, value): s.set_centered_and_update(value),
	&"offset":         func(s: PaperSprite2D, value): s.set_offset_and_update(value),
	&"z_index":        func(s: PaperSprite2D, value): s.set_z_index_and_update(value),
	&"z_as_relative":  func(s: PaperSprite2D, value): s.set_z_as_relative_and_update(value)
}:
	set(value): return

# Renderable common fields
var _skeleton: PaperSkeleton = null:
	set(value):
		if _skeleton == value: return
		_skeleton = value
		if _skeleton: _bind_effective_material()
		notify_property_list_changed()

var _parent_bone_2d: Bone2D = null

## Reference to the generated [MeshInstance3D]. Do not assign manually.
var _mesh_instance_3d: MeshInstance3D = null
## Optional MeshInstance3D for the border effect slot.
var _border_mesh_instance_3d: MeshInstance3D = null
## Optional MeshInstance3D for the group effect slot.
var _group_mesh_instance_3d: MeshInstance3D = null

## Z index assigned by [PaperSkeleton] to order renderables in 3D.
var _z_index_paper: int = -1

## Per-group micro index in [code][0..1][/code] range to reduce Z-fighting in [member PaperSkeleton.group_material] effects.
var _z_index_micro_group: float = 0.5

var _effective_paper_material: PaperMaterial = null
var _effective_border_paper_material: PaperMaterial = null
var _effective_group_paper_material: PaperMaterial = null

var _mesh_update_pending: bool = false

@warning_ignore("unused_private_class_variable")
var _paper_param_override_flags: int = 0
@warning_ignore("unused_private_class_variable")
@export_storage var _original_visibility_layer: int = 1

# AtlasTexture tracking
var _atlas_chain: Array[AtlasTexture] = []
var _atlas_changed_connected: bool = false

# Cached flattened values (in base-texture pixel space)
var _atlas_update_pending: bool = false
var _cached_offset := Vector2.ZERO
var _cached_mask := Vector4(0.0, 0.0, 1.0, 1.0)
var _cached_rect := Rect2()

# UV caching split into chain-level and sprite-level pieces
var _chain_base_size := Vector2.ZERO
var _chain_origin_in_base := Vector2.ZERO
var _chain_parent_size := Vector2.ZERO
var _chain_mask_min := Vector2.ZERO
var _chain_mask_max := Vector2.ONE
var _sprite_uv_dirty: bool = true
var _chain_dirty: bool = true
var _chain_base_texture: Texture2D = null
var _chain_base_changed: bool = false

# Transform cache for efficient updates
var _rel_local_cache: Transform2D = Transform2D.IDENTITY
var _rel_cache_valid: bool = false
var _rel_starting_check: bool = true

## Active display entry name for this [PaperSprite2D].
## [br][br]
## Display entries are named snapshots of selected visual properties and material parameter overrides.
## They let you quickly swap properties related to appearance (e.g., colors, textures, region, frames, UV flips, material parameter overrides)
## in the editor or at runtime by selecting a different entry name.
## [br][br]
## Setting this value will switch the display entry to a matching one.
## If the name doesn't match any entry, it will instead select the first one in the order.
## This is of course assuming at least one entry exists, in which case, setting this value will change nothing.
## [br][br]
## [b]Note:[/b] Remember to press the save button in the inspector before switching back to other entries, so that your changes aren't accidentally lost.
## [br][br]
## You can manage entries with:[br]
## 　• [method add_display_entry] / [method remove_display_entry] to add or remove display entries.[br]
## 　• [method rename_display_entry] to rename the display entry to something else (may lead to bugs if this name is already keyframed).[br]
## 　• [method move_display_entry] to reorder the display entry to a different position in the inspector dropdown.[br]
## 　• [method save_display_entry] to store the current visual properties into the currently selected entry.[br]
## 　• [method is_display_entry_dirty] to check if the current visual properties differ from the currently selected entry.
var display_entry: StringName = &"":
	set = set_display_entry, get = get_display_entry

@warning_ignore_start("unused_private_class_variable")
@export_storage var _display_entry_value: StringName = &""
@export_storage var _display_entry_data: Dictionary[StringName, Array] = {}
@export_storage var _display_entry_order: Array[StringName] = []
@warning_ignore_restore("unused_private_class_variable")

## Level of linear subdivision for the equivalent mesh.
## Higher values increase vertex count for smoother deformations with certain effects.
var subdivision_level: int = 0:
	set = set_subdivision_level, get = get_subdivision_level

## Texture used on the alternate side of the [PaperSkeleton] rig.
## [br][br]
## [b]Note:[/b] Unlike [member Sprite2D.texture], this property does not support [AtlasTexture]s.
##              Additionally, UV offsets and cropping from both [member Sprite2D.texture]'s
##              [AtlasTexture] and [member Sprite2D.region_rect] will be similarly applied to
##              [member flip_texture] in default shader setups.
var flip_texture: Texture2D = null:
	set = set_flip_texture, get = get_flip_texture

## Whether or not the edges of textures should be masked.
## With the exception of specific visual effects that require texture stretching, it's recommended to leave this enabled.
var uv_masking: bool = true:
	set = set_uv_masking, get = get_uv_masking

## Defines the type of resource used to override the material.
var override_mode := PaperConstants.OverrideMode.PAPER_MATERIAL:
	set = set_override_mode, get = get_override_mode

## Optional local [PaperMaterial] override.
## If null, falls back to [member PaperSkeleton.material].
var paper_material_override: PaperMaterial = null:
	set = set_paper_material_override, get = get_paper_material_override

## Optional [ShaderMaterial] override. Any changes to [member Sprite2D.texture] and
## [member flip_texture] will still be applied to the material, so use with caution.
## [br][br]
## This property primarily exists as a means to squeeze in some extra performance, as
## an abundance of redundant materials can add some unnecessary overhead.
## [br][br]
## [b]Note:[/b] [AtlasTexture]s applied to [member Sprite2D.texture] are configured via
##              specialized instance uniforms that adjust the UV, meaning that setups
##              involving [AtlasTexture]s should remain compatible, as long as they share
##              the same atlas.
var shader_material_override: ShaderMaterial = null:
	set = set_shader_material_override, get = get_shader_material_override

## Disabling this property makes the border mesh not appear when [member PaperSkeleton.border_material] is set.
## Useful for reducing overhead when the border mesh shows no visual difference.
var border_mesh_enabled := true:
	set = set_border_mesh_enabled, get = get_border_mesh_enabled

## Border mesh equivalent to [member paper_material_override].
## Draws border mesh even if [member PaperSkeleton.border_material] is not defined.
var border_paper_material_override: PaperMaterial = null:
	set = set_border_paper_material_override, get = get_border_paper_material_override

## Border mesh equivalent to [member shader_material_override].
## Draws border mesh even if [member PaperSkeleton.border_material] is not defined.
var border_shader_material_override: ShaderMaterial = null:
	set = set_border_shader_material_override, get = get_border_shader_material_override

## Disabling this property makes the group mesh not appear when [member PaperSkeleton.group_material] is set.
## Useful for reducing overhead when the group mesh shows no visual difference.
var group_mesh_enabled := true:
	set = set_group_mesh_enabled, get = get_group_mesh_enabled

## Group mesh equivalent to [member paper_material_override].
## Draws group mesh even if [member PaperSkeleton.group_material] is not defined.
var group_paper_material_override: PaperMaterial = null:
	set = set_group_paper_material_override, get = get_group_paper_material_override

## Group mesh equivalent to [member shader_material_override].
## Draws group mesh even if [member PaperSkeleton.group_material] is not defined.
var group_shader_material_override: ShaderMaterial = null:
	set = set_group_shader_material_override, get = get_group_shader_material_override

## When set, this sprite copies the 3D Z-index from the referenced renderable. Use this to keep
## multiple sprites in a fixed draw order block if desired, though be aware of potential Z-fighting
## when setup incorrectly.
var index_target: Node = null:
	set = set_index_target, get = get_index_target

## Index used for draw order grouping when [member PaperSkeleton.group_material] is set.
var group_index_target: Node = null:
	set = set_group_index_target, get = get_group_index_target

## Values for material parameter overrides.
## [br][br]
## For proper updates, assign the values with [method set_material_parameter_override].
@export_storage var material_parameter_overrides: Array = []

## Names for material parameter overrides.
## [br][br]
## For proper updates, assign the values with [method set_material_parameter_override_name].
@export_storage var material_parameter_override_names: Array[StringName] = []

## Types + flags for material parameter overrides. Contains encoded types, instance toggles, and array type toggles.
## [br][br]
## For proper updates and encoding/decoding, use:[br]
## 　• [enum PaperConstants.UniformType]: [method set_material_parameter_override_type]/[method get_material_parameter_override_type][br]
## 　• Instance toggle: [method set_material_parameter_override_instance]/[method get_material_parameter_override_instance][br]
## 　• Array type toggle: [method set_material_parameter_override_array]/[method get_material_parameter_override_array]
@export_storage var material_parameter_override_types: PackedByteArray = []

## Value used to resize [member material_parameter_overrides]. Shrinking the value clears uniforms on removed slots.
var material_parameter_overrides_size: int = 0:
	set = set_material_parameter_overrides_size, get = get_material_parameter_overrides_size

#region Built-in Overrides
func _init() -> void:
	_update_atlas_texture_tracking()

func _ready() -> void:
	material_parameter_override_names.resize(material_parameter_overrides_size)
	material_parameter_override_types.resize(material_parameter_overrides_size)
	PaperConstants._recompute_paper_param_override_flag_for_renderable(self, _TYPE)

static func _static_init() -> void:
	_PARAM_CALLS.make_read_only()
	_SETTER_OVERRIDES.make_read_only()

func _get_property_list() -> Array:
	return PaperConstants.get_renderable_property_list(self, _TYPE)

func _set(property: StringName, value: Variant) -> bool:
	# Material parameter overrides
	if PaperConstants.set_mpo(property, value, self, _TYPE):
		return true
	
	# If no skeleton yet, don't intercept engine setters
	if not (_skeleton and _skeleton.is_node_ready() and _skeleton.skeleton_2d):
		return false
	
	# Engine property interception for live updates
	var set_override = _SETTER_OVERRIDES.get(property)
	if set_override != null:
		(set_override as Callable).call(self, value)
		return true
	
	return false

func _get(property: StringName) -> Variant:
	return PaperConstants.get_mpo(property, material_parameter_overrides, material_parameter_override_names, material_parameter_override_types)

func _property_can_revert(property: StringName) -> bool:
	return PaperConstants.can_revert_renderable_property(property, self, _TYPE)

func _property_get_revert(property: StringName) -> Variant:
	return PaperConstants.get_revert_renderable_property(property, self, _TYPE)

func _validate_property(property: Dictionary) -> void:
	var prop: StringName = property.name
	if prop == &"reconstruct_mesh_action":
		if (!_skeleton or !_skeleton.skeleton_2d):
			property.usage = PROPERTY_USAGE_NO_EDITOR
	elif prop == &"material_parameter_override_types":
		if material_parameter_override_types.is_empty():
			property.usage = PROPERTY_USAGE_NONE

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		if not _skeleton or not is_node_ready(): return
		_relative_transform_check()
	elif what == NOTIFICATION_LOCAL_TRANSFORM_CHANGED:
		if not _skeleton or not is_node_ready(): return
		_skeleton._update_sprite_transform(self)
	elif what == NOTIFICATION_VISIBILITY_CHANGED:
		var vis := is_visible_in_tree()
		if _mesh_instance_3d:
			_mesh_instance_3d.visible = vis
		if _border_mesh_instance_3d:
			_border_mesh_instance_3d.visible = vis
		if _group_mesh_instance_3d:
			_group_mesh_instance_3d.visible = vis
	elif what == NOTIFICATION_PREDELETE:
		_disconnect_atlas_signal()
	elif what == NOTIFICATION_PARENTED:
		if _skeleton: _refresh_parent_bone_cache()
	elif what == NOTIFICATION_UNPARENTED:
		_parent_bone_2d = null
#endregion

#region AtlasTexture Support
func _connect_atlas_signal() -> void:
	if _atlas_changed_connected:
		return
	for at in _atlas_chain:
		if at and not at.changed.is_connected(_on_atlas_texture_changed):
			at.changed.connect(_on_atlas_texture_changed)
	_atlas_changed_connected = _atlas_chain.size() > 0

func _disconnect_atlas_signal() -> void:
	if not _atlas_changed_connected:
		return
	for at in _atlas_chain:
		if at and at.changed.is_connected(_on_atlas_texture_changed):
			at.changed.disconnect(_on_atlas_texture_changed)
	_atlas_changed_connected = false

func _gather_atlas_chain() -> void:
	_atlas_chain.clear()
	var t := texture
	while t is AtlasTexture:
		var at: AtlasTexture = t
		_atlas_chain.append(at)
		t = at.atlas

func _update_atlas_texture_tracking() -> void:
	_disconnect_atlas_signal()
	_gather_atlas_chain()
	_connect_atlas_signal()
	
	# Mark caches dirty and seed them
	_chain_dirty = true
	_sprite_uv_dirty = true
	_ensure_uv_cache()
	_cached_rect = get_rect()

func _on_atlas_texture_changed() -> void:
	_schedule_atlas_refresh()

func _schedule_atlas_refresh() -> void:
	if _atlas_update_pending:
		return
	_atlas_update_pending = true
	_refresh_atlas_params.call_deferred()

func _refresh_atlas_params() -> void:
	_atlas_update_pending = false
	if not texture:
		return
	
	# Recompute chain and sprite-local UV caches
	var old_offset := _cached_offset
	var old_mask := _cached_mask
	
	if _chain_base_changed:
		update_material_paper_params(PaperConstants.TEX_MAIN_PARAMS)
	
	_chain_dirty = true
	_sprite_uv_dirty = true
	_ensure_uv_cache()
	
	if _cached_offset != old_offset or _cached_mask != old_mask:
		update_material_paper_params(PaperConstants.REGION_PARAMS)
	
	# Mesh rebuild if rect changed
	var new_rect := get_rect()
	if new_rect != _cached_rect:
		_cached_rect = new_rect
		defer_3d_mesh_reconstruction()
#endregion

#region UV Cache Recomputation
func _ensure_uv_cache() -> void:
	if _chain_dirty:
		_recompute_chain_state()
	if _sprite_uv_dirty:
		_recompute_sprite_uv()

func _recompute_chain_state() -> void:
	_chain_dirty = false
	
	if not texture:
		_chain_base_size = Vector2.ZERO
		_chain_origin_in_base = Vector2.ZERO
		_chain_parent_size = Vector2.ZERO
		_chain_mask_min = Vector2.ZERO
		_chain_mask_max = Vector2.ONE
		_chain_base_changed = (_chain_base_texture != null)
		_chain_base_texture = null
		return
	
	var chain: Array[AtlasTexture] = []
	var t: Texture2D = texture
	while t is AtlasTexture:
		chain.append(t)
		t = (t as AtlasTexture).atlas
	
	var base_tex: Texture2D = t
	_chain_base_changed = (_chain_base_texture != base_tex)
	_chain_base_texture = base_tex
	
	var base_size := (base_tex.get_size() if base_tex else Vector2.ZERO)
	_chain_base_size = base_size
	
	if base_size.x <= 0.0 or base_size.y <= 0.0:
		_chain_origin_in_base = Vector2.ZERO
		_chain_parent_size = Vector2.ZERO
		_chain_mask_min = Vector2.ZERO
		_chain_mask_max = Vector2.ONE
		return
	
	# Two parent sizes:
	# - with margins: drives the sampling rect at each level
	# - without margins: what AtlasTexture.get_size() would return (used for region.size==0 fallbacks)
	var origin_in_base := Vector2.ZERO
	var parent_size_with_margins := base_size
	var parent_size_no_margins := base_size
	
	var mask_min := Vector2(0.0, 0.0)
	var mask_max := Vector2(1.0, 1.0)
	
	for i in range(chain.size() - 1, -1, -1):
		var at: AtlasTexture = chain[i]
		
		var rpos := at.region.position
		
		# Use the "no-margins" parent size as the fallback for region.size == 0
		var rsize_nomargin := at.region.size
		if rsize_nomargin.x == 0.0: rsize_nomargin.x = parent_size_no_margins.x
		if rsize_nomargin.y == 0.0: rsize_nomargin.y = parent_size_no_margins.y
		
		# Margins only apply when region.size was explicitly set on that axis
		var mpos := at.margin.position
		var msize := Vector2(
			at.margin.size.x if at.region.size.x != 0.0 else 0.0,
			at.margin.size.y if at.region.size.y != 0.0 else 0.0
		)
		
		# Effective sampling rect in parent's pixel space (includes margins)
		var x0 := rpos.x - mpos.x
		var y0 := rpos.y - mpos.y
		var w  := rsize_nomargin.x + msize.x
		var h  := rsize_nomargin.y + msize.y
		
		# Intersect mask with this level's region (no margins), normalized to base
		var reg_min := (origin_in_base + rpos) / base_size
		var reg_max := (origin_in_base + rpos + rsize_nomargin) / base_size
		mask_min.x = maxf(mask_min.x, reg_min.x)
		mask_min.y = maxf(mask_min.y, reg_min.y)
		mask_max.x = minf(mask_max.x, reg_max.x)
		mask_max.y = minf(mask_max.y, reg_max.y)
		
		# Advance to the next outer level
		origin_in_base += Vector2(x0, y0)
		parent_size_with_margins = Vector2(w, h)
		parent_size_no_margins = rsize_nomargin
	
	# Save chain state
	_chain_origin_in_base = origin_in_base
	_chain_parent_size = parent_size_with_margins
	_chain_mask_min = mask_min
	_chain_mask_max = mask_max
	
	# Chain changed -> sprite-local UV depends on it
	_sprite_uv_dirty = true

func _recompute_sprite_uv() -> void:
	_sprite_uv_dirty = false
	
	if not texture or _chain_base_size == Vector2.ZERO:
		_cached_offset = Vector2.ZERO
		_cached_mask = Vector4(0.0, 0.0, 1.0, 1.0)
		return
	
	var origin := _chain_origin_in_base
	var disp_size := Vector2.ZERO
	
	if region_enabled:
		origin += region_rect.position
		disp_size = region_rect.size
	else:
		disp_size = texture.get_size()
	
	# Frames
	if hframes > 1 or vframes > 1:
		var frame_size := Vector2(
			disp_size.x / float(maxi(hframes, 1)),
			disp_size.y / float(maxi(vframes, 1))
		)
		var coords := frame_coords
		origin += frame_size * Vector2(coords)
		disp_size = frame_size
	
	# Flips reflect within the base image (same as original)
	if flip_h: origin.x = _chain_base_size.x - (origin.x + disp_size.x)
	if flip_v: origin.y = _chain_base_size.y - (origin.y + disp_size.y)
	
	_cached_offset = origin
	
	# Mask only for AtlasTexture chains
	if _atlas_chain.size() > 0:
		var ms := _chain_mask_max - _chain_mask_min
		_cached_mask = Vector4(_chain_mask_min.x, _chain_mask_min.y, maxf(ms.x, 0.0), maxf(ms.y, 0.0))
	else:
		_cached_mask = Vector4(0.0, 0.0, 1.0, 1.0)
#endregion

#region Material and Parameter Updates
## Updates one [enum PaperConstants.PaperParam] shader parameter on all passes.
func update_material_paper_param(paper_param: PaperConstants.PaperParam) -> void:
	PaperConstants.update_paper_param(self, paper_param, _TYPE)

## Updates multiple [enum PaperConstants.PaperParam] shader parameters at once on all passes.
func update_material_paper_params(paper_params: PackedByteArray) -> void:
	PaperConstants.update_paper_params(self, paper_params, _TYPE)

func _update_material_param_at_all_passes(param: StringName, value: Variant) -> void:
	PaperConstants.update_param_for_all_slots(self, param, value, _TYPE)

func _update_material_params_at_all_passes(param_values: Dictionary[StringName, Variant]) -> void:
	PaperConstants.update_params_map_for_all_slots(self, param_values, _TYPE)

func _update_material_param_at_pass(pass_idx: int, param_name: StringName, value: Variant) -> void:
	PaperConstants.update_param_at_slot_pass(self, PaperConstants.RenderSlot.BASE, pass_idx, param_name, value, _TYPE)

func _bind_effective_material() -> void:
	PaperConstants.bind_effective_material_for_slot(self, PaperConstants.RenderSlot.BASE, _TYPE)

func _on_mat_pass_structure_changed(pass_idx: int, bits: int) -> void:
	PaperConstants.handle_pass_structure_changed(self, PaperConstants.RenderSlot.BASE, pass_idx, bits, _effective_paper_material, _TYPE)

func _unbind_effective_material() -> void:
	PaperConstants.unbind_effective_material_for_slot(self, PaperConstants.RenderSlot.BASE, _TYPE)

func _bind_effective_border_material() -> void:
	if not _skeleton or not _border_mesh_instance_3d: return
	PaperConstants.bind_effective_material_for_slot(self, PaperConstants.RenderSlot.BORDER, _TYPE)

func _on_border_mat_pass_structure_changed(pass_idx: int, bits: int) -> void:
	PaperConstants.handle_pass_structure_changed(self, PaperConstants.RenderSlot.BORDER, pass_idx, bits, _effective_border_paper_material, _TYPE)

func _unbind_effective_border_material() -> void:
	PaperConstants.unbind_effective_material_for_slot(self, PaperConstants.RenderSlot.BORDER, _TYPE)

func _border_shader_material_at_pass(pass_idx: int) -> ShaderMaterial:
	return PaperConstants.get_material_at_pass(get_border_spatial_material(), pass_idx)

func _rebuild_border_shader_chain_from(pass_idx: int) -> void:
	PaperConstants.rebuild_chain_for_slot_from_pass(self, PaperConstants.RenderSlot.BORDER, pass_idx, _effective_border_paper_material, _TYPE)

func _update_border_material_param_at_pass(pass_idx: int, param_name: StringName, value: Variant) -> void:
	PaperConstants.update_param_at_slot_pass(self, PaperConstants.RenderSlot.BORDER, pass_idx, param_name, value, _TYPE)

func _bind_effective_group_material() -> void:
	if not _skeleton or not _group_mesh_instance_3d: return
	PaperConstants.bind_effective_material_for_slot(self, PaperConstants.RenderSlot.GROUP, _TYPE)

func _on_group_mat_pass_structure_changed(pass_idx: int, bits: int) -> void:
	PaperConstants.handle_pass_structure_changed(self, PaperConstants.RenderSlot.GROUP, pass_idx, bits, _effective_group_paper_material, _TYPE)

func _unbind_effective_group_material() -> void:
	PaperConstants.unbind_effective_material_for_slot(self, PaperConstants.RenderSlot.GROUP, _TYPE)

func _group_shader_material_at_pass(pass_idx: int) -> ShaderMaterial:
	return PaperConstants.get_material_at_pass(get_group_spatial_material(), pass_idx)

func _rebuild_group_shader_chain_from(pass_idx: int) -> void:
	PaperConstants.rebuild_chain_for_slot_from_pass(self, PaperConstants.RenderSlot.GROUP, pass_idx, _effective_group_paper_material, _TYPE)

func _update_group_material_param_at_pass(pass_idx: int, param_name: StringName, value: Variant) -> void:
	PaperConstants.update_param_at_slot_pass(self, PaperConstants.RenderSlot.GROUP, pass_idx, param_name, value, _TYPE)

func _shader_material_at_pass(pass_idx: int) -> ShaderMaterial:
	return PaperConstants.get_material_at_pass(get_spatial_material(), pass_idx)

func _rebuild_shader_chain_from(pass_idx: int) -> void:
	PaperConstants.rebuild_chain_for_slot_from_pass(self, PaperConstants.RenderSlot.BASE, pass_idx, _effective_paper_material, _TYPE)
#endregion

#region Property Setters, Getters, and Updaters
func set_display_entry(value: StringName) -> void: PaperConstants.set_display_entry(self, _TYPE, value)

func get_display_entry() -> StringName: return _display_entry_value

func set_subdivision_level(value: int):
	var new_value := maxi(value, 0)
	if subdivision_level == new_value: return
	subdivision_level = new_value
	if is_node_ready():
		defer_3d_mesh_reconstruction()

func get_subdivision_level() -> int: return subdivision_level

func set_flip_texture(value: Texture2D):
	if flip_texture == value: return
	flip_texture = value
	update_material_paper_params(PaperConstants.TEX_FLIP_PARAMS)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

func get_flip_texture() -> Texture2D: return flip_texture

func set_uv_masking(value: bool):
	if uv_masking == value: return
	uv_masking = value
	update_material_paper_param(PaperConstants.PaperParam.USE_MASK)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

func get_uv_masking() -> bool: return uv_masking

func set_override_mode(value: PaperConstants.OverrideMode) -> void:
	var new_value := clampi(value, 0, PaperConstants.OverrideMode.size() - 1)
	if override_mode == new_value: return
	override_mode = new_value as PaperConstants.OverrideMode
	
	if is_node_ready(): 
		_bind_effective_material()
		_bind_effective_border_material()
		_bind_effective_group_material()
	notify_property_list_changed()

func get_override_mode() -> PaperConstants.OverrideMode: return override_mode

func set_paper_material_override(value: PaperMaterial):
	if paper_material_override == value: return
	paper_material_override = value
	if is_node_ready():
		_bind_effective_material()

func get_paper_material_override() -> PaperMaterial: return paper_material_override

func set_shader_material_override(value: ShaderMaterial) -> void:
	if shader_material_override == value: return
	if _is_shader_override_mode() and value == null:
		var active_pm := get_active_material()
		if active_pm: value = active_pm._create_shader_material_for_renderable(self, _TYPE)
	shader_material_override = value
	if is_node_ready() and _is_shader_override_mode() and _mesh_instance_3d:
		_mesh_instance_3d.material_override = shader_material_override

func get_shader_material_override() -> ShaderMaterial: return shader_material_override

func set_border_mesh_enabled(value: bool) -> void:
	if border_mesh_enabled == value: return
	border_mesh_enabled = value
	if is_node_ready() and _skeleton:
		_skeleton._ensure_border_instance_for_renderable(self, _TYPE)
		if _border_mesh_instance_3d:
			_skeleton._apply_offsets_for_renderable(self, _TYPE)
	notify_property_list_changed()

func get_border_mesh_enabled() -> bool: return border_mesh_enabled

func set_border_paper_material_override(value: PaperMaterial) -> void:
	if border_paper_material_override == value: return
	border_paper_material_override = value
	if is_node_ready():
		if (value != null) != (_border_mesh_instance_3d != null):
			_skeleton._ensure_border_instance_for_renderable(self, _TYPE)
			if _border_mesh_instance_3d:
				_skeleton._apply_offsets_for_renderable(self, _TYPE)
		_bind_effective_border_material()

func get_border_paper_material_override() -> PaperMaterial: return border_paper_material_override

func set_border_shader_material_override(value: ShaderMaterial) -> void:
	if border_shader_material_override == value: return
	if _is_shader_override_mode() and value == null:
		var active_pm := get_active_border_material()
		if active_pm: value = active_pm._create_shader_material_for_renderable(self, _TYPE)
	border_shader_material_override = value
	if is_node_ready():
		if (value != null) != (_border_mesh_instance_3d != null):
			_skeleton._ensure_border_instance_for_renderable(self, _TYPE)
			if _border_mesh_instance_3d:
				_skeleton._apply_offsets_for_renderable(self, _TYPE)
		_bind_effective_border_material()

func get_border_shader_material_override() -> ShaderMaterial: return border_shader_material_override

func set_group_mesh_enabled(value: bool) -> void:
	if group_mesh_enabled == value: return
	group_mesh_enabled = value
	if is_node_ready() and _skeleton:
		_skeleton._ensure_group_instance_for_renderable(self, _TYPE)
		if _group_mesh_instance_3d:
			_skeleton._apply_offsets_for_renderable(self, _TYPE)
	notify_property_list_changed()

func get_group_mesh_enabled() -> bool: return group_mesh_enabled

func set_group_paper_material_override(value: PaperMaterial) -> void:
	if group_paper_material_override == value: return
	group_paper_material_override = value
	if is_node_ready():
		if (value != null) != (_group_mesh_instance_3d != null):
			_skeleton._ensure_group_instance_for_renderable(self, _TYPE)
			if _group_mesh_instance_3d:
				_skeleton._apply_offsets_for_renderable(self, _TYPE)
		_bind_effective_group_material()

func get_group_paper_material_override() -> PaperMaterial: return group_paper_material_override

func set_group_shader_material_override(value: ShaderMaterial) -> void:
	if group_shader_material_override == value: return
	if _is_shader_override_mode() and value == null:
		var active_pm := get_active_group_material()
		if active_pm: value = active_pm._create_shader_material_for_renderable(self, _TYPE)
	group_shader_material_override = value
	if is_node_ready():
		if (value != null) != (_group_mesh_instance_3d != null):
			_skeleton._ensure_group_instance_for_renderable(self, _TYPE)
			if _group_mesh_instance_3d:
				_skeleton._apply_offsets_for_renderable(self, _TYPE)
		_bind_effective_group_material()

func get_group_shader_material_override() -> ShaderMaterial: return group_shader_material_override

func set_index_target(value: Node) -> void:
	if value == index_target: return
	if !value or value == self:
		index_target = null
	elif not (value is PaperSprite2D or value is PaperPolygon2D):
		push_error("'index_target' must be either a PaperSprite2D or a PaperPolygon2D.")
		return
	else:
		# Quick paradox check (A -> B and B -> A)
		var v_it: Node = value.get(&"index_target")
		if v_it == self:
			push_error("Paradoxical reference detected in Paper indices. This would cause an infinite loop.")
			return
		index_target = value
	if _skeleton:
		_skeleton._defer_index_pointer_update()

func get_index_target() -> Node: return index_target

func set_group_index_target(value: Node) -> void:
	if value == group_index_target: return
	if !value or value == self:
		group_index_target = null
	elif not (value is PaperSprite2D or value is PaperPolygon2D):
		push_error("'group_index_target' must be either a PaperSprite2D or a PaperPolygon2D.")
		return
	else:
		group_index_target = value
	if _skeleton:
		_skeleton._defer_index_pointer_update()

func get_group_index_target() -> Node: return group_index_target

func set_material_parameter_overrides_size(size: int) -> void:
	PaperConstants.set_material_parameter_overrides_size(size, self, _TYPE)

func get_material_parameter_overrides_size() -> int: return material_parameter_overrides.size()

## Sets [member CanvasItem.modulate] and updates spatial materials' color.
## [br][br]
## [b]Note:[/b] Due to technical limitations, there is no optimized way to get and update modulate
##              values from a [CanvasItem]'s parents. For this reason, it's better practice to use
##              [method set_self_modulate_and_update] over this function.
func set_modulate_and_update(value: Color) -> void:
	set_modulate(value)
	update_material_paper_param(PaperConstants.PaperParam.COLOR)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member CanvasItem.self_modulate] and updates spatial materials' color.
func set_self_modulate_and_update(value: Color) -> void:
	set_self_modulate(value)
	update_material_paper_param(PaperConstants.PaperParam.COLOR)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.flip_h] and updates UV transform and offset in spatial materials.
func set_flip_h_and_update(value: bool) -> void:
	set_flip_h(value)
	_sprite_uv_dirty = true
	update_material_paper_params(PaperConstants.UV_FLIP_PARAMS)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.flip_v] and updates UV transform and offset in spatial materials.
func set_flip_v_and_update(value: bool) -> void:
	set_flip_v(value)
	_sprite_uv_dirty = true
	update_material_paper_params(PaperConstants.UV_FLIP_PARAMS)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.texture], refreshes atlas chain data, pushes texture and region spatial material parameters,
## and triggers a mesh rebuild if the visual size changed.
func set_texture_and_update(value: Texture2D) -> void:
	var old_size := texture.get_size() if texture else Vector2.ZERO
	set_texture(value)
	
	# Update atlas texture tracking and caches
	_update_atlas_texture_tracking()
	
	# Texture params, and geometry may change (size/frame)
	# Push OFFSET and MASK so shader stays in sync
	const TEX_AND_REGION_PARAMS := PaperConstants.TEX_MAIN_PARAMS + PaperConstants.REGION_PARAMS
	update_material_paper_params(TEX_AND_REGION_PARAMS) 
	
	if old_size != (texture.get_size() if texture else Vector2.ZERO):
		defer_3d_mesh_reconstruction()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.region_enabled], updates region spatial material parameters and rebuilds the 3D mesh.
func set_region_enabled_and_update(value: bool) -> void:
	set_region_enabled(value)
	_sprite_uv_dirty = true
	update_material_paper_params(PaperConstants.REGION_PARAMS)
	defer_3d_mesh_reconstruction()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.region_rect], pushes region spatial material parameters and rebuilds mesh when size changed.
func set_region_rect_and_update(value: Rect2) -> void:
	var offset_update := region_rect.position != value.position
	var mesh_update := region_rect.size != value.size
	set_region_rect(value)
	if offset_update or mesh_update:
		_sprite_uv_dirty = true
		update_material_paper_params(PaperConstants.REGION_PARAMS)
	if mesh_update:
		defer_3d_mesh_reconstruction()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.hframes], updates frame UVs in spatial materials and rebuilds mesh's.
func set_hframes_and_update(value: int) -> void:
	set_hframes(value)
	_sprite_uv_dirty = true
	defer_3d_mesh_reconstruction()
	update_material_paper_param(PaperConstants.PaperParam.OFFSET)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.vframes], updates frame UVs in spatial materials and rebuilds mesh.
func set_vframes_and_update(value: int) -> void:
	set_vframes(value)
	_sprite_uv_dirty = true
	defer_3d_mesh_reconstruction()
	update_material_paper_param(PaperConstants.PaperParam.OFFSET)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.frame], updates frame UV offset in spatial materials.
func set_frame_and_update(value: int) -> void:
	set_frame(value)
	_sprite_uv_dirty = true
	update_material_paper_param(PaperConstants.PaperParam.OFFSET)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Sprite2D.centered] and rebuilds the 3D mesh.
func set_centered_and_update(value: bool) -> void:
	set_centered(value)
	defer_3d_mesh_reconstruction()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member Node2D.position] offset for the skin bind and updates the 3D transform.
func set_offset_and_update(value: Vector2) -> void:
	set_offset(value)
	if _skeleton:
		_skeleton._update_sprite_transform(self)
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member CanvasItem.z_index] and defers a paper z-index update.
func set_z_index_and_update(value: int) -> void:
	set_z_index(value)
	_defer_z_index_update()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)

## Sets [member CanvasItem.z_index] and defers a paper z-index update.
func set_z_as_relative_and_update(value: bool) -> void:
	set_z_as_relative(value)
	_defer_z_index_update()
	PaperConstants._on_display_entry_property_changed(self, _TYPE)
#endregion

#region Material Parameter Override Management
## Sets a material parameter override at [param idx] and propagates its uniform across all material passes.
func set_material_parameter_override(idx: int, value: Variant) -> void:
	var size_changed := PaperConstants.set_material_parameter_override(idx, value, self, _TYPE)
	if size_changed: notify_property_list_changed()

## Gets a material parameter override at [param idx].
func get_material_parameter_override(idx: int) -> Variant:
	return material_parameter_overrides[idx] \
		   if absi(idx) < material_parameter_overrides.size() \
		   else null

## Sets the name of a material parameter override.
func set_material_parameter_override_name(idx: int, value: StringName) -> void:
	var size_changed := PaperConstants.set_material_parameter_override_name(idx, value, self, _TYPE)
	if size_changed: notify_property_list_changed()

## Gets the name of a material parameter override at [param idx].
func get_material_parameter_override_name(idx: int) -> StringName:
	return material_parameter_override_names[idx] \
		   if absi(idx) < material_parameter_override_names.size() \
		   else &""

## Sets the type of a material parameter override for easier modification in the inspector.
func set_material_parameter_override_type(idx: int, value: PaperConstants.UniformType) -> void:
	var size_changed := PaperConstants.set_material_parameter_override_type(idx, value, self, _TYPE)
	if size_changed: notify_property_list_changed()

## Gets the type of a material parameter override at [param idx].
func get_material_parameter_override_type(idx: int) -> PaperConstants.UniformType:
	return PaperConstants._mpo_uniform_type(material_parameter_override_types[idx]) as PaperConstants.UniformType \
		   if absi(idx) < material_parameter_override_types.size() \
		   else PaperConstants.UniformType.TEXTURE

## Sets whether the override at [param idx] is applied as an instance parameter.
func set_material_parameter_override_instance(idx: int, value: bool) -> void:
	var size_changed := PaperConstants.set_material_parameter_override_instance(idx, value, self, _TYPE)
	if size_changed: notify_property_list_changed()

## Gets whether the override at [param idx] is applied as an instance parameter.
func get_material_parameter_override_instance(idx: int) -> bool:
	return PaperConstants._mpo_is_instance(material_parameter_override_types[idx]) \
		   if absi(idx) < material_parameter_override_types.size() \
		   else false

## Sets whether the override at [param idx] is applied as an array parameter.
func set_material_parameter_override_array(idx: int, value: bool) -> void:
	var size_changed := PaperConstants.set_material_parameter_override_array(idx, value, self, _TYPE)
	if size_changed: notify_property_list_changed()

## Gets whether the override at [param idx] is applied as an array parameter.
func get_material_parameter_override_array(idx: int) -> bool:
	return PaperConstants._mpo_is_array(material_parameter_override_types[idx]) \
		   if absi(idx) < material_parameter_override_types.size() \
		   else false
#endregion

#region Transform Updates
func _compute_rel_local_no_offset() -> Transform2D:
	if not _skeleton:
		return Transform2D.IDENTITY
	var b := _parent_bone_2d
	if b:
		return b.get_global_transform().affine_inverse() * get_global_transform()
	elif _skeleton.skeleton_2d:
		return _skeleton.skeleton_2d.get_global_transform().affine_inverse() * get_global_transform()
	else:
		return get_transform()

func _relative_transform_check() -> void:
	if _rel_starting_check:
		_rel_starting_check = false
		if _parent_bone_2d and get_parent() == _parent_bone_2d:
			return
	var cur := _compute_rel_local_no_offset()
	if not _rel_cache_valid or not _rel_local_cache.is_equal_approx(cur):
		_rel_local_cache = cur
		_rel_cache_valid = true
		_skeleton._update_sprite_transform(self)

func _update_transform_policy() -> void:
	if get_parent() == _parent_bone_2d:
		set_notify_local_transform(true)
		set_notify_transform(false)
		_rel_local_cache = Transform2D.IDENTITY
		_rel_cache_valid = false
	else:
		set_notify_local_transform(false)
		set_notify_transform(true)
		_rel_local_cache = _compute_rel_local_no_offset()
		_rel_cache_valid = true
#endregion

#region Display Entry Management
## Snapshots and creates a new display entry and selects it.
## [br][br]
## If [param entry_name] already exists, a numbered suffix is appended (or incremented, if one already exists).
## The snapshot includes the display properties and material parameter overrides for this [PaperSprite2D].
func add_display_entry(entry_name: StringName = display_entry) -> bool:
	return PaperConstants.add_display_entry(self, _TYPE, entry_name)

## Removes a display entry by name.
## [br][br]
## If the removed entry was active, the first available entry is then automatically selected.
func remove_display_entry(entry_name: StringName) -> bool:
	return PaperConstants.remove_display_entry(self, _TYPE, entry_name)

## Renames an existing display entry.
## [br][br]
## Returns [code]false[/code] if [param new_name] is empty or already exists.
func rename_display_entry(old_name: StringName, new_name: StringName) -> bool:
	return PaperConstants.rename_display_entry(self, _TYPE, old_name, new_name)

## Moves a display entry up or down in the list by [param dir].
## [br][br]
## Use [code]-1[/code] to move up, [code]1[/code] to move down.
func move_display_entry(entry_name: StringName, dir: int) -> bool:
	return PaperConstants.move_display_entry(self, _TYPE, entry_name, dir)

## Saves the current visual properties into the active display entry.
## [br][br]
## Use this after editing properties to persist the snapshot.
func save_display_entry() -> bool:
	return PaperConstants.save_display_entry(self, _TYPE)

## Returns [code]true[/code] if the current visual properties differ from the currently selected entry.
## [br][br]
## Useful to detect when a snapshot needs saving.
func is_display_entry_dirty() -> bool:
	return PaperConstants.is_display_entry_dirty(self, _TYPE)
#endregion

#region Utility Functions
## Gets the currently prioritized [PaperMaterial]. If none is defined, will return [code]null[/code].
func get_active_material() -> PaperMaterial:
	return paper_material_override if paper_material_override else (_skeleton.material if _skeleton else null)

## Border mesh equivalent to [method get_active_material].
func get_active_border_material() -> PaperMaterial:
	return border_paper_material_override if border_paper_material_override else (_skeleton.border_material if _skeleton else null)
	
## Group mesh equivalent to [method get_active_material].
func get_active_group_material() -> PaperMaterial:
	return group_paper_material_override if group_paper_material_override else (_skeleton.group_material if _skeleton else null)

## Returns the effective [ShaderMaterial] currently applied to the generated [MeshInstance3D].
## This is intended for advanced use. Assigning and editing a [PaperMaterial] is preferred.
func get_spatial_material() -> ShaderMaterial:
	return _mesh_instance_3d.material_override as ShaderMaterial if _mesh_instance_3d else null

## Border mesh equivalent to [method get_spatial_material].
func get_border_spatial_material() -> ShaderMaterial:
	return _border_mesh_instance_3d.material_override as ShaderMaterial if _border_mesh_instance_3d else null

## Group mesh equivalent to [method get_spatial_material].
func get_group_spatial_material() -> ShaderMaterial:
	return _group_mesh_instance_3d.material_override as ShaderMaterial if _group_mesh_instance_3d else null

## Returns the current UV offset in the base texture’s pixel space,
## taking into account region/framing and nested [AtlasTexture] chains.
func get_uv_offset() -> Vector2:
	_ensure_uv_cache()
	return _cached_offset

## Returns the current UV mask rectangle as [code]vec4(min_x, min_y, size_x, size_y)[/code] in normalized UV,
## constrained by nested [AtlasTexture] regions (or [code](0,0,1,1)[/code] when not using atlases).
func get_uv_mask() -> Vector4:
	_ensure_uv_cache()
	return _cached_mask

## Returns the 3D Z index assigned by [PaperSkeleton].
func get_paper_idx() -> int:
	return _z_index_paper

## Returns the grouping Z index source used by certain auxiliary mesh effects.
func get_group_idx() -> int:
	var target := group_index_target if group_index_target else self
	if target is PaperPolygon2D: return (target as PaperPolygon2D).get_paper_idx()
	else: return (target as PaperSprite2D).get_paper_idx()

## Returns the micro index [code][0..1][/code] within a group to reduce Z-fighting.
func get_group_micro_idx() -> float:
	return _z_index_micro_group

## Returns the root of the [member index_target] chain while avoiding loops and invalid references.
func get_root_target() -> Node:
	var visited: Array[Node] = []
	var current := self
	while current.index_target != null:
		if current in visited:
			push_warning("Cycle detected in index_target chain for %s. Breaking loop." % name)
			return current
		visited.append(current)
		current = current.index_target
		if not is_instance_valid(current):
			push_warning("Invalid index_target reference in %s. Using itself." % name)
			return self
	return current

## Whether or not the main [MeshInstance3D]'s material should be inherited from the [PaperSkeleton] instance.
func uses_skeleton_material() -> bool:
	return not _is_shader_override_mode() and paper_material_override == null

func _is_shader_override_mode() -> bool:
	return override_mode == PaperConstants.OverrideMode.SHADER_MATERIAL

func _assign_parent_bone(b: Bone2D) -> void:
	if _parent_bone_2d == b: return
	_parent_bone_2d = b
	_update_transform_policy()

func _refresh_parent_bone_cache() -> void:
	_assign_parent_bone(_skeleton._find_parent_bone2d(self) if _skeleton else null)

## Defers a reconstruction of the 3D mesh equivalent. This is usually ran automatically.
func defer_3d_mesh_reconstruction() -> void:
	if not _mesh_update_pending:
		reconstruct_3d_mesh.call_deferred()
		_mesh_update_pending = true

## Reconstructs the 3D mesh equivalent. This is usually ran automatically.
func reconstruct_3d_mesh() -> void:
	if _skeleton and _skeleton.is_node_ready():
		_skeleton._sprite_rebuild(self)

func _defer_z_index_update() -> void:
	if _skeleton:
		_skeleton._defer_z_index_update()

func _on_mesh_rebuilt() -> void:
	_mesh_update_pending = false
	if get_parent() == _parent_bone_2d:
		_rel_local_cache = _compute_rel_local_no_offset()
		_rel_cache_valid = true

func _set_instance_param(param_name: StringName, value: Variant) -> void:
	PaperConstants.set_instance_param_for_all_slots(self, param_name, value, _TYPE)
#endregion
