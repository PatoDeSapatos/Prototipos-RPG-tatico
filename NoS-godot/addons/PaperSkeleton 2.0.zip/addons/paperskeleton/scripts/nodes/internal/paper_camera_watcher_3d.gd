@tool
extends Node3D

## Internal node type used by [PaperSkeleton] to track camera movement when
## [PaperSkeleton.billboard_enabled] is set to true.
## Unless if you know what you're doing, it's recommended to leave this class alone.

static var _registry: Dictionary[Node3D, PaperSkeleton.PaperCameraWatcher3D] = {}

static func acquire(camera: Node3D) -> PaperSkeleton.PaperCameraWatcher3D:
	if not camera: return null
	var w = _registry.get(camera)
	if is_instance_valid(w): return w
	
	var nw := PaperSkeleton.PaperCameraWatcher3D.new()
	nw._attach_to_camera(camera)
	_registry[camera] = nw
	return nw

static func _release(camera: Node3D, watcher: PaperSkeleton.PaperCameraWatcher3D) -> void:
	if (_registry.get(camera) as PaperSkeleton.PaperCameraWatcher3D) == watcher:
		_registry.erase(camera)

var _camera: Node3D:
	set(value):
		if _camera == value: return
		_camera = value
		_camera_is_camera = _camera is Camera3D
var _camera_is_camera: bool = _camera is Camera3D
var _subs: Array[WeakRef] = []
var _need_polling_offset := false
var _cached_cam_xf: Transform3D

func _init() -> void:
	set_notify_transform(true)
	name = &"_PaperCameraWatcher"
	set_process(false)
	process_priority = PaperConstants.ProcessPriority.CAM_WATCHER

func _attach_to_camera(cam: Node3D) -> void:
	if _camera == cam: return
	if _camera and _camera.tree_exiting.is_connected(_on_camera_tree_exiting):
		_camera.tree_exiting.disconnect(_on_camera_tree_exiting)
	
	_camera = cam  # uses the setter; updates _camera_is_camera
	_cached_cam_xf = (_camera as Camera3D).get_camera_transform() if _camera_is_camera else _camera.global_transform
	_camera.add_child(self, false, INTERNAL_MODE_FRONT)
	_camera.tree_exiting.connect(_on_camera_tree_exiting, CONNECT_DEFERRED)
	
	_notify_subscribers()

func subscribe(skel: PaperSkeleton) -> void:
	if not skel: return
	for wr in _subs:
		var s: PaperSkeleton = wr.get_ref()
		if s == skel:
			_recompute_polling_flag()
			return
	_subs.append(weakref(skel))
	_recompute_polling_flag()
	skel._mark_billboard_dirty()

func unsubscribe(skel: PaperSkeleton) -> void:
	var dead_indices := PackedInt32Array()
	for i: int in _subs.size():
		var wr: WeakRef = _subs[i]
		var s: PaperSkeleton = wr.get_ref()
		if not is_instance_valid(s) or s == skel:
			dead_indices.append(i)
	
	if _compact_subs(dead_indices):
		_recompute_polling_flag()
		_try_self_release()

func on_subscriber_config_changed() -> void:
	_recompute_polling_flag()

func _recompute_polling_flag() -> void:
	var need := false
	if _camera is Camera3D:
		for wr: WeakRef in _subs:
			var s: PaperSkeleton = wr.get_ref()
			if is_instance_valid(s) and s.billboard_enabled and s.billboard_track_offset:
				need = true
				break
	_need_polling_offset = need
	set_process(_need_polling_offset)

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED: _notify_subscribers()

func _process(_delta: float) -> void:
	if not _need_polling_offset or not _camera_is_camera:
		_need_polling_offset = false
		set_process(false)
		return
	var ct := (_camera as Camera3D).get_camera_transform()
	if ct != _cached_cam_xf:
		_cached_cam_xf = ct
		_notify_subscribers()

func _notify_subscribers() -> void:
	var dead_indices := PackedInt32Array()
	for i: int in _subs.size():
		var wr: WeakRef = _subs[i]
		var skel: PaperSkeleton = wr.get_ref()
		if not is_instance_valid(skel):
			dead_indices.append(i)
		else:
			if skel.billboard_enabled and skel.is_inside_tree():
				skel._mark_billboard_dirty()
	
	if _compact_subs(dead_indices):
		_try_self_release()

func _compact_subs(dead_sorted_indices: PackedInt32Array) -> bool:
	var dead_count := dead_sorted_indices.size()
	if dead_count == 0: return false
	
	var subs_size := _subs.size()
	var new_size := subs_size - dead_count
	var alive: Array[WeakRef] = []
	alive.resize(new_size)
	
	var write_idx := 0
	var dead_idx := 0
	
	for read_idx: int in subs_size:
		if dead_idx < dead_count and read_idx == dead_sorted_indices[dead_idx]:
			dead_idx += 1
			continue
		
		alive[write_idx] = _subs[read_idx]
		write_idx += 1
	
	_subs = alive
	return true

func _on_camera_tree_exiting() -> void:
	_release(_camera, self)
	queue_free()

func _try_self_release() -> void:
	if _subs.is_empty():
		_release(_camera, self)
		queue_free()
