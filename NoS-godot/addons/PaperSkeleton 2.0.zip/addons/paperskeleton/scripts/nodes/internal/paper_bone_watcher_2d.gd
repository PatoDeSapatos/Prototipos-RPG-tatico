@tool
extends Node2D

## Internal node type used by [PaperSkeleton] to track local [Bone2D] movement.
## Unless if you know what you're doing, it's recommended to leave this class alone.

var skeleton: PaperSkeleton
var bone: Bone2D:
	set(value):
		if bone == value: return
		bone = value
		var old_bone := get_parent()
		if old_bone:
			old_bone.remove_child(self)
		if bone:
			bone.add_child(self, false, INTERNAL_MODE_FRONT)
		_local_transform_cache = bone.transform
var _local_transform_cache := Transform2D.IDENTITY

func _init(b: Bone2D, s: PaperSkeleton, n: StringName = &"_PaperBoneWatcher") -> void:
	bone = b
	skeleton = s
	name = n
	set_notify_transform(true)

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		# Clear CanvasItem::global_invalid such that more NOTIFICATION_TRANSFORM_CHANGED can be received
		get_global_transform()
		var cur := bone.get_transform()
		if _local_transform_cache != cur:
			_local_transform_cache = cur
			skeleton._update_bone_transform(bone)
