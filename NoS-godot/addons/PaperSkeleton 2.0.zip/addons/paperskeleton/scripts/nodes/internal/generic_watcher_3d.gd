@tool
extends Node3D

## Internal node type used to track movement on any [Node3D] that it's attached to,
## global or local. This node is only meant to be instantiated via code.
## Use [signal transform_update] to tell when the transform has been updated.

var watch_local: bool:
	set(value):
		if watch_local == value:
			return
		watch_local = value
		_value_change()
var target: Node3D:
	set(value):
		if target == value:
			return
		target = value
		var old_target := get_parent()
		if old_target:
			old_target.remove_child(self)
		if target:
			target.add_child(self, false, INTERNAL_MODE_FRONT)
		_value_change()
var _local_transform_cache: Transform3D

signal transform_update()

func _init(t: Node3D, wl: bool = false, n: String = "_GenericWatcher3D") -> void:
	target = t
	watch_local = wl
	name = n
	
	set_notify_transform(true)

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		_check_transform()

func _check_transform() -> void:
	if watch_local:
		var cur := target.get_transform()
		if _local_transform_cache != cur:
			_local_transform_cache = cur
			transform_update.emit()
	else:
		transform_update.emit()

func _value_change() -> void:
	if is_node_ready():
		if watch_local:
			if target:
				_local_transform_cache = target.get_transform()
				transform_update.emit()
		else:
			transform_update.emit()
