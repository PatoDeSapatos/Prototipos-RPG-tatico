@tool
extends Node

## Internal singleton bus that checks Viewports once per frame to see if the active 
## camera changes, and notifies [PaperSkeleton] subscribers when it does.
## Unless if you know what you're doing, it's recommended to leave this class alone.

static var _instance: PaperSkeleton.PaperViewportCameraBus

static func get_singleton(tree: SceneTree) -> PaperSkeleton.PaperViewportCameraBus:
	if is_instance_valid(_instance): return _instance
	
	_instance = PaperSkeleton.PaperViewportCameraBus.new()
	_instance.name = &"_PaperViewportCameraBus"
	_instance.process_priority = PaperConstants.ProcessPriority.VPC_BUS
	
	tree.get_root().add_child.call_deferred(_instance, false, INTERNAL_MODE_FRONT)
	return _instance

class _VPEntry:
	var viewport: Viewport
	var last_camera: Camera3D = null
	var subs: Array[WeakRef] = []
	
	func _init(vp: Viewport) -> void:
		viewport = vp
		last_camera = vp.get_camera_3d()
	
	func subscribe(skel: PaperSkeleton) -> void:
		for wr: WeakRef in subs:
			var s: PaperSkeleton = wr.get_ref()
			if s == skel: return
		subs.append(weakref(skel))
	
	func unsubscribe(skel: PaperSkeleton) -> void:
		var dead_indices := PackedInt32Array()
		for i: int in subs.size():
			var wr: WeakRef = subs[i]
			var s: PaperSkeleton = wr.get_ref()
			if not is_instance_valid(s) or s == skel:
				dead_indices.append(i)
		compact_subs(dead_indices)
	
	func compact_subs(dead_indices: PackedInt32Array) -> bool:
		var dead_count := dead_indices.size()
		if dead_count == 0: return false
		
		var sub_size := subs.size()
		var new_size := sub_size - dead_count
		var alive: Array[WeakRef] = []
		alive.resize(new_size)
		
		var write_idx := 0
		var dead_idx := 0
		
		for read_idx: int in sub_size:
			if dead_idx < dead_count and read_idx == dead_indices[dead_idx]:
				dead_idx += 1
				continue
			
			alive[write_idx] = subs[read_idx]
			write_idx += 1
		
		subs = alive
		return true

var _entries: Array[_VPEntry] = []
var _vp_to_index: Dictionary[Viewport, int] = {}

func _add_entry(e: _VPEntry) -> void:
	_entries.append(e)
	_vp_to_index[e.viewport] = _entries.size() - 1

func _remove_entry_at(i: int) -> void:
	if i < 0 or i >= _entries.size(): return
	var vp: Viewport = _entries[i].viewport
	_entries.remove_at(i)
	_vp_to_index.erase(vp)
	
	var entry_total := _entries.size()
	if i < entry_total:
		for j: int in entry_total:
			_vp_to_index[_entries[j].viewport] = j

func subscribe(vp: Viewport, skel: PaperSkeleton) -> void:
	if not vp or not is_instance_valid(skel): return
	
	var e: _VPEntry = null
	var idx: int = _vp_to_index.get(vp, -1)
	if idx >= 0 and idx < _entries.size():
		e = _entries[idx]
	
	if e == null:
		e = _VPEntry.new(vp)
		_add_entry(e)
		if not vp.tree_exiting.is_connected(_on_viewport_tree_exiting):
			vp.tree_exiting.connect(_on_viewport_tree_exiting.bind(vp))
	
	e.subscribe(skel)
	_set_process_state()

func unsubscribe(vp: Viewport, skel: PaperSkeleton) -> void:
	if not vp: return
	
	var idx: int = _vp_to_index.get(vp, -1)
	if idx >= 0 and idx < _entries.size():
		var e: _VPEntry = _entries[idx]
		e.unsubscribe(skel)
		if e.subs.is_empty():
			_remove_entry_at(idx)
		_set_process_state()
		return
	
	# Fallback linear search if map lookup failed
	_vp_to_index.erase(vp)
	for i: int in _entries.size():
		var e: _VPEntry = _entries[i]
		if e.viewport == vp:
			e.unsubscribe(skel)
			if e.subs.is_empty():
				_remove_entry_at(i)
			_set_process_state()
			return

func _on_viewport_tree_exiting(vp: Viewport = null) -> void:
	if vp != null:
		var idx: int = _vp_to_index.get(vp, -1)
		if idx >= 0 and idx < _entries.size():
			_remove_entry_at(idx)
			_set_process_state()
			return
		
		# Fallback linear search if map lookup failed
		_vp_to_index.erase(vp)
		for i: int in _entries.size():
			if _entries[i].viewport == vp:
				_remove_entry_at(i)
				break
	else:
		# Remove invalid viewports
		var i := 0
		while i < _entries.size():
			if not is_instance_valid(_entries[i].viewport):
				_remove_entry_at(i)
			else:
				i += 1
	_set_process_state()

func _set_process_state() -> void:
	set_process(not _entries.is_empty())

func _process(_delta: float) -> void:
	var i := 0
	while i < _entries.size():
		var e: _VPEntry = _entries[i]
		var vp: Viewport = e.viewport
		
		if not is_instance_valid(vp):
			_remove_entry_at(i)
			continue
		
		var cam := _resolve_camera_for_viewport(vp)
		if cam != e.last_camera:
			e.last_camera = cam
			_notify_subscribers(e, cam)
		
		i += 1
	
	_set_process_state()

func _notify_subscribers(e: _VPEntry, cam: Camera3D) -> void:
	var dead_indices := PackedInt32Array()
	for i: int in e.subs.size():
		var s: PaperSkeleton = e.subs[i].get_ref()
		if is_instance_valid(s):
			_notify_one(s, cam)
		else:
			dead_indices.append(i)
	e.compact_subs(dead_indices)

func _notify_one(skel: PaperSkeleton, cam: Camera3D) -> void:
	if is_instance_valid(skel):
		skel._on_viewport_camera_changed_from_bus(cam)

func _resolve_camera_for_viewport(vp: Viewport) -> Camera3D:
	if not Engine.is_editor_hint(): return vp.get_camera_3d()
	return get_editor_camera(vp.get_world_3d())

static func get_editor_camera(w: World3D) -> Camera3D:
	var ei := Engine.get_singleton(&"EditorInterface")
	if not ei: return null
	var fallback: Camera3D = null
	for i: int in 4:
		var ed_vp: SubViewport = ei.get_editor_viewport_3d(i)
		if not ed_vp: continue
		var ed_cam := ed_vp.get_camera_3d()
		if ed_cam:
			if ed_cam.get_world_3d() == w:
				return ed_cam
			if not fallback:
				fallback = ed_cam
	return fallback
