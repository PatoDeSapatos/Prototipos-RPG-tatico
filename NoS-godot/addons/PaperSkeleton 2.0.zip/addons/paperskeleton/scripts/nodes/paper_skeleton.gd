@tool
@icon("uid://papersklbico")
extends Skeleton3D
class_name PaperSkeleton

## 2D→3D bridge that mirrors a 2D cutout rig ([Sprite2D]s and [Polygon2D]s driven by [Skeleton2D])
## as a skinned 3D setup ([Skeleton3D] + [MeshInstance3D]s) suitable for spatial shaders and effects.
## [br][br]
## What [PaperSkeleton] does:[br]
## 　• Collects [Polygon2D] under [member polygon_group] (converting to [PaperPolygon2D]).[br]
## 　• Collects [Sprite2D] below [member skeleton_2d] (converting to [PaperSprite2D]).[br]
## 　• Builds skinned meshes and binds them to [PaperSkeleton].[br]
## 　• Mirrors 2D Z-order into 3D through per-instance Z offsets and sorting.[br]
## 　• Supports optional auxiliary border/group effect meshes.[br]
## 　• Supports cylindrical billboarding to have rig always face the camera.
## [br][br]
## Typical workflow:[br]
## 　1) Author a 2D rig with one [Skeleton2D] and [Sprite2D]/[Polygon2D] children.[br]
## 　2) Set [member polygon_group] to the node containing your [Polygon2D]s, or set [member skeleton_2d] for [Sprite2D] collection.[br]
## 　3) Optionally assign [member material], [member border_material], [member group_material].[br]
## 　4) Tune [member layer_space], index pointers, and billboarding options as needed.
## [br][br]
## Notes:[br]
## 　• Bone names in the [Skeleton2D] must be unique (mirrors [Skeleton3D] constraints).[br]
## 　• [PaperSkeleton] hides the original 2D nodes when [member hide_sources] is true (default).

#region Signals
## Emitted when the [PaperSkeleton] rig is fully constructed (meshes, bones, wiring).
signal skeleton_constructed
## Emitted when the [PaperSkeleton] rig is deconstructed (session cleared).
signal skeleton_deconstructed
## Emitted when there's a cylindrical billboard update.
signal billboard_update
## Emitted when the billboard camera changes.
signal billboard_camera_update
## Emitted when a flip occurs from either [member flip_rotate] or [member flip].
signal flipped
#endregion

#region Constants
## 2D pixel-to-3D unit scale
const PX_SCALE: float = 0.01
## Per-layer spacing in 3D Z
const LAYER_SCALE: float = 0.001
## Extra bones used by the rig.
## In this iteration of the addon, [code]PaperFlipBone3D[/code] is the only extra bone. 
const EX_BONES: int = 1

## Index for flip bone
const FLIP_BONE_IDX  := 0
## Name for flip bone     
const FLIP_BONE_NAME := "PaperFlipBone3D"

## Internal tracker node used to keep track of [Bone2D] updates.
const PaperBoneWatcher2D   := preload("uid://paperbwtcgds")
## Internal tracker node used to keep track of [Camera3D] updates when [member billboard_enabled] is set to true.
const PaperCameraWatcher3D := preload("uid://papercwtcgds")
## Internal polling node used to keep track of viewport camera changes.
const PaperViewportCameraBus := preload("uid://papervpcbgds")
#endregion

#region Exported properties
## Tool button that runs [method refresh_setup].
@export_tool_button("Rebuild PaperSkeleton", "Reload")
var refresh_skeleton := refresh_setup

@export_group("Sources")
## Root node containing [Polygon2D] children to collect as [PaperPolygon2D].
@export var polygon_group: Node = null:
	set = set_polygon_group, get = get_polygon_group

## [Skeleton2D] whose subtree is walked to collect [Sprite2D]s as [PaperSprite2D].
@export var skeleton_2d: Skeleton2D:
	set = set_skeleton_2d, get = get_skeleton_2d

@export_group("Visual")
## Hide the original 2D sources ([Polygon2D]s/[Sprite2D]s) while the rig is active.
## [br][br]
## [b]Note:[/b] This just sets the [member CanvasItem.visibility_layer] of all renderables to
##              [code]0[/code].
@export var hide_sources := true:
	set = set_hide_sources, get = get_hide_sources

@export_subgroup("Materials")
## [PaperMaterial] applied to the rig's meshes. Used to easily assign custom [Shader]s and their
## parameters without needing to individually manage [ShaderMaterial]s.
@export var material: PaperMaterial = null:
	set = set_material, get = get_material

## [PaperMaterial] for the "border" effect slot.
## [br][br]
## Setting this value will display auxiliary meshes using the material behind the main rig.
## This should allow for simple flat "border" style effects to be conveyed with specialized shaders.
@export var border_material: PaperMaterial = null:
	set = set_border_material, get = get_border_material

## [PaperMaterial] for the "group" effect slot.
## [br][br]
## Setting this value will individually display auxiliary meshes using this material behind each renderable's main meshes.
## Like [member border_material] this should also allow for simple flat "border" style effects, but on
## individual assets, instead of only being placed behind the main rig.
## [br][br]
## Setting a renderable's group index pointer ([member PaperPolygon2D.group_index_target] or
## [member PaperSprite2D.group_index_target]), will let you group these auxiliary meshes together.
## Doing this will allow you to convey a border around a group of renderables, conveying the effect
## of them being a singular object.
@export var group_material: PaperMaterial = null:
	set = set_group_material, get = get_group_material

@export_subgroup("Technical")
## [member GeometryInstance3D.cast_shadow] option applied to generated [MeshInstance3D]s.
@export var cast_shadow := GeometryInstance3D.SHADOW_CASTING_SETTING_DOUBLE_SIDED:
	set = set_cast_shadow, get = get_cast_shadow

## [member GeometryInstance3D.gi_mode] applied to generated [MeshInstance3D]s.
@export var global_illumination_mode := GeometryInstance3D.GI_MODE_DISABLED:
	set = set_global_illumination_mode, get = get_global_illumination_mode

## [member VisualInstance3D.layers] bitmask for all generated [MeshInstance3D]s.
@export_custom(PROPERTY_HINT_LAYERS_3D_RENDER, "")
var render_layers: int = 1:
	set = set_render_layers, get = get_render_layers

@export_group("Flip Transformation")
## When true, applies 180 degrees of rotation to [code]PaperFlipBone3D[/code],
## effectively flipping the model across the X axis. 
@export var flip := false:
	set = set_flip, get = get_flip

## Flips the [PaperSkeleton] rig using the [code]PaperFlipBone3D[/code] bone.
@export_range(-360, 360, 0.5, "or_less", "or_greater", "radians_as_degrees")
var flip_rotate := 0.0:
	set = set_flip_rotate, get = get_flip_rotate

@export_group("Cylindrical Billboarding", "billboard_")
## Enables cylindrical billboarding, forcing the rig to face the camera.
@export_custom(PROPERTY_HINT_GROUP_ENABLE, "")
var billboard_enabled := false:
	set = set_billboard_enabled, get = get_billboard_enabled

## Optional explicit camera to drive billboarding.
@export var billboard_camera_override: Node3D:
	set = set_billboard_camera_override, get = get_billboard_camera_override

enum BillboardDirection {
	POSITION, ## Face camera position.
	ROTATION  ## Match camera rotation.
}
## Controls direction for billboarding.
@export var billboard_direction := BillboardDirection.POSITION:
	set = set_billboard_direction, get = get_billboard_direction

## When enabled, uses [member Camera3D.get_camera_transform()] rather than just its global transform.
## [br][br]
## Due to needing frame-by-frame checking to consistently detect updates, enabling this option also
## has the side effect of updating stale frames in certain scenarios. If you notice that your model's
## billboarding occasionally updates a frame too late, enabling this option [i]might[/i] fix it.
@export var billboard_track_offset := false:
	set = set_billboard_track_offset, get = get_billboard_track_offset

var _is_dir_position := billboard_direction == BillboardDirection.POSITION

enum BillboardAxis {
	LOCAL,         ## Up aligned to skeleton’s local Y.
	GLOBAL,        ## Up aligned to world UP.
	GLOBAL_UPRIGHT ## Same as [enum BillboardAxis.GLOBAL], but with a more explicit upright constraint.
}
## Controls vertical axis source of cylindrical billboarding.
@export var billboard_axis := BillboardAxis.LOCAL:
	set = set_billboard_axis, get = get_billboard_axis
var _is_axis_local := billboard_axis == BillboardAxis.LOCAL
var _is_axis_upright := billboard_axis == BillboardAxis.GLOBAL_UPRIGHT

@export_group("Z Sorting")
## Layer spacing scale. Affects 3D Z offsets between renderables.
@export var layer_space := 1.0:
	set = set_layer_space, get = get_layer_space

## When true, listen for child order changes and keep Z sorting live.
## When false, do not recursively connect all the child nodes to [signal Node.child_order_changed].
## [br][br]
## [b]Note:[/b] This is useful to have enabled in the editor (which is why it's enabled by default), but
##              for general animation purposes, it's not particularly necessary, and can potentially increase
##              overhead and instantiation time.
##              [br][br]
##              If you'd like to manually update the Z order while this is disabled, run [method _defer_scene_sort_update].
@export var track_child_order := true:
	set = set_track_child_order, get = get_track_child_order

## Adjusts the [MeshInstance3D]s' [member VisualInstance3D.sorting_offset] during Z sorting.
## [br][br]
## Useful when the "Alpha" blending transparency mode is used in the [member material]'s [Shader], as it becomes sorted from both sides. 
## If using any other transparency mode, this property should have no significant effect.
@export var adjust_sorting_offset := true:
	set = set_adjust_sorting_offset, get = get_adjust_sorting_offset

@export_group("Instantiation Cache", "instantiation_cache_")
## Saves [NodePath]s pointing to [PaperPolygon2D] and [PaperSprite2D] renderables into scene data for faster instantiation.
## [br][br]
## [b]Note:[/b] This needs to be enabled for [member instantiation_cache_meshes] and [member instantiation_cache_z_indices] to have any effect.
@export_custom(PROPERTY_HINT_GROUP_ENABLE, "")
var instantiation_cache_enabled := true
## Saves [PaperPolygon2D] and [PaperSprite2D] renderables' 3D [ArrayMesh]es into scene data for faster instantiation.
## [br][br]
## [b]Note:[/b] Requires [member instantiation_cache_enabled] to be enabled in order to have any effect.
@export var instantiation_cache_meshes := true
## Saves [PaperPolygon2D] and [PaperSprite2D] renderables' 3D Z indices into scene data for faster instantiation.
## [br][br]
## [b]Note:[/b] Requires [member instantiation_cache_enabled] to be enabled in order to have any effect.
@export var instantiation_cache_z_indices := true
#endregion

#region Inspector/editor helpers
func _validate_property(property: Dictionary) -> void:
	var prop: StringName = property.name
	if prop == &"cast_shadow":
		# Make enums more readable.
		property.hint_string = "Off,On,Double-Sided,Shadows Only"
	elif prop == &"global_illumination_mode":
		# Make enums more readable.
		property.hint_string = "Disabled,Static,Dynamic"
	elif prop == &"refresh_skeleton":
		# Don't present an option to "rebuild" if there's nothing to build from.
		if not skeleton_2d: property.usage = PROPERTY_USAGE_NONE
	elif prop == &"skeleton_2d":
		# Makes no sense to be able to manually define skeleton_2d when it's
		# already defined by polygon_group. It'd just cause issues.
		if polygon_group != null: property.usage |= PROPERTY_USAGE_READ_ONLY
#endregion

#region Internal runtime state
@onready var _transform_cache := global_transform
var _cached_flip_state := false
var _real_layer_space := 0.0
var _suppress_setup := false
var _has_readied := false

enum _ZUpdate { ORDER = 1 << 0, POINTERS = 1 << 1, SCENE = 1 << 2 }

var _z_update_bits: int = 0
var _sorted_z_cache: Array[CanvasItem] = []
var _sorted_z_cache_valid: bool = false
@export_storage var _total_indices := 0

var _monitored_nodes: Array[Node] = []
var _bone_watchers: Array[PaperBoneWatcher2D] = []
var _camera_watcher: PaperCameraWatcher3D
var _warned_no_camera := false
var _billboard_camera: Node3D:
	set(value):
		if value == _billboard_camera: return
		_billboard_camera = value
		_billboard_camera_is_camera = _billboard_camera is Camera3D
		if is_node_ready():
			_handle_camera_tracker()
			_update_billboard_transform()
			billboard_camera_update.emit()
var _billboard_camera_is_camera: bool = _billboard_camera is Camera3D
var _camera_override_set := false
var _billboard_dirty := false

var _block_bone_setup_signal := false
var _bone_setup_check_pending := false
var _last_bone_signature: int = 0

var _index_update := false
var _rebuild_update := false

var _border_mat_connected := false
var _group_mat_connected := false

@onready var _mesh_inst_holder: Node3D = _add_mesh_inst_holder()
func _add_mesh_inst_holder() -> Node3D:
	var mih := Node3D.new(); mih.name = &"_MeshInstHolder"; add_child(mih, false, INTERNAL_MODE_FRONT); return mih

# Renderable lists
var _polygons: Array[PaperPolygon2D] = []
var _sprites: Array[PaperSprite2D] = []
var _renderables: Array[CanvasItem] = []

# Fast-instantiation caches
@export_storage var _stored_polygon_paths: Array[NodePath] = []
@export_storage var _stored_polygon_meshes: Array[ArrayMesh] = []
@export_storage var _stored_sprite_paths: Array[NodePath] = []
@export_storage var _stored_sprite_meshes: Array[ArrayMesh] = []

@export_storage var _stored_polygon_z_papers: PackedInt32Array = []
@export_storage var _stored_polygon_z_micro_groups: PackedFloat32Array = []
@export_storage var _stored_sprite_z_papers: PackedInt32Array = []
@export_storage var _stored_sprite_z_micro_groups: PackedFloat32Array = []
#endregion

#region Lifecycle
func _init() -> void:
	_cache_flip_state()
	process_priority = PaperConstants.ProcessPriority.SKELETON

func _process(_delta: float) -> void:
	_ensure_billboard_current()

func _ready() -> void:
	_ready_paper_skeleton()

func _ready_paper_skeleton() -> void:
	_assign_camera()
	if skeleton_2d: _setup_from_sources()
	_stored_polygon_paths.clear()
	_stored_polygon_meshes.clear()
	_stored_sprite_paths.clear()
	_stored_sprite_meshes.clear()
	_stored_polygon_z_papers.clear()
	_stored_polygon_z_micro_groups.clear()
	_stored_sprite_z_papers.clear()
	_stored_sprite_z_micro_groups.clear()
	_has_readied = true

func _notification(what: int) -> void:
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		if billboard_enabled:
			_check_billboard_update()
			_ensure_billboard_current()
	if what == NOTIFICATION_ENTER_TREE:
		if not is_node_ready(): return
		if billboard_enabled:
			if not _camera_override_set:
				_subscribe_to_viewport_bus()
				_autobind_camera_if_needed(true)
			if not _camera_watcher:
				_handle_camera_tracker()
	elif what == NOTIFICATION_EXIT_TREE:
		if billboard_enabled:
			_unsubscribe_to_viewport_bus()
		if _camera_watcher:
			_camera_watcher.unsubscribe(self)
			_camera_watcher = null
	elif what == NOTIFICATION_EDITOR_PRE_SAVE:
		if not instantiation_cache_enabled: return
		var p_size := _polygons.size()
		_stored_polygon_paths.resize(p_size)
		if instantiation_cache_meshes: 
			_stored_polygon_meshes.resize(p_size)
		if instantiation_cache_z_indices:
			_stored_polygon_z_papers.resize(p_size)
			_stored_polygon_z_micro_groups.resize(p_size)
		for i: int in p_size:
			var pp: PaperPolygon2D = _polygons[i]
			_stored_polygon_paths[i] = polygon_group.get_path_to(pp)
			if instantiation_cache_meshes:
				var mi := pp._mesh_instance_3d
				_stored_polygon_meshes[i] = (mi.mesh as ArrayMesh) if mi and mi.mesh else null
			if instantiation_cache_z_indices:
				_stored_polygon_z_papers[i] = pp._z_index_paper
				_stored_polygon_z_micro_groups[i] = pp._z_index_micro_group
		
		var s_size := _sprites.size()
		_stored_sprite_paths.resize(s_size)
		if instantiation_cache_meshes:
			_stored_sprite_meshes.resize(s_size)
		if instantiation_cache_z_indices:
			_stored_sprite_z_papers.resize(s_size)
			_stored_sprite_z_micro_groups.resize(s_size)
		for i: int in s_size:
			var spr: PaperSprite2D = _sprites[i]
			_stored_sprite_paths[i] = skeleton_2d.get_path_to(spr)
			if instantiation_cache_meshes:
				var mi := spr._mesh_instance_3d
				_stored_sprite_meshes[i] = (mi.mesh as ArrayMesh) if mi and mi.mesh else null
			if instantiation_cache_z_indices:
				_stored_sprite_z_papers[i] = spr._z_index_paper
				_stored_sprite_z_micro_groups[i] = spr._z_index_micro_group
	elif what == NOTIFICATION_EDITOR_POST_SAVE:
		_stored_polygon_paths.clear()
		_stored_sprite_paths.clear()
		if instantiation_cache_meshes: 
			_stored_polygon_meshes.clear()
			_stored_sprite_meshes.clear()
		if instantiation_cache_z_indices:
			_stored_polygon_z_papers.clear()
			_stored_polygon_z_micro_groups.clear()
			_stored_sprite_z_papers.clear()
			_stored_sprite_z_micro_groups.clear()
#endregion

#region Public setters/getters

func set_polygon_group(new_group: Node) -> void:
	if polygon_group == new_group: return
	if is_node_ready():
		if new_group == null:
			_clear_polygons_only()
			polygon_group = null
		elif _validate_polygon_group(new_group):
			_clear_polygons_only()
			_suppress_setup = true
			set_skeleton_2d(_find_skeleton_in_group(new_group))
			_suppress_setup = false
			polygon_group = new_group
			_setup_from_sources()
		notify_property_list_changed()
		if Engine.is_editor_hint() and is_inside_tree():
			update_gizmos()
	else:
		polygon_group = new_group

func get_polygon_group() -> Node: return polygon_group

func set_skeleton_2d(value: Skeleton2D) -> void:
	if skeleton_2d == value: return
	_disconnect_skeleton2d_setup_monitor()
	if polygon_group and not _suppress_setup:
		var auto_skel := _find_skeleton_in_group(polygon_group)
		if value != auto_skel:
			set_polygon_group(null)
	if is_node_ready():
		if value == null:
			_clear_sprites_only()
			skeleton_2d = null
		elif _suppress_setup or _validate_skeleton_2d_assignment(value):
			_clear_sprites_only()
			skeleton_2d = value
			if not _suppress_setup:
				_setup_from_sources()
		notify_property_list_changed()
		if Engine.is_editor_hint() and is_inside_tree():
			update_gizmos()
	else:
		skeleton_2d = value

func get_skeleton_2d() -> Skeleton2D: return skeleton_2d

func set_hide_sources(value: bool) -> void:
	hide_sources = value
	if is_node_ready(): _toggle_source_visibility()

func get_hide_sources() -> bool: return hide_sources

func set_layer_space(value: float) -> void:
	if layer_space == value: return
	layer_space = value
	if is_node_ready():
		_calc_layer_space()
		_apply_offsets_for_all_renderables()

func get_layer_space() -> float: return layer_space

func set_material(value: PaperMaterial) -> void:
	if material == value: return
	_disconnect_default_material_signals()
	material = value
	_connect_default_material_signals()
	if is_node_ready():
		_update_renderables_with_default_material()

func get_material() -> PaperMaterial: return material

func set_border_material(value: PaperMaterial) -> void:
	if border_material == value: return
	_disconnect_effect_material_signals(true)
	border_material = value
	_connect_effect_material_signals(true)
	if is_node_ready():
		for p: PaperPolygon2D in _polygons:
			_ensure_border_instance_for_renderable(p, PaperPolygon2D._TYPE)
			p._bind_effective_border_material()
		for s: PaperSprite2D in _sprites:
			_ensure_border_instance_for_renderable(s, PaperSprite2D._TYPE)
			s._bind_effective_border_material()
		_apply_offsets_for_all_renderables()

func get_border_material() -> PaperMaterial:
	return border_material

func set_group_material(value: PaperMaterial) -> void:
	if group_material == value: return
	_disconnect_effect_material_signals(false)
	group_material = value
	_connect_effect_material_signals(false)
	if is_node_ready():
		for p: PaperPolygon2D in _polygons:
			_ensure_group_instance_for_renderable(p, PaperPolygon2D._TYPE)
			p._bind_effective_group_material()
		for s: PaperSprite2D in _sprites:
			_ensure_group_instance_for_renderable(s, PaperSprite2D._TYPE)
			s._bind_effective_group_material()
		_apply_offsets_for_all_renderables()

func get_group_material() -> PaperMaterial:
	return group_material

func set_cast_shadow(value: GeometryInstance3D.ShadowCastingSetting) -> void:
	if cast_shadow == value: return
	cast_shadow = value
	if is_node_ready():
		for pp: PaperPolygon2D in _polygons:
			var mi := pp._mesh_instance_3d
			var bmi := pp._border_mesh_instance_3d
			var gmi := pp._group_mesh_instance_3d
			if mi: mi.cast_shadow = cast_shadow
			if bmi: bmi.cast_shadow = cast_shadow
			if gmi: gmi.cast_shadow = cast_shadow
		for spr: PaperSprite2D in _sprites:
			var mi := spr._mesh_instance_3d
			var bmi := spr._border_mesh_instance_3d
			var gmi := spr._group_mesh_instance_3d
			if mi: mi.cast_shadow = cast_shadow
			if bmi: bmi.cast_shadow = cast_shadow
			if gmi: gmi.cast_shadow = cast_shadow

func get_cast_shadow() -> GeometryInstance3D.ShadowCastingSetting: return cast_shadow

func set_global_illumination_mode(value: GeometryInstance3D.GIMode) -> void:
	if global_illumination_mode == value: return
	global_illumination_mode = value
	if is_node_ready():
		for pp: PaperPolygon2D in _polygons:
			var mi := pp._mesh_instance_3d
			var bmi := pp._border_mesh_instance_3d
			var gmi := pp._group_mesh_instance_3d
			if mi: mi.gi_mode = global_illumination_mode
			if bmi: bmi.gi_mode = global_illumination_mode
			if gmi: gmi.gi_mode = global_illumination_mode
		for spr: PaperSprite2D in _sprites:
			var mi := spr._mesh_instance_3d
			var bmi := spr._border_mesh_instance_3d
			var gmi := spr._group_mesh_instance_3d
			if mi: mi.gi_mode = global_illumination_mode
			if bmi: bmi.gi_mode = global_illumination_mode
			if gmi: gmi.gi_mode = global_illumination_mode

func get_global_illumination_mode() -> GeometryInstance3D.GIMode: return global_illumination_mode

func set_render_layers(value: int) -> void:
	if render_layers == value: return
	render_layers = value
	if is_node_ready():
		for pp: PaperPolygon2D in _polygons:
			var mi := pp._mesh_instance_3d
			var bmi := pp._border_mesh_instance_3d
			var gmi := pp._group_mesh_instance_3d
			if mi: mi.layers = render_layers
			if bmi: bmi.layers = render_layers
			if gmi: gmi.layers = render_layers
		for spr: PaperSprite2D in _sprites:
			var mi := spr._mesh_instance_3d
			var bmi := spr._border_mesh_instance_3d
			var gmi := spr._group_mesh_instance_3d
			if mi: mi.layers = render_layers
			if bmi: bmi.layers = render_layers
			if gmi: gmi.layers = render_layers

func get_render_layers() -> int: return render_layers

func set_flip(value: bool) -> void:
	flip = value
	if is_node_ready():
		_update_flip_transform()
		if _cache_flip_state(): flipped.emit()

func get_flip() -> bool: return flip

func set_flip_rotate(value: float) -> void:
	if flip_rotate == value: return
	flip_rotate = value
	if is_node_ready():
		_update_flip_transform()
		if _cache_flip_state(): flipped.emit()
		_mark_billboard_dirty()

func get_flip_rotate() -> float: return flip_rotate

func set_billboard_enabled(value: bool) -> void:
	if billboard_enabled == value: return
	billboard_enabled = value
	if is_node_ready():
		if billboard_enabled and not _camera_override_set:
			_subscribe_to_viewport_bus()
			_autobind_camera_if_needed(true)
		else:
			_unsubscribe_to_viewport_bus()
			if not billboard_enabled:
				_mesh_inst_holder.basis = Basis.IDENTITY
				billboard_update.emit()
		_handle_camera_tracker()
		notify_property_list_changed()

func get_billboard_enabled() -> bool: return billboard_enabled

func set_billboard_camera_override(value: Node3D) -> void:
	if billboard_camera_override == value: return
	billboard_camera_override = value
	_camera_override_set = billboard_camera_override != null
	if is_node_ready() and billboard_enabled:
		if _camera_override_set:
			_unsubscribe_to_viewport_bus()
		else:
			_subscribe_to_viewport_bus()
		_autobind_camera_if_needed(true)

func get_billboard_camera_override() -> Node3D: return billboard_camera_override

func set_billboard_direction(value: BillboardDirection) -> void:
	if billboard_direction == value: return
	billboard_direction = value
	_is_dir_position = billboard_direction == BillboardDirection.POSITION
	if is_node_ready():
		_mark_billboard_dirty()
		if _camera_watcher:
			_camera_watcher.on_subscriber_config_changed()

func get_billboard_direction() -> BillboardDirection: return billboard_direction

func set_billboard_track_offset(value: bool) -> void:
	if billboard_track_offset == value: return
	billboard_track_offset = value
	if is_node_ready():
		_mark_billboard_dirty()
		if _camera_watcher:
			_camera_watcher.on_subscriber_config_changed()

func get_billboard_track_offset() -> bool: return billboard_track_offset

func set_billboard_axis(value: BillboardAxis) -> void:
	if billboard_axis == value: return
	billboard_axis = value
	_is_axis_local = billboard_axis == BillboardAxis.LOCAL
	_is_axis_upright = billboard_axis == BillboardAxis.GLOBAL_UPRIGHT
	if is_node_ready(): _mark_billboard_dirty()

func get_billboard_axis() -> BillboardAxis: return billboard_axis

func set_track_child_order(value: bool) -> void:
	if track_child_order == value: return
	track_child_order = value
	if not is_node_ready(): return
	if track_child_order:
		if skeleton_2d: _connect_child_order_recursive(skeleton_2d)
		if polygon_group: _connect_child_order_recursive(polygon_group)
		_defer_scene_sort_update()
	else:
		_disconnect_child_order_recursive()

func get_track_child_order() -> bool: return track_child_order

func set_adjust_sorting_offset(value: bool) -> void:
	if adjust_sorting_offset == value: return
	adjust_sorting_offset = value
	if not is_node_ready(): return
	_apply_offsets_for_all_renderables()

func get_adjust_sorting_offset() -> bool: return adjust_sorting_offset
#endregion

#region Build/teardown
func _setup_from_sources() -> void:
	_collect_polygons()
	_collect_sprites()
	_rebuild_renderables_cache()
	if track_child_order:
		_connect_child_order_recursive(skeleton_2d)
		_connect_child_order_recursive(polygon_group)
	_setup_skeleton3d()
	_calc_layer_space()
	if not _try_restore_z_caches():
		_recalculate_z_indices()
	_create_all_renderable_meshes()
	_update_skeleton3d()
	_attach_bone_watchers()
	_update_flip_transform()
	if hide_sources and _has_readied: _toggle_source_visibility()
	_connect_skeleton2d_setup_monitor()
	skeleton_constructed.emit()

func _clear_session() -> void:
	_disconnect_child_order_recursive()
	if hide_sources: _toggle_source_visibility(true)
	for pp: PaperPolygon2D in _polygons:
		if pp._border_mesh_instance_3d:
			pp._border_mesh_instance_3d.queue_free()
			pp._border_mesh_instance_3d = null
		if pp._group_mesh_instance_3d:
			pp._group_mesh_instance_3d.queue_free()
			pp._group_mesh_instance_3d = null
		var mi := pp._mesh_instance_3d
		pp._mesh_instance_3d = null
		pp._z_index_paper = -1
		pp._skeleton = null
		if mi: mi.free()
	for spr: PaperSprite2D in _sprites:
		if spr._border_mesh_instance_3d:
			spr._border_mesh_instance_3d.queue_free()
			spr._border_mesh_instance_3d = null
		if spr._group_mesh_instance_3d:
			spr._group_mesh_instance_3d.queue_free()
			spr._group_mesh_instance_3d = null
		var mi := spr._mesh_instance_3d
		spr._mesh_instance_3d = null
		spr._z_index_paper = -1
		spr._skeleton = null
		if mi: mi.free()
	clear_bones()
	_detach_bone_watchers()
	_polygons.clear()
	_sprites.clear()
	_renderables.clear()
	_sorted_z_cache.clear()
	_sorted_z_cache_valid = false
	_z_update_bits = 0
	skeleton_deconstructed.emit()
#endregion

#region Renderable cache and mesh instance helpers
func _rebuild_renderables_cache() -> void:
	_renderables.clear()
	_renderables.append_array(_polygons)
	_renderables.append_array(_sprites)

static func _bind_material_for_renderable(r: Object, type: PaperConstants.RenderableType) -> void:
	var mi: MeshInstance3D
	var active: PaperMaterial = null
	if type == PaperPolygon2D._TYPE:
		var p: PaperPolygon2D = r
		mi = p._mesh_instance_3d
		if not mi: return
		if p._is_shader_override_mode():
			mi.material_override = p.shader_material_override
			return
		active = p.get_active_material()
	else:
		var s: PaperSprite2D = r
		mi = s._mesh_instance_3d
		if not mi: return
		if s._is_shader_override_mode():
			mi.material_override = s.shader_material_override
			return
		active = s.get_active_material()
	mi.material_override = (
		active._create_shader_material_for_renderable(r, type) if active
		else PaperConstants.build_default_shader_material(r, type)
	)

func _new_mesh_instance_for(r: CanvasItem, type: PaperConstants.RenderableType, mesh: Mesh, skin: Skin = null, name_suffix := "_mi_3d") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = r.name + name_suffix
	mi.mesh = mesh
	mi.skin = skin
	mi.skeleton = get_path()
	mi.cast_shadow = cast_shadow
	mi.gi_mode = global_illumination_mode
	mi.layers = render_layers
	mi.visible = r.is_visible_in_tree()
	mi.sorting_use_aabb_center = false
	_mesh_inst_holder.add_child(mi, false, INTERNAL_MODE_FRONT)
	
	PaperConstants.apply_paper_instance_uniforms(mi, r, type)
	return mi

func _attach_mesh_instance_for(r: Object, type: PaperConstants.RenderableType, mesh: Mesh, skin: Skin = null) -> MeshInstance3D:
	var mi := _new_mesh_instance_for(r, type, mesh, skin, "_mi_3d")
	var old: MeshInstance3D
	if type == PaperPolygon2D._TYPE:
		old = r._mesh_instance_3d
		r._mesh_instance_3d = mi
	else:
		old = r._mesh_instance_3d
		r._mesh_instance_3d = mi
	if old: old.queue_free()
	return mi

func _toggle_source_visibility(show_sources: bool = not hide_sources, type: int = -1) -> void:
	const INVISIBILITY_LAYER := 0
	if show_sources:
		if type == PaperPolygon2D._TYPE or type == -1:
			for pp: PaperPolygon2D in _polygons:
				if not pp: continue
				if pp.visibility_layer == INVISIBILITY_LAYER:
					pp.visibility_layer = pp._original_visibility_layer
		if type == PaperSprite2D._TYPE or type == -1:
			for spr: PaperSprite2D in _sprites:
				if not spr: continue
				if spr.visibility_layer == INVISIBILITY_LAYER:
					spr.visibility_layer = spr._original_visibility_layer
	else:
		if type == PaperPolygon2D._TYPE or type == -1:
			for pp: PaperPolygon2D in _polygons:
				if not pp: continue
				pp._original_visibility_layer = pp.visibility_layer
				pp.visibility_layer = INVISIBILITY_LAYER
		if type == PaperSprite2D._TYPE or type == -1:
			for spr: PaperSprite2D in _sprites:
				if not spr: continue
				spr._original_visibility_layer = spr.visibility_layer
				spr.visibility_layer = INVISIBILITY_LAYER
#endregion

#region Material management
func _connect_default_material_signals() -> void:
	if not material: return
	if not material.pass_parameter_changed.is_connected(_on_default_pass_param_changed):
		material.pass_parameter_changed.connect(_on_default_pass_param_changed)
	if not material.pass_structure_changed.is_connected(_on_default_pass_struct_changed):
		material.pass_structure_changed.connect(_on_default_pass_struct_changed)

func _disconnect_default_material_signals() -> void:
	if not material: return
	if material.pass_parameter_changed.is_connected(_on_default_pass_param_changed):
		material.pass_parameter_changed.disconnect(_on_default_pass_param_changed)
	if material.pass_structure_changed.is_connected(_on_default_pass_struct_changed):
		material.pass_structure_changed.disconnect(_on_default_pass_struct_changed)

func _connect_effect_material_signals(is_border: bool) -> void:
	if is_border:
		if border_material and not _border_mat_connected:
			if not border_material.pass_parameter_changed.is_connected(_on_border_pass_param_changed):
				border_material.pass_parameter_changed.connect(_on_border_pass_param_changed)
			if not border_material.pass_structure_changed.is_connected(_on_border_pass_struct_changed):
				border_material.pass_structure_changed.connect(_on_border_pass_struct_changed)
			_border_mat_connected = true
	else:
		if group_material and not _group_mat_connected:
			if not group_material.pass_parameter_changed.is_connected(_on_group_pass_param_changed):
				group_material.pass_parameter_changed.connect(_on_group_pass_param_changed)
			if not group_material.pass_structure_changed.is_connected(_on_group_pass_struct_changed):
				group_material.pass_structure_changed.connect(_on_group_pass_struct_changed)
			_group_mat_connected = true

func _disconnect_effect_material_signals(is_border: bool) -> void:
	if is_border:
		if border_material and _border_mat_connected:
			if border_material.pass_parameter_changed.is_connected(_on_border_pass_param_changed):
				border_material.pass_parameter_changed.disconnect(_on_border_pass_param_changed)
			if border_material.pass_structure_changed.is_connected(_on_border_pass_struct_changed):
				border_material.pass_structure_changed.disconnect(_on_border_pass_struct_changed)
		_border_mat_connected = false
	else:
		if group_material and _group_mat_connected:
			if group_material.pass_parameter_changed.is_connected(_on_group_pass_param_changed):
				group_material.pass_parameter_changed.disconnect(_on_group_pass_param_changed)
			if group_material.pass_structure_changed.is_connected(_on_group_pass_struct_changed):
				group_material.pass_structure_changed.disconnect(_on_group_pass_struct_changed)
		_group_mat_connected = false

func _on_default_pass_param_changed(pass_idx: int, param_name: StringName, value: Variant) -> void:
	for pp: PaperPolygon2D in _polygons:
		if pp.uses_skeleton_material():
			pp._update_material_param_at_pass(pass_idx, param_name, value)
	for spr: PaperSprite2D in _sprites:
		if spr.uses_skeleton_material():
			spr._update_material_param_at_pass(pass_idx, param_name, value)

func _on_default_pass_struct_changed(pass_idx: int, bits: int) -> void:
	var rebuild_chain: bool = bits & (PaperMaterial.Struct.SHADER | PaperMaterial.Struct.NEXT_PASS)
	var render_priority: bool = bits & PaperMaterial.Struct.RENDER_PRIORITY
	if render_priority and not rebuild_chain and not material: return
	for pp: PaperPolygon2D in _polygons:
		if not pp or not pp.uses_skeleton_material(): continue
		if rebuild_chain:
			pp._rebuild_shader_chain_from(pass_idx)
		if render_priority:
			if not material: return
			var target: ShaderMaterial = pp._shader_material_at_pass(pass_idx)
			if target:
				var pm := material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority
	for spr: PaperSprite2D in _sprites:
		if not spr or not spr.uses_skeleton_material(): continue
		if rebuild_chain:
			spr._rebuild_shader_chain_from(pass_idx)
		if render_priority:
			if not material: return
			var target: ShaderMaterial = spr._shader_material_at_pass(pass_idx)
			if target:
				var pm := material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority

func _on_border_pass_param_changed(pass_idx: int, param_name: StringName, value: Variant) -> void:
	for p: PaperPolygon2D in _polygons:
		if p._border_mesh_instance_3d and p.border_shader_material_override == null and p.border_paper_material_override == null:
			p._update_border_material_param_at_pass(pass_idx, param_name, value)
	for s: PaperSprite2D in _sprites:
		if s._border_mesh_instance_3d and s.border_shader_material_override == null and s.border_paper_material_override == null:
			s._update_border_material_param_at_pass(pass_idx, param_name, value)

func _on_border_pass_struct_changed(pass_idx: int, bits: int) -> void:
	var rebuild_chain: bool = bits & (PaperMaterial.Struct.SHADER | PaperMaterial.Struct.NEXT_PASS)
	var render_priority: bool = bits & PaperMaterial.Struct.RENDER_PRIORITY
	for p: PaperPolygon2D in _polygons:
		if not p._border_mesh_instance_3d: continue
		if p.border_shader_material_override != null or p.border_paper_material_override != null: continue
		if rebuild_chain: p._rebuild_border_shader_chain_from(pass_idx)
		if render_priority:
			var target := p._border_shader_material_at_pass(pass_idx)
			if target and border_material:
				var pm := border_material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority
	for s: PaperSprite2D in _sprites:
		if not s._border_mesh_instance_3d: continue
		if s.border_shader_material_override != null or s.border_paper_material_override != null: continue
		if rebuild_chain: s._rebuild_border_shader_chain_from(pass_idx)
		if render_priority:
			var target := s._border_shader_material_at_pass(pass_idx)
			if target and border_material:
				var pm := border_material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority

func _on_group_pass_param_changed(pass_idx: int, param_name: StringName, value: Variant) -> void:
	for p: PaperPolygon2D in _polygons:
		if p._group_mesh_instance_3d and p.group_shader_material_override == null and p.group_paper_material_override == null:
			p._update_group_material_param_at_pass(pass_idx, param_name, value)
	for s: PaperSprite2D in _sprites:
		if s._group_mesh_instance_3d and s.group_shader_material_override == null and s.group_paper_material_override == null:
			s._update_group_material_param_at_pass(pass_idx, param_name, value)

func _on_group_pass_struct_changed(pass_idx: int, bits: int) -> void:
	var rebuild_chain: bool = bits & (PaperMaterial.Struct.SHADER | PaperMaterial.Struct.NEXT_PASS)
	var render_priority: bool = bits & PaperMaterial.Struct.RENDER_PRIORITY
	for p: PaperPolygon2D in _polygons:
		if not p._group_mesh_instance_3d: continue
		if p.group_shader_material_override != null or p.group_paper_material_override != null: continue
		if rebuild_chain: p._rebuild_group_shader_chain_from(pass_idx)
		if render_priority:
			var target := p._group_shader_material_at_pass(pass_idx)
			if target and group_material:
				var pm := group_material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority
	for s: PaperSprite2D in _sprites:
		if not s._group_mesh_instance_3d: continue
		if s.group_shader_material_override != null or s.group_paper_material_override != null: continue
		if rebuild_chain: s._rebuild_group_shader_chain_from(pass_idx)
		if render_priority:
			var target := s._group_shader_material_at_pass(pass_idx)
			if target and group_material:
				var pm := group_material.get_pass(pass_idx)
				if pm: target.render_priority = pm.render_priority
#endregion

#region Effect mesh instances
func _clone_effect_from_base(r: CanvasItem, type: PaperConstants.RenderableType, base_mi: MeshInstance3D, suffix: String) -> MeshInstance3D:
	return _new_mesh_instance_for(r, type, base_mi.mesh, base_mi.skin, suffix)

func _ensure_effect_instances_for_renderable(r: CanvasItem, type: PaperConstants.RenderableType) -> void:
	_ensure_border_instance_for_renderable(r, type)
	_ensure_group_instance_for_renderable(r, type)

func _ensure_border_instance_for_renderable(r: CanvasItem, type: PaperConstants.RenderableType) -> void:
	_ensure_effect_instance_for_renderable(r, false, type)

func _ensure_group_instance_for_renderable(r: CanvasItem, type: PaperConstants.RenderableType) -> void:
	_ensure_effect_instance_for_renderable(r, true, type)

func _ensure_effect_instance_for_renderable(r: CanvasItem, is_group: bool, type: PaperConstants.RenderableType) -> void:
	var base_mi: MeshInstance3D = null
	var want_effect  := false
	var has_effect_mi := false
	if type == PaperPolygon2D._TYPE:
		var p: PaperPolygon2D = r
		base_mi = p._mesh_instance_3d
		if not base_mi: return
		if is_group:
			has_effect_mi = is_instance_valid(p._group_mesh_instance_3d)
			want_effect = p.group_mesh_enabled and (
				group_material or
				p.group_shader_material_override or 
				p.group_paper_material_override
			)
		else:
			has_effect_mi = is_instance_valid(p._border_mesh_instance_3d)
			want_effect = p.border_mesh_enabled and (
				border_material or
				p.border_shader_material_override or 
				p.border_paper_material_override
			)
	else:
		var s: PaperSprite2D = r
		base_mi = s._mesh_instance_3d
		if not base_mi: return
		if is_group:
			has_effect_mi = is_instance_valid(s._group_mesh_instance_3d)
			want_effect = s.group_mesh_enabled and (
				group_material or 
				s.group_shader_material_override or 
				s.group_paper_material_override
			)
		else:
			has_effect_mi = is_instance_valid(s._border_mesh_instance_3d)
			want_effect = s.border_mesh_enabled and (
				border_material or
				s.border_shader_material_override or 
				s.border_paper_material_override
			)
	
	if want_effect:
		if not has_effect_mi:
			var mi := _clone_effect_from_base(r, type, base_mi, "_mi_3d_group" if is_group else "_mi_3d_border")
			if type == PaperPolygon2D._TYPE:
				var p: PaperPolygon2D = r
				if is_group:
					p._group_mesh_instance_3d = mi
					p._bind_effective_group_material()
				else:
					p._border_mesh_instance_3d = mi
					p._bind_effective_border_material()
			else:
				var s: PaperSprite2D = r
				if is_group:
					s._group_mesh_instance_3d = mi
					s._bind_effective_group_material()
				else:
					s._border_mesh_instance_3d = mi
					s._bind_effective_border_material()
	elif has_effect_mi:
		if type == PaperPolygon2D._TYPE:
			var p: PaperPolygon2D = r
			if is_group:
				p._group_mesh_instance_3d.queue_free()
				p._group_mesh_instance_3d = null
				p._unbind_effective_group_material()
			else:
				p._border_mesh_instance_3d.queue_free()
				p._border_mesh_instance_3d = null
				p._unbind_effective_border_material()
		else:
			var s: PaperSprite2D = r
			if is_group:
				s._group_mesh_instance_3d.queue_free()
				s._group_mesh_instance_3d = null
				s._unbind_effective_group_material()
			else:
				s._border_mesh_instance_3d.queue_free()
				s._border_mesh_instance_3d = null
				s._unbind_effective_border_material()

func _sync_effect_mesh_resources_for_renderable(r: CanvasItem, type: PaperConstants.RenderableType) -> void:
	var base_mi: MeshInstance3D = null
	var border_mi: MeshInstance3D = null
	var group_mi: MeshInstance3D = null
	if type == PaperPolygon2D._TYPE:
		var p := r as PaperPolygon2D
		base_mi = p._mesh_instance_3d
		border_mi = p._border_mesh_instance_3d
		group_mi = p._group_mesh_instance_3d
	else:
		var s := r as PaperSprite2D
		base_mi = s._mesh_instance_3d
		border_mi = s._border_mesh_instance_3d
		group_mi = s._group_mesh_instance_3d
	if not base_mi: return
	if border_mi:
		border_mi.mesh = base_mi.mesh
		border_mi.skin = base_mi.skin
		border_mi.skeleton = get_path()
	if group_mi:
		group_mi.mesh = base_mi.mesh
		group_mi.skin = base_mi.skin
		group_mi.skeleton = get_path()

func _apply_offsets_for_renderable(r: CanvasItem, type: PaperConstants.RenderableType) -> void:
	var z := 0
	var group_f := 0.0
	var base_mi: MeshInstance3D = null
	var border_mi: MeshInstance3D = null
	var group_mi: MeshInstance3D = null
	if type == PaperPolygon2D._TYPE:
		var p: PaperPolygon2D = r
		z = p.get_paper_idx()
		group_f = float(p.get_group_idx()) - p.get_group_micro_idx()
		base_mi = p._mesh_instance_3d
		border_mi = p._border_mesh_instance_3d
		group_mi = p._group_mesh_instance_3d
	else:
		var s: PaperSprite2D = r
		z = s.get_paper_idx()
		group_f = float(s.get_group_idx()) - s.get_group_micro_idx()
		base_mi = s._mesh_instance_3d
		border_mi = s._border_mesh_instance_3d
		group_mi = s._group_mesh_instance_3d
	
	var off_base := (float(z) - 0.5 * float(_total_indices)) * _real_layer_space
	if base_mi:
		base_mi.position.z = off_base
		base_mi.sorting_offset = off_base if adjust_sorting_offset else 0.0
	if border_mi:
		var off_b := off_base - float(_total_indices) * _real_layer_space
		border_mi.position.z = off_b
		border_mi.sorting_offset = off_b if adjust_sorting_offset else 0.0
	if group_mi:
		var off_g := (group_f - 0.5 * float(_total_indices)) * _real_layer_space
		group_mi.position.z = off_g
		group_mi.sorting_offset = off_g if adjust_sorting_offset else 0.0

func _apply_offsets_for_all_renderables() -> void:
	for p: PaperPolygon2D in _polygons:
		_apply_offsets_for_renderable(p, PaperPolygon2D._TYPE)
	for s: PaperSprite2D in _sprites:
		_apply_offsets_for_renderable(s, PaperSprite2D._TYPE)
#endregion

#region Z-indexing
class _RAndPath:
	var r: CanvasItem
	var path: PackedInt32Array
	func _init(_r: CanvasItem, _path := PackedInt32Array()) -> void:
		r = _r
		path = _path

class _ZAndPath:
	var z: int
	var path: PackedInt32Array
	func _init(_z := 0, _path := PackedInt32Array()) -> void:
		z = _z
		path = _path

func _recalculate_z_indices() -> void:
	_rebuild_sorted_z_cache()
	_assign_indices_from_sorted(_sorted_z_cache)

func _rebuild_sorted_z_cache() -> void:
	_sorted_z_cache.clear()
	var root := _lowest_common_ancestor(polygon_group, skeleton_2d)
	if not root:
		root = polygon_group if polygon_group else skeleton_2d
		if not root:
			root = (get_tree().get_edited_scene_root() if Engine.is_editor_hint() else get_tree().get_root())
	var z_groups: Dictionary[int, Array] = {}
	for r: CanvasItem in _renderables:
		var result := _get_z_and_path(root, r)
		var z := result.z
		var group = z_groups.get(z)
		if group == null:
			group = []
			z_groups[z] = group as Array
		(group as Array).append(_RAndPath.new(r, result.path))
	var z_keys := z_groups.keys()
	z_keys.sort()
	var total_count := 0
	for arr: Array in z_groups.values():
		total_count += arr.size()
	_sorted_z_cache.resize(total_count)
	var write_idx := 0
	for z: int in z_keys:
		var group: Array = z_groups[z]
		group.sort_custom(_compare_renderables_by_path)
		for r_and_path: _RAndPath in group:
			_sorted_z_cache[write_idx] = r_and_path.r
			write_idx += 1
	_sorted_z_cache_valid = true

func _assign_indices_from_sorted(sorted: Array[CanvasItem]) -> void:
	var root_map: Dictionary[Object, int] = {}
	var z_baskets: Array[Array] = []
	for r: Object in sorted:
		var root_target: Object = null
		if r is PaperPolygon2D: root_target = (r as PaperPolygon2D).get_root_target()
		else: root_target = (r as PaperSprite2D).get_root_target()
		var basket_idx: int
		if root_map.has(root_target):
			basket_idx = root_map[root_target]
		else:
			basket_idx = z_baskets.size()
			root_map[root_target] = basket_idx
			z_baskets.append([])
		z_baskets[basket_idx].append(r)
	for z_id: int in z_baskets.size():
		for r: Object in z_baskets[z_id]:
			if r is PaperPolygon2D: (r as PaperPolygon2D)._z_index_paper = z_id
			else: (r as PaperSprite2D)._z_index_paper = z_id
	var group_map: Dictionary[int, Array] = {}
	for r: Object in sorted:
		var gid := 0
		if r is PaperPolygon2D: gid = (r as PaperPolygon2D).get_group_idx()
		else: gid = (r as PaperSprite2D).get_group_idx()
		var group = group_map.get(gid)
		if group == null:
			group = []
			group_map[gid] = group as Array
		(group as Array).append(r)
	for group: Array in group_map.values():
		var n := group.size()
		if n == 1:
			var r0: Object = group[0]
			if r0 is PaperPolygon2D: (r0 as PaperPolygon2D)._z_index_micro_group = 0.5
			else: (r0 as PaperSprite2D)._z_index_micro_group = 0.5
		else:
			var n_minus_1 := float(n - 1)
			for i: int in n:
				var t := float(i) / n_minus_1
				var v := 0.4 + (t * 0.2)
				var ri: Object = group[i]
				if ri is PaperPolygon2D: (ri as PaperPolygon2D)._z_index_micro_group = v
				else: (ri as PaperSprite2D)._z_index_micro_group = v
	_total_indices = z_baskets.size()

func _try_restore_z_caches() -> bool:
	var ok_polys := _stored_polygon_z_papers.size() == _polygons.size() and \
					_stored_polygon_z_micro_groups.size() == _polygons.size()
	var ok_sprites := _stored_sprite_z_papers.size() == _sprites.size() and \
					  _stored_sprite_z_micro_groups.size() == _sprites.size()
	if not (ok_polys and ok_sprites): return false
	
	for i: int in _polygons.size():
		var p := _polygons[i]
		p._z_index_paper = _stored_polygon_z_papers[i]
		p._z_index_micro_group = _stored_polygon_z_micro_groups[i]
	for i: int in _sprites.size():
		var s := _sprites[i]
		s._z_index_paper = _stored_sprite_z_papers[i]
		s._z_index_micro_group = _stored_sprite_z_micro_groups[i]
	
	_sorted_z_cache_valid = true
	return true

func _mark_dirty(bits: int) -> void:
	_z_update_bits |= bits
	if not _index_update:
		_on_deferred_recalc_indices.call_deferred()
		_index_update = true

func _defer_z_index_update() -> void:
	_mark_dirty(_ZUpdate.ORDER)

func _defer_index_pointer_update() -> void:
	_mark_dirty(_ZUpdate.POINTERS)

func _defer_scene_sort_update() -> void:
	_mark_dirty(_ZUpdate.SCENE)

func _on_deferred_recalc_indices() -> void:
	if not is_inside_tree():
		_z_update_bits = 0
		_index_update = false
		return
	var need_full := bool(_z_update_bits & (_ZUpdate.ORDER | _ZUpdate.SCENE)) or not _sorted_z_cache_valid
	if need_full: _rebuild_sorted_z_cache()
	_assign_indices_from_sorted(_sorted_z_cache)
	_z_update_bits = 0
	_index_update = false
	_apply_offsets_for_all_renderables()

func _connect_child_order_recursive(node: Node) -> void:
	if not is_instance_valid(node): return
	if not node.child_order_changed.is_connected(_defer_scene_sort_update):
		node.child_order_changed.connect(_defer_scene_sort_update)
		_monitored_nodes.append(node)
	for child: Node in node.get_children():
		_connect_child_order_recursive(child)

func _disconnect_child_order_recursive() -> void:
	for node: Node in _monitored_nodes:
		if is_instance_valid(node) and node.child_order_changed.is_connected(_defer_scene_sort_update):
			node.child_order_changed.disconnect(_defer_scene_sort_update)
	_monitored_nodes.clear()

func _calc_layer_space() -> float:
	_real_layer_space = layer_space * LAYER_SCALE
	return _real_layer_space

static func _get_z_and_path(root: Node, ci: CanvasItem) -> _ZAndPath:
	var depth := 0
	var n: Node = ci
	while n and n != root:
		depth += 1
		n = n.get_parent()
	var path := PackedInt32Array()
	path.resize(depth)
	var sum_rel := 0
	var absolute_z := -1
	var has_absolute := false
	n = ci
	var idx := depth - 1
	while idx >= 0:
		path[idx] = n.get_index()
		idx -= 1
		if n is CanvasItem:
			var node_ci: CanvasItem = n
			var zi := node_ci.get_z_index()
			if node_ci.is_z_relative():
				sum_rel += zi
			elif not has_absolute:
				absolute_z = zi
				has_absolute = true
		n = n.get_parent()
	var final_z := (absolute_z if has_absolute else 0) + sum_rel
	return _ZAndPath.new(final_z, path)

static func _lowest_common_ancestor(a: Node, b: Node) -> Node:
	if not a: return b
	if not b: return a
	if a == b: return a
	var seen: Dictionary[Node, bool] = {}
	var na := a
	var nb := b
	while na or nb:
		if na:
			if seen.has(na): return na
			seen[na] = true
			na = na.get_parent()
		if nb:
			if seen.has(nb): return nb
			seen[nb] = true
			nb = nb.get_parent()
	return null

static func _compare_renderables_by_path(a: _RAndPath, b: _RAndPath) -> bool:
	return _less_index_path(a.path, b.path)

static func _less_index_path(a: PackedInt32Array, b: PackedInt32Array) -> bool:
	var m := mini(a.size(), b.size())
	for i: int in m:
		if a[i] != b[i]:
			return a[i] < b[i]
	return a.size() < b.size()
#endregion

#region Flip bone transform update/cache
## Returns true when the rig is currently considered flipped from either [member flip_rotate] or [member flip].
func is_flipped() -> bool: return _cached_flip_state

func _update_flip_transform() -> void:
	if FLIP_BONE_IDX > get_bone_count() - 1: return
	var yaw_eff := flip_rotate + (PI if flip else 0.0)
	var t := Transform3D.IDENTITY.rotated(Vector3.UP, yaw_eff)
	set_bone_pose(FLIP_BONE_IDX, t)

func _cache_flip_state() -> bool:
	var new_flip_state := (flip) != (cos(flip_rotate) < 0)
	if _cached_flip_state == new_flip_state: return false
	_cached_flip_state = new_flip_state
	return true
#endregion

#region Skeleton2D → Skeleton3D bridge
func _setup_skeleton3d() -> void:
	if (is_node_ready() and get_bone_count() == 0) or \
	   (skeleton_2d and skeleton_2d.get_bone_count() + EX_BONES != get_bone_count()):
		clear_bones()
		add_bone(FLIP_BONE_NAME)
		for idx: int in EX_BONES:
			set_bone_rest(idx, Transform3D.IDENTITY)
			reset_bone_pose(idx)
		if skeleton_2d:
			for i: int in skeleton_2d.get_bone_count():
				var b := skeleton_2d.get_bone(i)
				var bi := add_bone(b.name)
				var rest := _transform_2d_to_3d(b.rest)
				set_bone_rest(bi, rest)
				reset_bone_pose(bi)
				var p := b.get_parent()
				var pi := get_3d_bone_idx(p) if p is Bone2D else FLIP_BONE_IDX
				set_bone_parent(bi, pi)

## Returns the sum of [method Bone2D.get_index_in_skeleton] and [constant EX_BONES].
static func get_3d_bone_idx(bone: Bone2D) -> int:
	return bone.get_index_in_skeleton() + EX_BONES

func _attach_bone_watchers() -> void:
	_detach_bone_watchers()
	var bone_count := skeleton_2d.get_bone_count()
	_bone_watchers.resize(bone_count)
	for i: int in bone_count:
		var b := skeleton_2d.get_bone(i)
		var w := PaperBoneWatcher2D.new(b, self)
		_bone_watchers[i] = w

func _detach_bone_watchers() -> void:
	for w in _bone_watchers:
		if w: w.queue_free()
	_bone_watchers.clear()

func _update_skeleton3d() -> void:
	for i: int in skeleton_2d.get_bone_count():
		var b := skeleton_2d.get_bone(i)
		_update_bone_transform(b)

func _update_bone_transform(bone: Bone2D) -> void:
	var idx := get_3d_bone_idx(bone)
	var local3 := _transform_2d_to_3d(bone.get_transform())
	set_bone_pose(idx, local3)

static func _transform_2d_to_3d(t2d: Transform2D, z := 0.0) -> Transform3D:
	var basis3 := Basis(
		Vector3(t2d.x.x, -t2d.x.y, 0.0),
		Vector3(-t2d.y.x,  t2d.y.y, 0.0),
		Vector3.BACK
	)
	var o := t2d.origin
	var origin3 := Vector3(o.x * PX_SCALE, -o.y * PX_SCALE, z)
	return Transform3D(basis3, origin3)

func _compute_bone_setup_signature() -> int:
	if not skeleton_2d: return 0
	var count := skeleton_2d.get_bone_count()
	var h := PaperConstants.h64(count)
	for i: int in count:
		var b: Bone2D = skeleton_2d.get_bone(i)
		var p := b.get_parent()
		var parent_idx := ((p as Bone2D).get_index_in_skeleton() if p is Bone2D else -1)
		h = PaperConstants.h64(hash(b.name), h)
		h = PaperConstants.h64(parent_idx, h)
		h = PaperConstants.h64(PaperConstants.t2d_sig(b.rest), h)
	return h

func _connect_skeleton2d_setup_monitor() -> void:
	if not skeleton_2d: return
	if not skeleton_2d.bone_setup_changed.is_connected(_on_skeleton2d_bone_setup_changed):
		skeleton_2d.bone_setup_changed.connect(_on_skeleton2d_bone_setup_changed)
	_last_bone_signature = _compute_bone_setup_signature()

func _disconnect_skeleton2d_setup_monitor() -> void:
	if skeleton_2d and skeleton_2d.bone_setup_changed.is_connected(_on_skeleton2d_bone_setup_changed):
		skeleton_2d.bone_setup_changed.disconnect(_on_skeleton2d_bone_setup_changed)

func _on_skeleton2d_bone_setup_changed() -> void:
	if _block_bone_setup_signal: return
	if not _bone_setup_check_pending:
		_bone_setup_check_pending = true
		_check_bone_setup_after_idle.call_deferred()

func _check_bone_setup_after_idle() -> void:
	_bone_setup_check_pending = false
	if not skeleton_2d or not skeleton_2d.is_inside_tree(): return
	var sig := _compute_bone_setup_signature()
	if sig != _last_bone_signature:
		_defer_refresh_setup()
#endregion

#region Billboarding
func _handle_camera_tracker() -> void:
	if not is_instance_valid(_camera_watcher):
		_camera_watcher = null
	
	if not (_billboard_camera and billboard_enabled):
		if _camera_watcher:
			_camera_watcher.unsubscribe(self)
			_camera_watcher = null
		return
	
	var watcher := PaperCameraWatcher3D.acquire(_billboard_camera)
	if _camera_watcher and _camera_watcher != watcher:
		_camera_watcher.unsubscribe(self)
	_camera_watcher = watcher
	_camera_watcher.subscribe(self)
	_camera_watcher.on_subscriber_config_changed()

func _on_viewport_camera_changed_from_bus(cam: Node3D) -> void:
	if not billboard_enabled or _camera_override_set or _billboard_camera == cam: return
	_billboard_camera = cam
	_warned_no_camera = false

func _get_viewport_bus() -> PaperViewportCameraBus:
	return PaperViewportCameraBus.get_singleton(get_tree())

func _subscribe_to_viewport_bus() -> void:
	_get_viewport_bus().subscribe(get_viewport(), self)

func _unsubscribe_to_viewport_bus() -> void:
	_get_viewport_bus().unsubscribe(get_viewport(), self)

func _assign_camera() -> void:
	_camera_override_set = billboard_camera_override != null
	if billboard_enabled:
		_subscribe_to_viewport_bus()
		_autobind_camera_if_needed(true)
		_handle_camera_tracker()

func _check_billboard_update() -> void:
	var new_transform := global_transform
	var should_update := billboard_enabled and (
		_transform_cache.basis != new_transform.basis or
		(_is_dir_position and new_transform.origin != _transform_cache.origin)
	)
	if should_update: _mark_billboard_dirty()

func _mark_billboard_dirty() -> void:
	if not billboard_enabled: return
	_billboard_dirty = true
	_transform_cache = global_transform

func _ensure_billboard_current() -> void:
	if not billboard_enabled or not _billboard_dirty: return
	_update_billboard_transform()
	_billboard_dirty = false

func _update_billboard_transform() -> void:
	var cam_xf: Transform3D = (
		(_billboard_camera as Camera3D).get_camera_transform()
		if (billboard_track_offset and _billboard_camera_is_camera)
		else _billboard_camera.global_transform
	)
	var sk_xf := global_transform
	
	var target_dir: Vector3
	if _is_dir_position:
		target_dir = cam_xf.origin - sk_xf.origin
	else:
		var rotate_dir := cam_xf.basis.z
		
		var t := absf(cos(flip_rotate))
		if t < 0.999:
			var position_dir := cam_xf.origin - sk_xf.origin
			var rotate_normalized := rotate_dir
			var position_normalized := position_dir
			target_dir = position_normalized.lerp(rotate_normalized, t)
		else:
			target_dir = rotate_dir
	
	if target_dir.x == 0.0 and target_dir.z == 0.0: return
	var sk_basis := sk_xf.basis
	var up := (sk_basis.y if _is_axis_local else Vector3.UP)
	var target_world_basis: Basis
	if _is_axis_local or _is_axis_upright:
		var fwd := target_dir.slide(up)
		var right := up.cross(fwd)
		target_world_basis = Basis(right, up, fwd).orthonormalized()
	else:
		var target_h := target_dir.slide(up)
		var curr_h := sk_basis.z.slide(up)
		var delta := curr_h.signed_angle_to(target_h, up)
		var yaw_b := Basis(up, delta)
		target_world_basis = (yaw_b * sk_basis).orthonormalized()
	var target_local_basis := sk_basis.inverse() * target_world_basis
	_mesh_inst_holder.basis = target_local_basis
	billboard_update.emit()

func _resolve_camera() -> Node3D:
	if is_instance_valid(billboard_camera_override):
		return billboard_camera_override
	
	if not Engine.is_editor_hint():
		var cam := get_viewport().get_camera_3d()
		if cam: return cam
	return PaperViewportCameraBus.get_editor_camera(get_world_3d())

func _autobind_camera_if_needed(force := false) -> void:
	var resolved := _resolve_camera()
	if resolved and (force or resolved != _billboard_camera):
		_billboard_camera = resolved
		_warned_no_camera = false
		return
	if not resolved and _billboard_camera:
		_billboard_camera = null
	if not resolved and not _warned_no_camera and billboard_enabled:
		_warned_no_camera = true
		push_warning("PaperSkeleton: No Camera3D bound yet. Will auto-bind when one becomes available.")
#endregion

#region Polygon2D path
func _validate_polygon_group(node: Node) -> bool:
	var eval := _polygon_group_eval(node)
	if eval == _PolygonEval.PASS: return true
	const EVAL_MESSAGES: PackedStringArray = [
		"No Polygon2Ds detected within the \"%s\" node.",
		"No Skeleton2D assigned to any of the Polygon2Ds within the \"%s\" node.",
		"There can only be one Skeleton2D assigned to the group of Polygon2Ds within the \"%s\" node.",
		"Bone2D names within the Skeleton2D must be unique to be compatible with Skeleton3D."
	]
	var msg := EVAL_MESSAGES[eval + 1]
	if eval != _PolygonEval.BONE_NAMES_NOT_UNIQUE: msg = msg % node.name
	push_error(msg)
	return false

enum _PolygonEval { PASS, NO_POLYGONS, NO_SKELETON, MULTIPLE_SKELETONS, BONE_NAMES_NOT_UNIQUE }

func _polygon_group_eval(node: Node) -> _PolygonEval:
	if not _has_polygons(node): return _PolygonEval.NO_POLYGONS
	var found_skeletons: Array = []
	_check_polygons(node, found_skeletons)
	if found_skeletons.is_empty(): return _PolygonEval.NO_SKELETON
	if found_skeletons.size() > 1: return _PolygonEval.MULTIPLE_SKELETONS
	if not _check_bones_unique(found_skeletons[0]):
		return _PolygonEval.BONE_NAMES_NOT_UNIQUE
	return _PolygonEval.PASS

func _has_polygons(node: Node) -> bool:
	if node is Polygon2D:
		return true
	for ch: Node in node.get_children():
		if _has_polygons(ch):
			return true
	return false

func _check_polygons(node: Node, found_skeletons: Array) -> void:
	if node is Polygon2D:
		var p: Polygon2D = node
		if not p.skeleton.is_empty():
			var sk := p.get_node(p.skeleton)
			if sk is Skeleton2D and !found_skeletons.has(sk):
				found_skeletons.append(sk)
	for ch in node.get_children(): _check_polygons(ch, found_skeletons)

func _check_bones_unique(skeleton: Node, names: Dictionary[StringName, bool] = {}) -> bool:
	for ch: Node in skeleton.get_children():
		if ch is Bone2D:
			if names.has(ch.name):
				return false
			names[ch.name] = true
		if not _check_bones_unique(ch, names):
			return false
	return true

func _collect_polygons() -> void:
	_polygons.clear()
	if _stored_polygon_paths:
		var p_size := _stored_polygon_paths.size()
		_polygons.resize(p_size)
		for i: int in p_size:
			var path := _stored_polygon_paths[i]
			var pp: PaperPolygon2D = polygon_group.get_node(path)
			pp._skeleton = self
			_polygons[i] = polygon_group.get_node(path)
	else:
		_walk_and_collect_polygons(polygon_group)

func _walk_and_collect_polygons(node: Node) -> void:
	if not node: return
	for child in node.get_children():
		if child is Polygon2D:
			var p2d := _convert_polygon_to_paper_polygon(child)
			_polygons.append(p2d)
		_walk_and_collect_polygons(child)

func _convert_polygon_to_paper_polygon(polygon: Polygon2D) -> PaperPolygon2D:
	if not (polygon is PaperPolygon2D):
		polygon.set_script(PaperPolygon2D)
		print("Converted Polygon2D instance \"%s\" to PaperPolygon2D" % polygon.name)
	var pp: PaperPolygon2D = polygon
	pp._skeleton = self
	return pp

func _find_skeleton_in_group(group: Node) -> Skeleton2D:
	if not group: return null
	
	for child: Node in group.get_children():
		if child is Polygon2D:
			var p2d: Polygon2D = child
			var skel := p2d.get_node_or_null(p2d.skeleton)
			if skel is Skeleton2D: return skel
		
		var nested := _find_skeleton_in_group(child)
		if nested: return nested
	
	return null

func _skeleton_for_polygon(p: Polygon2D) -> Skeleton2D:
	if skeleton_2d: return skeleton_2d
	if p and not p.skeleton.is_empty():
		var n := p.get_node_or_null(p.skeleton)
		if n is Skeleton2D: return n
	return null

static func _resolve_bone_from_path(skel: Skeleton2D, path: NodePath) -> Bone2D:
	if not path or not skel: return null
	var node := skel.get_node_or_null(path)
	return node as Bone2D if node is Bone2D else null

func _polygon_rebuild(polygon: PaperPolygon2D) -> void:
	if not polygon._mesh_instance_3d: return
	polygon._mesh_instance_3d.mesh = _build_polygon_mesh_skinned(polygon)
	_sync_effect_mesh_resources_for_renderable(polygon, PaperPolygon2D._TYPE)
	_apply_offsets_for_renderable(polygon, PaperPolygon2D._TYPE)
	polygon._on_mesh_rebuilt()

func _create_mesh_instance_for_polygon(pp: PaperPolygon2D, cache_idx := -1) -> void:
	var mesh: ArrayMesh
	if cache_idx == -1:
		mesh = _build_polygon_mesh_skinned(pp)
	else:
		var stored_mesh: ArrayMesh = _stored_polygon_meshes[cache_idx]
		mesh = stored_mesh if stored_mesh else _build_polygon_mesh_skinned(pp)
	var _mi := _attach_mesh_instance_for(pp, PaperPolygon2D._TYPE, mesh)

func _build_polygon_mesh_skinned(pp: PaperPolygon2D) -> ArrayMesh:
	var polygon_vertices := pp.polygon
	var polygon_uvs := pp.uv
	var polygon_indices := pp.polygons
	var vertex_count: int = polygon_vertices.size()
	if polygon_uvs.is_empty():
		polygon_uvs = polygon_vertices
	if polygon_indices.size() <= 1 and (polygon_indices.is_empty() or polygon_indices[0].is_empty()):
		polygon_indices.resize(1)
		polygon_indices[0] = PackedInt32Array(range(vertex_count))
	
	var skel := _skeleton_for_polygon(pp)
	var bones_prop: Array = pp.bones
	var resolved_bones: Array[Bone2D] = []
	var resolved_weights: Array[PackedFloat32Array] = []
	if skel and not bones_prop.is_empty():
		for i: int in range(0, bones_prop.size(), 2):
			var bone_path: NodePath = bones_prop[i]
			var bone_weights: PackedFloat32Array = bones_prop[i + 1]
			if _is_float32_array_all_less_than_zero(bone_weights): continue
			if bone_weights.size() != vertex_count:
				push_warning("Bone '", bone_path, "' in Polygon2D '", pp.name, "' has mismatched vertex and weight counts.")
			var bone := _resolve_bone_from_path(skel, bone_path)
			if bone:
				resolved_bones.append(bone)
				resolved_weights.append(bone_weights)
			else:
				push_warning("Bone path '", bone_path, "' in Polygon2D '", pp.name, "' could not be resolved.")
	
	var is_weighted := resolved_bones.size() > 0
	var weights_leq4 := true
	if is_weighted:
		for v: int in vertex_count:
			var cnt := 0
			for j in resolved_weights.size():
				var arr := resolved_weights[j]
				var w := (arr[v] if v < arr.size() else 0.0)
				if w > 0.0:
					cnt += 1
					if cnt > 4:
						weights_leq4 = false
						break
			if not weights_leq4: break
	var max_bw := 4 if weights_leq4 else 8
	
	var transform_modifier := pp.get_global_transform()
	if skel:
		var sk_gt := skel.get_global_transform()
		transform_modifier = sk_gt.affine_inverse() * transform_modifier
	transform_modifier = transform_modifier.translated(pp.offset)
	
	var verts   := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs     := PackedVector2Array()
	var bones   := PackedInt32Array()
	var weights := PackedFloat32Array()
	verts.resize(vertex_count)
	normals.resize(vertex_count)
	uvs.resize(vertex_count)
	if is_weighted:
		bones.resize(vertex_count * max_bw)
		weights.resize(vertex_count * max_bw)
	
	for i: int in vertex_count:
		var v2: Vector2 = polygon_vertices[i]
		v2 = transform_modifier * v2 * PX_SCALE
		verts[i] = Vector3(v2.x, -v2.y, 0)
		normals[i] = Vector3.MODEL_FRONT
		uvs[i] = polygon_uvs[i] if polygon_uvs.size() > i else Vector2.ZERO
		if not is_weighted: continue
		var bw_start := i * max_bw
		var bw_idx := bw_start
		var total_w := 0.0
		var cnt := 0
		for j: int in resolved_bones.size():
			var b2d := resolved_bones[j]
			var arr := resolved_weights[j]
			var w := (arr[i] if i < arr.size() else 0.0)
			if w <= 0.0: continue
			if cnt + 1 > max_bw:
				push_warning("More than ", max_bw, " bones on vertex ", i, " of polygon '", pp.name, "'. Extra influences will be ignored.")
				continue
			bones[bw_idx] = get_3d_bone_idx(b2d)
			weights[bw_idx] = w
			total_w += w
			cnt += 1
			bw_idx += 1
		if total_w > 0.0:
			for j: int in range(bw_start, bw_start + cnt):
				weights[j] /= total_w
		for j: int in range(bw_start + cnt, bw_start + max_bw):
			bones[j] = 0
			weights[j] = 0.0
	
	var indices := PackedInt32Array()
	var tri_count := 0
	for poly: PackedInt32Array in polygon_indices:
		var n := poly.size()
		if n >= 3:
			tri_count += (n - 2) * 3
	indices.resize(tri_count)
	
	var cur := 0
	for poly: PackedInt32Array in polygon_indices:
		var n := poly.size()
		if n < 3: continue
		var a := poly[0]
		for i: int in range(1, n - 1):
			var b := poly[i]
			var c := poly[i + 1]
			if a >= vertex_count or b >= vertex_count or c >= vertex_count: continue
			var normal := (verts[c] - verts[a]).cross(verts[b] - verts[a]).normalized()
			indices[cur] = a
			if normal.z < 0:
				indices[cur + 1] = c
				indices[cur + 2] = b
			else:
				indices[cur + 1] = b
				indices[cur + 2] = c
			cur += 3
	
	# Optional linear subdivision
	for _level: int in pp.subdivision_level:
		var current_vertex_count := verts.size()
		var current_index_count := indices.size()
		
		var edge_keys: PackedInt64Array = []
		edge_keys.resize(current_index_count)
		var e_write := 0
		for i: int in range(0, current_index_count, 3):
			var a := indices[i]; var b := indices[i + 1]; var c := indices[i + 2]
			edge_keys[e_write] = _edge_key(a, b); e_write += 1
			edge_keys[e_write] = _edge_key(b, c); e_write += 1
			edge_keys[e_write] = _edge_key(c, a); e_write += 1
		
		edge_keys.sort()
		
		var unique_edge_keys: PackedInt64Array = []
		var edge_key_count := edge_keys.size()
		unique_edge_keys.resize(edge_key_count)
		if edge_key_count > 0:
			var last := edge_keys[0]
			unique_edge_keys[0] = last
			var write_idx := 1
			for i: int in range(1, edge_key_count):
				var k: int = edge_keys[i]
				if k != last:
					unique_edge_keys[write_idx] = k
					write_idx += 1
					last = k
			unique_edge_keys.resize(write_idx)
		
		var num_new_vertices := unique_edge_keys.size()
		if num_new_vertices == 0: break
		
		var new_vertex_count := current_vertex_count + num_new_vertices
		var new_index_count := current_index_count * 4
		
		var new_verts: PackedVector3Array = [];   new_verts.resize(new_vertex_count)
		var new_uvs: PackedVector2Array = [];     new_uvs.resize(new_vertex_count)
		var new_normals: PackedVector3Array = []; new_normals.resize(new_vertex_count)
		var new_indices: PackedInt32Array = [];   new_indices.resize(new_index_count)
		
		var new_bones: PackedInt32Array = []
		var new_weights: PackedFloat32Array = []
		if is_weighted:
			new_bones.resize(new_vertex_count * max_bw)
			new_weights.resize(new_vertex_count * max_bw)
		
		for i: int in current_vertex_count:
			new_verts[i] = verts[i]
			new_uvs[i] = uvs[i]
			new_normals[i] = normals[i]
			if is_weighted:
				var bw_start_idx := i * max_bw
				for j: int in max_bw:
					var idx := bw_start_idx + j
					new_bones[idx] = bones[idx]
					new_weights[idx] = weights[idx]
		
		var edge_mid_index := PackedInt32Array()
		edge_mid_index.resize(unique_edge_keys.size())
		var cur_new_vi := current_vertex_count
		
		for ui: int in unique_edge_keys.size():
			var key := unique_edge_keys[ui]
			
			var a := key >> 32
			var b := key & 0xFFFFFFFF
			
			var pos := (verts[a] + verts[b]) * 0.5
			var uv := (uvs[a] + uvs[b]) * 0.5
			var normal := (normals[a] + normals[b]).normalized()
			
			new_verts[cur_new_vi] = pos
			new_uvs[cur_new_vi] = uv
			new_normals[cur_new_vi] = normal
			
			if is_weighted:
				var acc_bones: PackedInt32Array = [];     acc_bones.resize(max_bw)
				var acc_weights: PackedFloat32Array = []; acc_weights.resize(max_bw)
				var used := 0
				
				var a_start := a * max_bw
				for j: int in max_bw:
					var w := weights[a_start + j]
					if w <= 0.0: continue
					var bone_idx := bones[a_start + j]
					var found := false
					for k: int in used:
						if acc_bones[k] == bone_idx:
							acc_weights[k] += 0.5 * w
							found = true
							break
					if not found and used < max_bw:
						acc_bones[used] = bone_idx
						acc_weights[used] = 0.5 * w
						used += 1
				
				var b_start := b * max_bw
				for j: int in max_bw:
					var w := weights[b_start + j]
					if w <= 0.0: continue
					var bone_idx := bones[b_start + j]
					var found := false
					for k: int in used:
						if acc_bones[k] == bone_idx:
							acc_weights[k] += 0.5 * w
							found = true
							break
					if not found and used < max_bw:
						acc_bones[used] = bone_idx
						acc_weights[used] = 0.5 * w
						used += 1
				
				var sum_w := 0.0
				for k: int in used: sum_w += acc_weights[k]
				var write_start := cur_new_vi * max_bw
				if sum_w > 0.0:
					var inv_sum := 1.0 / sum_w
					for k: int in used:
						new_bones[write_start + k] = acc_bones[k]
						new_weights[write_start + k] = acc_weights[k] * inv_sum
				
				for k: int in range(used, max_bw):
					new_bones[write_start + k] = 0
					new_weights[write_start + k] = 0.0
			
			edge_mid_index[ui] = cur_new_vi
			cur_new_vi += 1
		
		var write := 0
		for i: int in range(0, current_index_count, 3):
			var a := indices[i]; var b := indices[i + 1]; var c := indices[i + 2]
			
			var mab := edge_mid_index[unique_edge_keys.bsearch(_edge_key(a, b))]
			var mbc := edge_mid_index[unique_edge_keys.bsearch(_edge_key(b, c))]
			var mca := edge_mid_index[unique_edge_keys.bsearch(_edge_key(c, a))]
			
			new_indices[write] = a;   new_indices[write + 1] = mab; new_indices[write + 2] = mca; write += 3
			new_indices[write] = mab; new_indices[write + 1] = b;   new_indices[write + 2] = mbc; write += 3
			new_indices[write] = mca; new_indices[write + 1] = mbc; new_indices[write + 2] = c;   write += 3
			new_indices[write] = mab; new_indices[write + 1] = mbc; new_indices[write + 2] = mca; write += 3
		
		verts = new_verts
		uvs = new_uvs
		normals = new_normals
		if is_weighted:
			bones = new_bones
			weights = new_weights
		indices = new_indices
	
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh_flags := 0
	if is_weighted:
		arrays[Mesh.ARRAY_BONES] = bones
		arrays[Mesh.ARRAY_WEIGHTS] = weights
		if max_bw > 4:
			mesh_flags = Mesh.ARRAY_FLAG_USE_8_BONE_WEIGHTS
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays, [], {}, mesh_flags)
	return m

static func _edge_key(a: int, b: int) -> int:
	if a > b: return (b << 32) | a
	else: return (a << 32) | b

static func _is_float32_array_all_less_than_zero(array: PackedFloat32Array) -> bool:
	for f: float in array:
		if f > 0.0: return false
	return true
#endregion

#region Sprite2D path
## Completely rebuilds the rig (useful after large topology changes)
func refresh_setup() -> void:
	_rebuild_update = false
	if skeleton_2d:
		var prev_block := _block_bone_setup_signal
		_block_bone_setup_signal = true
		_clear_session()
		_setup_from_sources()
		_last_bone_signature = _compute_bone_setup_signature()
		_block_bone_setup_signal = prev_block

func _defer_refresh_setup() -> void:
	if not _rebuild_update:
		refresh_setup.call_deferred()
		_rebuild_update = true

func _validate_skeleton_2d_assignment(skel: Skeleton2D) -> bool:
	if not _check_bones_unique_names(skel):
		push_error("Bone2D names in the assigned Skeleton2D must be unique to be compatible with Skeleton3D.")
		return false
	return true

func _check_bones_unique_names(node: Node, seen: Dictionary[StringName, bool] = {}) -> bool:
	for ch in node.get_children():
		if ch is Bone2D:
			if seen.has(ch.name): return false
			seen[ch.name] = true
		if not _check_bones_unique_names(ch, seen):
			return false
	return true

func _collect_sprites() -> void:
	_sprites.clear()
	if _stored_sprite_paths:
		var s_size := _stored_sprite_paths.size()
		_sprites.resize(s_size)
		for i: int in s_size:
			var path := _stored_sprite_paths[i]
			var spr: PaperSprite2D = skeleton_2d.get_node(path)
			spr._skeleton = self
			spr._assign_parent_bone(_find_parent_bone2d(spr))
			_sprites[i] = skeleton_2d.get_node(path)
			
	else:
		_walk_and_collect_sprites(skeleton_2d)

func _walk_and_collect_sprites(node: Node) -> void:
	if not node: return
	for child in node.get_children():
		if child is Sprite2D:
			var spr := _convert_to_paper_sprite(child)
			_sprites.append(spr)
		_walk_and_collect_sprites(child)

func _convert_to_paper_sprite(s: Sprite2D) -> PaperSprite2D:
	if s is not PaperSprite2D:
		s.set_script(PaperSprite2D)
		print("Converted Sprite2D \"%s\" to PaperSprite2D" % s.name)
	var ps: PaperSprite2D = s
	ps._skeleton = self
	ps._assign_parent_bone(_find_parent_bone2d(ps))
	return ps

func _create_mesh_instance_for_sprite(spr: PaperSprite2D, cache_idx := -1) -> void:
	var mesh: ArrayMesh
	if cache_idx == -1:
		mesh = _build_sprite_quad_mesh_skinned(spr)
	else:
		var stored_mesh: ArrayMesh = _stored_sprite_meshes[cache_idx]
		mesh = stored_mesh if stored_mesh else _build_sprite_quad_mesh_skinned(spr)
	var skin := _make_skin_for_sprite(spr)
	var _mi := _attach_mesh_instance_for(spr, PaperSprite2D._TYPE, mesh, skin)

func _make_sprite_base_surface(spr: PaperSprite2D) -> Array:
	var rect := spr.get_rect()
	
	var segs := maxi(2, spr.subdivision_level + 2)
	var segs_m := segs - 1
	
	var w := rect.size.x * PX_SCALE
	var h := rect.size.y * PX_SCALE
	
	var hw := w * 0.5
	var hh := h * 0.5
	
	var vcount := segs * segs
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var normals := PackedVector3Array()
	verts.resize(vcount)
	uvs.resize(vcount)
	normals.resize(vcount)
	
	for y: int in segs:
		var fy := float(y) / float(segs_m)
		var vy := lerpf(hh, -hh, fy)
		if not spr.centered: vy -= hh
		var sy := segs * y
		for x: int in segs:
			var ix := sy + x
			var fx := float(x) / float(segs_m)
			var vx := lerpf(-hw, hw, fx)
			if not spr.centered: vx += hw
			verts[ix] = Vector3(vx, vy, 0.0)
			uvs[ix] = Vector2(rect.size.x * fx, rect.size.y * fy)
			normals[ix] = Vector3.MODEL_FRONT
	
	var icount := segs_m * segs_m * 6
	var indices := PackedInt32Array()
	indices.resize(icount)
	var cur := 0
	for y: int in segs_m:
		var sy := segs * y
		for x: int in segs_m:
			var i0 := sy + x
			var i1 := i0 + 1
			var i2 := i0 + segs
			var i3 := i2 + 1
			indices[cur]     = i0
			indices[cur + 1] = i1
			indices[cur + 2] = i2
			indices[cur + 3] = i1
			indices[cur + 4] = i3
			indices[cur + 5] = i2
			cur += 6
	
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return [arrays, vcount]

func _make_single_bone_skinning(vcount: int) -> Array:
	var bones := PackedInt32Array()
	var weights := PackedFloat32Array()
	bones.resize(vcount * 4)
	weights.resize(vcount * 4)
	for vi: int in vcount:
		weights[vi * 4] = 1.0
	return [bones, weights]

func _build_sprite_quad_mesh_skinned(spr: PaperSprite2D) -> ArrayMesh:
	var base := _make_sprite_base_surface(spr)
	var arrays: Array = base[0]
	var vcount: int = base[1]
	var skin := _make_single_bone_skinning(vcount)
	arrays[Mesh.ARRAY_BONES] = skin[0]
	arrays[Mesh.ARRAY_WEIGHTS] = skin[1]
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return m

func _make_skin_for_sprite(spr: PaperSprite2D) -> Skin:
	var b := spr._parent_bone_2d
	var bi := get_3d_bone_idx(b) if b else FLIP_BONE_IDX
	var skin := Skin.new()
	var t3 := _sprite_local_3d_transform(spr)
	skin.add_bind(bi, t3)
	return skin

func _sprite_local_3d_transform(spr: PaperSprite2D, add_offset: bool = true) -> Transform3D:
	return _transform_2d_to_3d(_sprite_local_2d_transform(spr, add_offset))

func _sprite_local_2d_transform(spr: PaperSprite2D, add_offset: bool = true) -> Transform2D:
	var b := spr._parent_bone_2d
	var t2: Transform2D
	if b:
		t2 = b.get_global_transform().affine_inverse() * spr.get_global_transform()
	elif skeleton_2d:
		t2 = skeleton_2d.get_global_transform().affine_inverse() * spr.get_global_transform()
	else:
		t2 = spr.get_transform()
	return t2.translated_local(spr.offset) if add_offset else t2

func _find_parent_bone2d(spr: Node) -> Bone2D:
	var p := spr.get_parent()
	while p and p != skeleton_2d:
		if p is Bone2D: return p
		p = p.get_parent()
	return null

func _update_sprite_transform(spr: PaperSprite2D) -> void:
	var mi: MeshInstance3D = spr._mesh_instance_3d
	if not mi: return
	var skin: Skin = mi.skin
	if skin:
		var t3 := _sprite_local_3d_transform(spr)
		mi.skin.set_bind_pose(0, t3)
	else:
		mi.skin = _make_skin_for_sprite(spr)
	if Engine.is_editor_hint(): update_gizmos()

func _sprite_rebuild(spr: PaperSprite2D) -> void:
	var mi: MeshInstance3D = spr._mesh_instance_3d
	if not mi: return
	mi.mesh = _build_sprite_quad_mesh_skinned(spr)
	if (mi.skin):
		var t3 := _sprite_local_3d_transform(spr)
		mi.skin.set_bind_pose(0, t3)
	else:
		mi.skin = _make_skin_for_sprite(spr)
	if not mi.is_inside_tree():
		_mesh_inst_holder.add_child(mi, false, INTERNAL_MODE_FRONT)
	mi.skeleton = get_path()
	spr._on_mesh_rebuilt()
	_sync_effect_mesh_resources_for_renderable(spr, PaperSprite2D._TYPE)
	_apply_offsets_for_renderable(spr, PaperSprite2D._TYPE)
	if Engine.is_editor_hint(): update_gizmos()
#endregion

#region Batch building of meshes/materials
func _create_all_renderable_meshes() -> void:
	var use_poly_cache: bool = not _stored_polygon_meshes.is_empty()
	for i: int in _polygons.size():
		var poly: PaperPolygon2D = _polygons[i]
		_create_mesh_instance_for_polygon(poly, i if use_poly_cache else -1)
		_bind_material_for_renderable(poly, PaperPolygon2D._TYPE)
		_ensure_effect_instances_for_renderable(poly, PaperPolygon2D._TYPE)
	var use_sprite_cache: bool = not _stored_sprite_meshes.is_empty()
	for i: int in _sprites.size():
		var spr: PaperSprite2D = _sprites[i]
		_create_mesh_instance_for_sprite(spr, i if use_sprite_cache else -1)
		_bind_material_for_renderable(spr, PaperSprite2D._TYPE)
		_ensure_effect_instances_for_renderable(spr, PaperSprite2D._TYPE)
	_apply_offsets_for_all_renderables()

func _update_renderables_with_default_material() -> void:
	for pp: PaperPolygon2D in _polygons:
		if not pp or not pp.uses_skeleton_material(): continue
		pp._bind_effective_material()
	for spr: PaperSprite2D in _sprites:
		if not spr or not spr.uses_skeleton_material(): continue
		spr._bind_effective_material()
#endregion

#region Polygon2D/Sprite2D teardown helpers
func _clear_polygons_only() -> void:
	if track_child_order: _disconnect_child_order_recursive()
	
	for p: PaperPolygon2D in _polygons:
		if p._mesh_instance_3d: p._mesh_instance_3d.free()
		p._mesh_instance_3d = null
		p._z_index_paper = -1
		p._skeleton = null
	if hide_sources: _toggle_source_visibility(true, PaperPolygon2D._TYPE)
	_polygons.clear()
	_rebuild_renderables_cache()
	
	if _sprites.is_empty():
		clear_bones()
		_detach_bone_watchers()
		if _camera_watcher:
			_camera_watcher.queue_free()
			_camera_watcher = null
	elif track_child_order:
		_connect_child_order_recursive(skeleton_2d)

func _clear_sprites_only() -> void:
	if track_child_order: _disconnect_child_order_recursive()
	
	for s: PaperSprite2D in _sprites:
		if s._mesh_instance_3d: s._mesh_instance_3d.queue_free()
		s._mesh_instance_3d = null
		s._z_index_paper = -1
		s._skeleton = null
	if hide_sources: _toggle_source_visibility(true, PaperSprite2D._TYPE)
	_sprites.clear()
	_rebuild_renderables_cache()
	
	if _polygons.is_empty():
		clear_bones()
		_detach_bone_watchers()
		if _camera_watcher:
			_camera_watcher.queue_free()
			_camera_watcher = null
	elif track_child_order:
		_connect_child_order_recursive(polygon_group)
#endregion
