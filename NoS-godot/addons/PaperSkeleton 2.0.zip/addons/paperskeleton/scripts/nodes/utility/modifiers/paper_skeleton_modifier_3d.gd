@tool
@abstract
extends SkeletonModifier3D
class_name PaperSkeletonModifier3D

## Base modifier for [PaperSkeleton]. Make a subclass of this and override [method _build_bone_modifiers].
## [br][br]
## This is primarily used for compatibility with [member PaperSkeleton.flip_rotate], as regular
## skeleton modifiers that apply 3D transformation will typically deal with the problem of their 3D bone
## extrusions not adjusting correctly during the process, as well as the transformation looking rather
## different on either flip side.
## [br][br]
## When [member retract_bone_modifiers] or [member flip_bone_modifiers] properties are set to true,
## bone modifier transformations will adjust accordingly.
## [br][br]
## How to use:[br][br]
## 　• Make your modifier node a child of the PaperSkeleton node.[br][br]
## 　• Create a script that extends this class and implement [method _build_bone_modifiers] by using it to
##     return an array with a [PackedInt32Array] mapping bone indices to an array of [Transform3D] modifiers.[br][br]
## 　• The class will then automatically combine those transforms with the current bone pose, handling
##     retract/flip rules.

## Retract bone modifiers during a flip.
@export
var retract_bone_modifiers: bool = true

## Flip bone modifiers after a flip.
@export
var flip_bone_modifiers: bool = true

var _paper_skeleton: PaperSkeleton = null
var _is_non_paper := false:
	set(value):
		if _is_non_paper == value: return
		_is_non_paper = value
		update_configuration_warnings()

#region Built-in Overrides
func _get_configuration_warnings() -> PackedStringArray:
	var warnings: PackedStringArray
	if _is_non_paper:
		warnings.append("PaperSkeletonModifier3D is attached to a regular Skeleton3D. \
						It will run, but any behavior specific to PaperSkeleton won't work.")
	return warnings

# Assign _paper_skeleton when skeleton is set or changed.
func _skeleton_changed(_old_skeleton: Skeleton3D, new_skeleton: Skeleton3D) -> void:
	_paper_skeleton = (new_skeleton as PaperSkeleton) if (new_skeleton is PaperSkeleton) else null
	_is_non_paper = _paper_skeleton == null and new_skeleton != null

# Main processing hook.
func _process_modification_with_delta(delta: float) -> void:
	var skel := _paper_skeleton if _paper_skeleton else get_skeleton()
	if not skel: return
	
	var mods := _build_bone_modifiers(delta)
	if mods.is_empty() or mods.size() < 2: return
	
	var indices: PackedInt32Array = mods[0]
	var xforms: Array[Transform3D] = mods[1]
	var pair_count := mini(indices.size(), xforms.size())
	if pair_count == 0: return
	
	var flip_cos := get_flip_cos()
	var do_flip := flip_bone_modifiers and flip_cos < 0.0
	
	var t := absf(flip_cos)
	var do_retract := retract_bone_modifiers and t != 1.0
	
	var bone_count := skel.get_bone_count()
	
	for i: int in pair_count:
		var index := indices[i]
		if index < 0 or index >= bone_count: continue
		
		var base_pose: Transform3D = skel.get_bone_pose(index)
		var xform: Transform3D = xforms[i]
		
		# Flip bone modifiers across Z
		if do_flip:
			xform.basis.x.z = -xform.basis.x.z
			xform.basis.y.z = -xform.basis.y.z
			xform.basis.z.x = -xform.basis.z.x
			xform.basis.z.y = -xform.basis.z.y
			xform.origin.z = -xform.origin.z
		
		var target := base_pose * xform
		
		if do_retract:
			var mb := xform.basis
			
			# XY scales from column lengths
			var sx := mb.x.length()
			var sy := mb.y.length()
			
			# Z-twist angle from quaternion
			var rq := mb.get_rotation_quaternion()
			var rot_z := 2.0 * atan2(rq.z, rq.w)
			
			# Build flattened basis
			var c := cos(rot_z)
			var s := sin(rot_z)
			
			var ob := base_pose.basis
			var flattened := base_pose
			flattened.basis.x = ob.x * ( c * sx) + ob.y * (s * sx)
			flattened.basis.y = ob.x * (-s * sy) + ob.y * (c * sy)
			
			# Flatten modifier origin
			flattened.origin += Vector3(xform.origin.x, xform.origin.y, 0.0)
			
			target = flattened.interpolate_with(target, t)
		
		skel.set_bone_pose(index, target)
#endregion

#region Abstract Functions
## Override this to provide local bone delta transforms.
## Return an array of [code][PackedInt32Array, Array[Transform3D]][/code].
@abstract func _build_bone_modifiers(delta: float) -> Array
#endregion

#region Helper Functions
## Gets [PaperSkeleton] (may be null if attached to regular [Skeleton3D]).
func get_paper_skeleton() -> PaperSkeleton:
	return _paper_skeleton

## Returns the of [member PaperSkeleton.flip_rotate] in radians.
## If there's no [PaperSkeleton] attached, returns [code]1.0[/code].
func get_flip_cos() -> float:
	return cos(_paper_skeleton.flip_rotate) if _paper_skeleton else 1.0
#endregion
