@tool
@icon("uid://papermdfsico")
extends PaperSkeletonModifier3D
class_name SimplePaperBoneModifier3D

## Simple [PaperSkeletonModifier3D] with a property-based interface.
## Set [member modifier_count] to control how many bones to modify, and then
## select each bone by name from a dropdown or by index to configure its transform.

const _BONE_MOD_PREFIX := "modifier_"
const _TRANSFORM_PREFIX := "transform/"
const _PROP_BONE_NAME := "name"
const _PROP_BONE_IDX := "index"

@export_storage var _bone_names: PackedStringArray = []
@export_storage var _bone_indices: PackedInt32Array = []
@export_storage var _transforms: Array[Transform3DInterface] = []

## Number of bones to modify. Increase/decrease to add/remove modifier entries.
@export_range(0, 999, 1)
var modifier_count: int = 0:
	set = set_modifier_count, get = get_modifier_count

var _dirty_all: bool = true

enum _BoneFlag { DIRTY = 1 << 0, PENDING_RESET = 1 << 1 }
var _bone_flag_update: int = 0
var _bone_flags: PackedByteArray = []

var _bone_to_entries: Array[PackedInt32Array] = []
var _bone_to_slot: PackedInt32Array = []
var _total_bones: int = 0

var _connected_skeleton: Skeleton3D = null

enum _PropKind { NAME = 0, INDEX = 1, TRANSFORM = 2, NONE = 3 }
static var _prop_parse_cache: Dictionary[StringName, int] = {}

var _mods: Array = [PackedInt32Array(), Array([], TYPE_TRANSFORM3D, &"", null)]
var _mod_indices: PackedInt32Array:
	set(value): _mods[0] = value
	get: return _mods[0]
var _mod_xforms: Array[Transform3D]:
	set(value): _mods[1] = value
	get: return _mods[1]

#region Built-in Overrides
func _ready() -> void:
	_validate_transforms()
	_resize_modifier_data()
	_ensure_total_bones()
	_rebuild_bone_to_entries()
	_connect_skeleton_signals()
	_dirty_all = true

func _enter_tree() -> void:
	if _connected_skeleton:
		_connect_skeleton_signals(_connected_skeleton)

func _exit_tree() -> void:
	if _connected_skeleton:
		_disconnect_skeleton_signals()

func _skeleton_changed(old_skeleton: Skeleton3D, new_skeleton: Skeleton3D) -> void:
	super._skeleton_changed(old_skeleton, new_skeleton)
	_connect_skeleton_signals(new_skeleton)
	_update_all_bone_indices()
	_clean()
	notify_property_list_changed()

func _get_property_list() -> Array[Dictionary]:
	return _get_bone_mod_property_list()

func _get(property: StringName) -> Variant:
	var parsed := _parse_mod_property(property)
	var kind: int = _decode_prop_kind(parsed)
	if kind == _PropKind.NONE: return null
	
	var idx: int = _decode_prop_idx(parsed)
	if not _entry_idx_valid(idx): return null
	
	if kind == _PropKind.NAME:
		return get_entry_bone_name(idx)
	elif kind == _PropKind.INDEX:
		return get_entry_bone_index(idx)
	elif kind == _PropKind.TRANSFORM:
		var xform := _transforms[idx]
		if xform:
			var key: int = _decode_prop_key(parsed)
			if key >= 0 and key < Transform3DInterface._DISPLAY_KEYS.size():
				var prop: StringName = Transform3DInterface._DISPLAY_KEYS[key]
				return xform.get(prop)
	return null

func _set(property: StringName, value: Variant) -> bool:
	var parsed := _parse_mod_property(property)
	var kind: int = _decode_prop_kind(parsed)
	if kind == _PropKind.NONE: return false
	
	var idx: int = _decode_prop_idx(parsed)
	if not _entry_idx_valid(idx): return false
	
	if kind == _PropKind.NAME:
		set_entry_bone_name(idx, value)
		return true
	elif kind == _PropKind.INDEX:
		set_entry_bone_index(idx, value)
		return true
	elif kind == _PropKind.TRANSFORM:
		var xform := _transforms[idx]
		if xform:
			var key: int = _decode_prop_key(parsed)
			if key >= 0 and key < Transform3DInterface._DISPLAY_KEYS.size():
				var prop: StringName = Transform3DInterface._DISPLAY_KEYS[key]
				xform.set(prop, value)
				return true
	return false

func _property_can_revert(property: StringName) -> bool:
	var parsed := _parse_mod_property(property)
	var kind: int = _decode_prop_kind(parsed)
	if kind == _PropKind.NONE: return false
	
	var idx: int = _decode_prop_idx(parsed)
	if not _entry_idx_valid(idx): return false
	
	if kind == _PropKind.NAME:
		return get_entry_bone_name(idx) != ""
	elif kind == _PropKind.INDEX:
		return get_entry_bone_index(idx) != -1
	elif kind == _PropKind.TRANSFORM:
		var xform := _transforms[idx]
		if xform:
			var key: int = _decode_prop_key(parsed)
			if key >= 0 and key < Transform3DInterface._DISPLAY_KEYS.size():
				var prop: StringName = Transform3DInterface._DISPLAY_KEYS[key]
				return xform.property_can_revert(prop)
	return false

func _property_get_revert(property: StringName) -> Variant:
	var parsed := _parse_mod_property(property)
	var kind: int = _decode_prop_kind(parsed)
	if kind == _PropKind.NONE: return null
	
	var idx: int = _decode_prop_idx(parsed)
	if not _entry_idx_valid(idx): return null
	
	if kind == _PropKind.NAME:
		return ""
	elif kind == _PropKind.INDEX:
		return -1
	elif kind == _PropKind.TRANSFORM:
		var xform := _transforms[idx]
		if xform:
			var key: int = _decode_prop_key(parsed)
			if key >= 0 and key < Transform3DInterface._DISPLAY_KEYS.size():
				var prop: StringName = Transform3DInterface._DISPLAY_KEYS[key]
				return xform.property_get_revert(prop)
	return null

func _build_bone_modifiers(_delta: float) -> Array:
	# Apply any pending cache updates before returning arrays.
	if _dirty_all:
		_clean()
	elif _bone_flag_update & _BoneFlag.DIRTY:
		for b: int in _total_bones:
			if _bone_flags[b] & _BoneFlag.DIRTY:
				_update_cached_bone(b)
		_bone_flag_update &= ~_BoneFlag.DIRTY
	
	# Reset poses for bones that lost all modifiers this frame.
	if _bone_flag_update & _BoneFlag.PENDING_RESET:
		var skel := get_skeleton()
		_bone_flag_update &= ~_BoneFlag.PENDING_RESET
		if skel:
			for b: int in _total_bones:
				if _bone_flags[b] & _BoneFlag.PENDING_RESET:
					_bone_flags[b] &= ~_BoneFlag.PENDING_RESET
					if _bone_to_slot[b] == -1:
						skel.set_bone_pose(b, skel.get_bone_pose(b))
		else:
			for b: int in _total_bones:
				_bone_flags[b] &= ~_BoneFlag.PENDING_RESET
	
	return _mods
#endregion

#region Transform3DInterface Lifecycle
func _validate_transforms() -> void:
	# Ensure all transform resources are unique to this node instance and connect their signals
	for i: int in _transforms.size():
		if _transforms[i]:
			_transforms[i] = _transforms[i].duplicate(true)
			_transforms[i].property_list_changed.connect(notify_property_list_changed)
			_transforms[i].changed.connect(_on_transform_changed.bind(i))

func _resize_modifier_data() -> void:
	# Resize internal arrays to match modifier_count
	var old_size := _bone_names.size()
	var new_size := modifier_count
	if old_size == new_size: return
	
	# Clean up removed entries and queue neutral resets
	for i: int in range(new_size, old_size):
		var xform := _transforms[i]
		if xform:
			xform.property_list_changed.disconnect(notify_property_list_changed)
			xform.changed.disconnect(_on_transform_changed)
		if i < _bone_indices.size():
			var prev_bone := _bone_indices[i]
			if is_node_ready():
				_queue_neutral_reset(prev_bone)
			_remove_entry_from_bone(prev_bone, i)
			if prev_bone != -1:
				_mark_bone_dirty(prev_bone)
	
	_bone_names.resize(new_size)
	_bone_indices.resize(new_size)
	_transforms.resize(new_size)
	
	# Initialize new entries
	for i: int in range(old_size, new_size):
		_bone_names[i] = ""
		_bone_indices[i] = -1
		
		var xform := Transform3DInterface.new()
		xform.property_list_changed.connect(notify_property_list_changed)
		xform.changed.connect(_on_transform_changed.bind(i))
		_transforms[i] = xform
	
	_dirty_all = true
#endregion

#region Skeleton Wiring
func _connect_skeleton_signals(skel: Skeleton3D = get_skeleton()) -> void:
	_disconnect_skeleton_signals()
	if skel and not skel.bone_list_changed.is_connected(_on_skeleton_bone_list_changed):
		skel.bone_list_changed.connect(_on_skeleton_bone_list_changed)
	_connected_skeleton = skel

func _disconnect_skeleton_signals() -> void:
	if _connected_skeleton and _connected_skeleton.bone_list_changed.is_connected(_on_skeleton_bone_list_changed):
		_connected_skeleton.bone_list_changed.disconnect(_on_skeleton_bone_list_changed)
	_connected_skeleton = null

func _on_skeleton_bone_list_changed() -> void:
	_update_all_bone_indices()
	_clean()
	notify_property_list_changed()
#endregion

#endregion Mapping Entry <-> Bone
func _update_bone_idx(entry_idx: int) -> void:
	# Update bone index from bone name for a specific entry.
	var prev_idx := _bone_indices[entry_idx] if _entry_idx_valid(entry_idx) else -1
	var skel := get_skeleton()
	if not skel or _bone_names[entry_idx].is_empty():
		_bone_indices[entry_idx] = -1
		_on_entry_bone_idx_changed(entry_idx, prev_idx, -1)
		return
	
	var new_idx := skel.find_bone(_bone_names[entry_idx])
	if new_idx == -1:
		_bone_indices[entry_idx] = -1
		_on_entry_bone_idx_changed(entry_idx, prev_idx, -1)
		return
	
	_bone_indices[entry_idx] = new_idx
	_on_entry_bone_idx_changed(entry_idx, prev_idx, new_idx)

func _update_bone_name(entry_idx: int) -> void:
	# Update bone name from bone index for a specific entry.
	var skel := get_skeleton()
	if not skel or _bone_indices[entry_idx] == -1:
		_bone_names[entry_idx] = ""
		return
	
	var bone_idx := _bone_indices[entry_idx]
	if bone_idx >= 0 and bone_idx < skel.get_bone_count():
		_bone_names[entry_idx] = skel.get_bone_name(bone_idx)
	else:
		_bone_names[entry_idx] = ""

func _update_all_bone_indices() -> void:
	for i: int in _bone_names.size():
		_update_bone_idx(i)

func _on_transform_changed(entry_idx: int) -> void:
	var bone_idx := _bone_indices[entry_idx]
	if bone_idx != -1:
		_mark_bone_dirty(bone_idx)

func _on_entry_bone_idx_changed(entry_idx: int, prev_idx: int, new_idx: int) -> void:
	if prev_idx == new_idx: return
	if prev_idx != -1:
		_remove_entry_from_bone(prev_idx, entry_idx)
		_mark_bone_dirty(prev_idx)
	if new_idx != -1:
		_add_entry_to_bone(new_idx, entry_idx)
		_mark_bone_dirty(new_idx)
#endregion

#region Cache Helpers
func _get_skeleton_bone_count() -> int:
	var skel := get_skeleton()
	return skel.get_bone_count() if skel else 0

func _ensure_total_bones() -> void:
	var count := _get_skeleton_bone_count()
	if _total_bones == count: return
	_total_bones = count
	
	_bone_to_entries.resize(_total_bones)
	for i: int in _total_bones:
		_bone_to_entries[i].clear()
	
	_bone_flags.resize(_total_bones)
	_bone_flags.fill(0)
	
	_bone_to_slot.resize(_total_bones)
	_bone_to_slot.fill(-1)
	
	_mod_indices.clear()
	_mod_xforms.clear()

func _rebuild_bone_to_entries() -> void:
	_ensure_total_bones()
	_clear_bone_to_entries()
	for i: int in modifier_count:
		var b := _bone_indices[i]
		if _bone_idx_valid(b):
			_bone_to_entries[b].append(i)

func _mark_bone_dirty(bone_idx: int) -> void:
	_bone_flags[bone_idx] |= _BoneFlag.DIRTY
	_bone_flag_update |= _BoneFlag.DIRTY

func _queue_neutral_reset(bone_idx: int) -> void:
	_bone_flags[bone_idx] |= _BoneFlag.PENDING_RESET
	_bone_flag_update |= _BoneFlag.PENDING_RESET

func _clear_bone_to_entries() -> void:
	for b: int in _total_bones:
		_bone_to_entries[b].clear()

func _add_entry_to_bone(bone_idx: int, entry_idx: int) -> void:
	_bone_to_entries[bone_idx].append(entry_idx)

func _remove_entry_from_bone(bone_idx: int, entry_idx: int) -> void:
	var arr := _bone_to_entries[bone_idx]
	var removed := arr.erase(entry_idx)
	if removed and arr.is_empty():
		_queue_neutral_reset(bone_idx)

func _activate_bone(b: int) -> void:
	if _bone_to_slot[b] != -1: return
	var slot := _mod_indices.size()
	_mod_indices.append(b)
	_mod_xforms.append(Transform3D.IDENTITY)
	_bone_to_slot[b] = slot

func _deactivate_bone(b: int) -> void:
	var slot := _bone_to_slot[b]
	if slot == -1: return
	var last := _mod_indices.size() - 1
	if slot != last:
		var moved_bone := _mod_indices[last]
		_mod_indices[slot] = moved_bone
		_mod_xforms[slot] = _mod_xforms[last]
		_bone_to_slot[moved_bone] = slot
	_mod_indices.resize(last)
	_mod_xforms.resize(last)
	_bone_to_slot[b] = -1

func _write_cached_transform(b: int, t: Transform3D) -> void:
	var slot := _bone_to_slot[b]
	if slot == -1:
		_activate_bone(b)
		slot = _bone_to_slot[b]
	_mod_xforms[slot] = t

func _rebuild_cached_mods() -> void:
	_bone_to_slot.fill(-1)
	_mod_indices.clear()
	_mod_xforms.clear()
	
	# Recompute all active bones
	for bone_idx: int in _total_bones:
		var entries := _bone_to_entries[bone_idx]
		if entries.is_empty(): continue
		var first := true
		var agg := Transform3D.IDENTITY
		for i: int in entries:
			if not _entry_idx_valid(i): continue
			var x := _transforms[i]
			if x:
				var t := x.get_transform()
				if first:
					agg = t
					first = false
				else:
					agg *= t
		if not first:
			_write_cached_transform(bone_idx, agg)
		_bone_flags[bone_idx] &= ~_BoneFlag.DIRTY

func _update_cached_bone(bone_idx: int) -> void:
	_bone_flags[bone_idx] &= ~_BoneFlag.DIRTY
	var entries := _bone_to_entries[bone_idx]
	if entries.is_empty():
		_deactivate_bone(bone_idx)
		return
	
	var first := true
	var agg := Transform3D.IDENTITY
	for i: int in entries:
		if not _entry_idx_valid(i): continue
		var x := _transforms[i]
		if x:
			var t := x.get_transform()
			if first:
				agg = t
				first = false
			else:
				agg *= t
	
	if first:
		_deactivate_bone(bone_idx)
	else:
		_write_cached_transform(bone_idx, agg)

func _clean() -> void:
	_ensure_total_bones()
	_rebuild_bone_to_entries()
	_rebuild_cached_mods()
	_dirty_all = false
	_bone_flag_update &= ~_BoneFlag.DIRTY
#endregion

#region Bounds Check Helpers
func _entry_idx_valid(entry_idx: int) -> bool:
	return entry_idx >= 0 and entry_idx < modifier_count

func _xform_idx_valid(entry_idx: int) -> bool:
	return _entry_idx_valid(entry_idx) and _transforms[entry_idx]

func _bone_idx_valid(bone_idx: int) -> bool:
	return bone_idx >= 0 and bone_idx < _total_bones
#endregion

#region Property Parsing and Building
func _get_bone_mod_property_list() -> Array[Dictionary]:
	if modifier_count <= 0: return []
	
	var skel := get_skeleton()
	var bone_idx_range: String
	var bone_names: String
	if skel:
		bone_idx_range = "-1,%d,1" % (skel.get_bone_count() - 1)
		bone_names = skel.get_concatenated_bone_names()
	else:
		bone_idx_range = "-1,999,1,or_greater"
		bone_names = ""
	
	var total := modifier_count * 2
	for idx: int in modifier_count:
		total += _transforms[idx].get_display_property_list_size()
	
	var properties: Array[Dictionary] = []
	properties.resize(total)
	
	var p := 0
	for m: int in modifier_count:
		var bm_prefix := "%s%d/" % [_BONE_MOD_PREFIX, m]
		
		# Bone name property
		var bone_name_prop := {
			"name": bm_prefix + _PROP_BONE_NAME,
			"type": TYPE_STRING,
			"usage": PROPERTY_USAGE_EDITOR,
		}
		if bone_names:
			bone_name_prop.hint = PROPERTY_HINT_ENUM
			bone_name_prop.hint_string = bone_names
		
		properties[p] = bone_name_prop
		p += 1
		
		# Bone index property
		properties[p] = {
			"name": bm_prefix + _PROP_BONE_IDX,
			"type": TYPE_INT,
			"usage": PROPERTY_USAGE_EDITOR,
			"hint": PROPERTY_HINT_RANGE,
			"hint_string": bone_idx_range
		}
		p += 1
		
		# Transform properties
		var t_prefix := bm_prefix + _TRANSFORM_PREFIX
		var transform_properties := _transforms[m].get_display_property_list(t_prefix)
		for t: Dictionary in transform_properties:
			properties[p] = t
			p += 1
	
	return properties

static func _encode_prop(idx: int, kind: int, key: int) -> int:
	return (idx << 32) | ((key & 0x3FFFFFFF) << 2) | (kind & 0x3)

static func _decode_prop_idx(meta: int) -> int:
	return meta >> 32

static func _decode_prop_kind(meta: int) -> _PropKind:
	return (meta & 0x3) as _PropKind

static func _decode_prop_key(meta: int) -> int:
	return (meta >> 2) & 0x3FFFFFFF

static func _parse_mod_property(property: StringName) -> int:
	const NONE_PROPERTY: int = (0 << 32) | ((0 & 0x3FFFFFFF) << 2) | (_PropKind.NONE & 0x3)
	if not property: return NONE_PROPERTY
	
	var cached: int = _prop_parse_cache.get(property, -1)
	if cached != -1: return cached
	
	var prop_str := String(property)
	if not prop_str.begins_with(_BONE_MOD_PREFIX): return NONE_PROPERTY
	
	var slash := prop_str.find("/")
	if slash == -1: return NONE_PROPERTY
	
	var idx_str := prop_str.substr(_BONE_MOD_PREFIX.length(), slash - _BONE_MOD_PREFIX.length())
	var idx := idx_str.to_int()
	var remainder := prop_str.substr(slash + 1)
	
	var kind := _PropKind.NONE
	var key := 0
	
	if remainder == _PROP_BONE_NAME:
		kind = _PropKind.NAME
	elif remainder == _PROP_BONE_IDX:
		kind = _PropKind.INDEX
	elif remainder.begins_with(_TRANSFORM_PREFIX):
		kind = _PropKind.TRANSFORM
		var key_name := StringName(prop_str.substr(slash + 1 + _TRANSFORM_PREFIX.length()))
		key = Transform3DInterface._DISPLAY_KEYS.find(key_name)
		if key == -1: return NONE_PROPERTY
	else:
		return NONE_PROPERTY
	
	cached = _encode_prop(idx, kind, key)
	_prop_parse_cache[property] = cached
	return cached
#endregion

#region Public API Methods
func set_modifier_count(value: int) -> void:
	var new_count := maxi(0, value)
	if modifier_count == new_count: return
	modifier_count = new_count
	if is_node_ready():
		_resize_modifier_data()
		notify_property_list_changed()

func get_modifier_count() -> int:
	return modifier_count

## Set the bone name for a given entry index.
func set_entry_bone_name(entry_idx: int, bone_name: String) -> void:
	if ((not _entry_idx_valid(entry_idx)) or 
		_bone_names[entry_idx] == bone_name): return
	_bone_names[entry_idx] = bone_name
	_update_bone_idx(entry_idx)

## Get the bone name for a given entry index.
func get_entry_bone_name(entry_idx: int) -> String:
	return _bone_names[entry_idx] if _entry_idx_valid(entry_idx) else ""

## Set the bone index for a given entry index.
func set_entry_bone_index(entry_idx: int, bone_idx: int) -> void:
	if ((not _entry_idx_valid(entry_idx)) or 
		_bone_indices[entry_idx] == bone_idx): return
	var prev := _bone_indices[entry_idx]
	_bone_indices[entry_idx] = bone_idx
	_update_bone_name(entry_idx)
	_on_entry_bone_idx_changed(entry_idx, prev, bone_idx)

## Get the bone index for a given entry index.
func get_entry_bone_index(entry_idx: int) -> int:
	return _bone_indices[entry_idx] if _entry_idx_valid(entry_idx) else -1

## Set the transform for a given entry index.
func set_entry_transform(entry_idx: int, xform: Transform3D) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].transform = xform

## Get the transform for a given entry index.
func get_entry_transform(entry_idx: int) -> Transform3D:
	return _transforms[entry_idx].transform if _xform_idx_valid(entry_idx) else Transform3D.IDENTITY

## Set the position for a given entry index.
func set_entry_position(entry_idx: int, pos: Vector3) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].position = pos

## Get the position for a given entry index.
func get_entry_position(entry_idx: int) -> Vector3:
	return _transforms[entry_idx].position if _xform_idx_valid(entry_idx) else Vector3.ZERO

## Set the rotation (in radians) for a given entry index.
func set_entry_rotation(entry_idx: int, rot: Vector3) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].rotation = rot

## Get the rotation (in radians) for a given entry index.
func get_entry_rotation(entry_idx: int) -> Vector3:
	return _transforms[entry_idx].rotation if _xform_idx_valid(entry_idx) else Vector3.ZERO

## Set the rotation (in degrees) for a given entry index.
func set_entry_rotation_degrees(entry_idx: int, rot_deg: Vector3) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].rotation_degrees = rot_deg

## Get the rotation (in degrees) for a given entry index.
func get_entry_rotation_degrees(entry_idx: int) -> Vector3:
	return _transforms[entry_idx].rotation_degrees if _xform_idx_valid(entry_idx) else Vector3.ZERO

## Set the quaternion rotation for a given entry index.
func set_entry_quaternion(entry_idx: int, quat: Quaternion) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].quaternion = quat

## Get the quaternion rotation for a given entry index.
func get_entry_quaternion(entry_idx: int) -> Quaternion:
	return _transforms[entry_idx].quaternion if _xform_idx_valid(entry_idx) else Quaternion.IDENTITY

## Set the basis for a given entry index.
func set_entry_basis(entry_idx: int, bas: Basis) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].basis = bas

## Get the basis for a given entry index.
func get_entry_basis(entry_idx: int) -> Basis:
	return _transforms[entry_idx].basis if _xform_idx_valid(entry_idx) else Basis.IDENTITY

## Set the scale for a given entry index.
func set_entry_scale(entry_idx: int, scl: Vector3) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].scale = scl

## Get the scale for a given entry index.
func get_entry_scale(entry_idx: int) -> Vector3:
	return _transforms[entry_idx].scale if _xform_idx_valid(entry_idx) else Vector3.ONE

## Set the rotation order for a given entry index.
func set_entry_rotation_order(entry_idx: int, order: EulerOrder) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].rotation_order = order

## Get the rotation order for a given entry index.
func get_entry_rotation_order(entry_idx: int) -> EulerOrder:
	return _transforms[entry_idx].rotation_order if _xform_idx_valid(entry_idx) else EULER_ORDER_YXZ

## Set the rotation edit mode for a given entry index.
func set_entry_rotation_edit_mode(entry_idx: int, mode: Node3D.RotationEditMode) -> void:
	if _xform_idx_valid(entry_idx): _transforms[entry_idx].rotation_edit_mode = mode

## Get the rotation edit mode for a given entry index.
func get_entry_rotation_edit_mode(entry_idx: int) -> Node3D.RotationEditMode:
	return _transforms[entry_idx].rotation_edit_mode if _xform_idx_valid(entry_idx) else Node3D.ROTATION_EDIT_MODE_EULER
#endregion
