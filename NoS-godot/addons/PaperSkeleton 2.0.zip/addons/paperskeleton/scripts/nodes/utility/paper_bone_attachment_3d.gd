@tool
@icon("uid://paperatchico")
extends Node3D
class_name PaperBoneAttachment3D

## This node selects a bone within [PaperSkeleton], and dynamically copies its position.
## This is an imitation of [BoneAttachment3D], but with extra functions meant to
## accomodate for [PaperSkeleton]'s extra features.
## [br][br]
## [b]Note[/b]: There are no plans to recreate [member BoneAttachment3D.override_pose].

#region Constants
## Internal tracker node type used to track [PaperSkeleton] movement updates.
const GenericWatcher3D := preload("uid://paper3wtcgds")
#endregion

#region Configuration Properties
## The name of the bone to attach to in the [PaperSkeleton]
@export var bone_name: String = PaperSkeleton.FLIP_BONE_NAME:
	set = set_bone_name, get = get_bone_name

## The index of the bone in the [PaperSkeleton].
## This value is updated automatically when [member bone_name] changes.
@export var bone_idx: int = -1:
	set = set_bone_idx, get = get_bone_idx

## Inverts the scale on the X axis when detected as flipped instead of rotating.
@export var invert_x_scale_when_flipped: bool = false:
	set = set_invert_x_scale_when_flipped, get = get_invert_x_scale_when_flipped

## When [member PaperSkeleton.billboard_enabled] is set to true, rotates to match.
@export var follow_billboard: bool = true:
	set = set_follow_billboard, get = get_follow_billboard

@export_group("Use External PaperSkeleton")
## When true, uses [member external_paper_skeleton] instead of searching parent hierarchy.
@export_custom(PROPERTY_HINT_GROUP_ENABLE, "")
var use_external_paper_skeleton: bool = false:
	set = set_use_external_paper_skeleton, get = get_use_external_paper_skeleton

## External [PaperSkeleton] reference when [member use_external_paper_skeleton] is enabled.
@export var external_paper_skeleton: PaperSkeleton = null:
	set = set_external_paper_skeleton, get = get_external_paper_skeleton
#endregion

#region Internal References
var _paper_skeleton: PaperSkeleton = null:
	set(value):
		if _paper_skeleton == value: return
		
		if _paper_skeleton:
			_paper_skeleton.skeleton_constructed.disconnect(on_skeleton_updated)
			_paper_skeleton.skeleton_deconstructed.disconnect(on_skeleton_updated)
			_paper_skeleton.skeleton_updated.disconnect(on_skeleton_updated)
			if follow_billboard:
				_paper_skeleton.billboard_update.disconnect(on_skeleton_updated)
				_paper_skeleton.billboard_camera_update.disconnect(on_skeleton_updated)
		
		_paper_skeleton = value
		
		if _paper_skeleton:
			_paper_skeleton.skeleton_constructed.connect(on_skeleton_updated)
			_paper_skeleton.skeleton_deconstructed.connect(on_skeleton_updated)
			_paper_skeleton.skeleton_updated.connect(on_skeleton_updated)
			if follow_billboard:
				_paper_skeleton.billboard_update.connect(on_skeleton_updated)
				_paper_skeleton.billboard_camera_update.connect(on_skeleton_updated)
		
		_update_bone_idx()

var _watcher_3d: GenericWatcher3D
#endregion

#region Lifecycle Methods
func _ready():
	print(get_property_list())
	_find_paper_skeleton()
	_handle_watcher()

## Function that moves the node to the correct position.
func on_skeleton_updated():
	if not is_inside_tree() or not _paper_skeleton or \
	   bone_idx < 0 or bone_idx >= _paper_skeleton.get_bone_count(): return
	
	var base := _paper_skeleton.global_transform
	if follow_billboard and _paper_skeleton.billboard_enabled:
		var mesh_inst_holder := _paper_skeleton._mesh_inst_holder
		if mesh_inst_holder:
			base.basis *= mesh_inst_holder.basis
	
	var bone_pose := _paper_skeleton.get_bone_global_pose(bone_idx)
	if invert_x_scale_when_flipped and _paper_skeleton.is_flipped():
		bone_pose.basis.z = -bone_pose.basis.z
	
	global_transform = base * bone_pose

func _notification(what: int):
	if what == NOTIFICATION_PARENTED:
		if not use_external_paper_skeleton:
			_find_paper_skeleton()
			update_configuration_warnings()
	elif what == NOTIFICATION_ENTER_TREE:
		if is_node_ready():
			_handle_watcher()
			on_skeleton_updated()
	elif what == NOTIFICATION_EXIT_TREE:
		if is_node_ready(): _detach_watcher()
#endregion

#region Skeleton Management
func _on_skeleton_reconstructed() -> void:
	_update_bone_idx()
	update_configuration_warnings()

func _find_paper_skeleton() -> void:
	_paper_skeleton = external_paper_skeleton if use_external_paper_skeleton else _find_parent_skeleton()
	_update_bone_idx()

func _find_parent_skeleton() -> PaperSkeleton:
	var parent := get_parent()
	while parent:
		if parent is PaperSkeleton:
			return parent
		parent = parent.get_parent()
	return null

func _handle_watcher() -> void:
	if use_external_paper_skeleton and external_paper_skeleton:
		if not _watcher_3d:
			_watcher_3d = GenericWatcher3D.new(external_paper_skeleton, false, "_BoneAttachmentWatcher")
			_watcher_3d.transform_update.connect(on_skeleton_updated)
		else:
			_watcher_3d.target = external_paper_skeleton
	else:
		_detach_watcher()

func _detach_watcher() -> void:
	if _watcher_3d:
		if _watcher_3d.transform_update.is_connected(on_skeleton_updated):
			_watcher_3d.transform_update.disconnect(on_skeleton_updated)
		_watcher_3d.queue_free()
		_watcher_3d = null

## Returns the parent or external [PaperSkeleton] node if it exists, otherwise returns `null`.
func get_paper_skeleton() -> PaperSkeleton: return _paper_skeleton
#endregion

#region Bone Management
func _update_bone_idx() -> void:
	if not _paper_skeleton or _paper_skeleton.get_bone_count() == 0:
		bone_idx = -1
		return
	bone_idx = _paper_skeleton.find_bone(bone_name)

func _update_bone_name() -> void:
	if _paper_skeleton and _paper_skeleton and bone_idx != -1:
		bone_name = _paper_skeleton.get_bone_name(bone_idx)
#endregion

#region Setters and Getters
func set_bone_name(value: String) -> void:
	if bone_name == value: return
	bone_name = value
	_update_bone_idx()
	update_configuration_warnings()

func get_bone_name() -> String: return bone_name

func set_bone_idx(value: int) -> void:
	if bone_idx == value: return
	bone_idx = value
	_update_bone_name()
	on_skeleton_updated()
	update_configuration_warnings()

func get_bone_idx() -> int: return bone_idx

func set_invert_x_scale_when_flipped(value: bool) -> void:
	if invert_x_scale_when_flipped == value: return
	invert_x_scale_when_flipped = value
	on_skeleton_updated()

func get_invert_x_scale_when_flipped() -> bool: return invert_x_scale_when_flipped

func set_follow_billboard(value: bool) -> void:
	if follow_billboard == value: return
	follow_billboard = value
	
	if follow_billboard:
		if _paper_skeleton:
			_paper_skeleton.billboard_update.connect(on_skeleton_updated)
			_paper_skeleton.billboard_camera_update.connect(on_skeleton_updated)
	elif _paper_skeleton:
		_paper_skeleton.billboard_update.disconnect(on_skeleton_updated)
		_paper_skeleton.billboard_camera_update.disconnect(on_skeleton_updated)
	
	on_skeleton_updated()

func get_follow_billboard() -> bool: return follow_billboard

func set_use_external_paper_skeleton(value: bool) -> void:
	if use_external_paper_skeleton == value: return
	use_external_paper_skeleton = value
	if is_node_ready():
		_find_paper_skeleton()
		_handle_watcher()
		notify_property_list_changed()
		update_configuration_warnings()

func get_use_external_paper_skeleton() -> bool: return use_external_paper_skeleton

func set_external_paper_skeleton(value: PaperSkeleton) -> void:
	if external_paper_skeleton == value: return
	external_paper_skeleton = value
	if is_node_ready():
		if use_external_paper_skeleton:
			_find_paper_skeleton()
		_handle_watcher()
		notify_property_list_changed()
		update_configuration_warnings()

func get_external_paper_skeleton() -> PaperSkeleton: return external_paper_skeleton
#endregion

#region Editor Integration
func _get_configuration_warnings() -> PackedStringArray:
	const WARN_NO_EXTERNAL := "External PaperSkeleton is not set."
	const WARN_NO_PARENT_SKEL := "No PaperSkeleton found in parent hierarchy."
	const WARN_BONE_UNSET := "Bone name/index is not set."
	const WARN_BONE_MISSING := "Bone '%s' not found in skeleton."
	const WARN_NO_POLY_GROUP := "PaperSkeleton's Skeleton2D hasn't been set."
	
	var warnings := PackedStringArray()
	
	if !_paper_skeleton:
		warnings.append(WARN_NO_EXTERNAL if use_external_paper_skeleton else WARN_NO_PARENT_SKEL)
		return warnings
	
	if !_paper_skeleton.skeleton_2d:
		warnings.append(WARN_NO_POLY_GROUP)
		return warnings
	
	if bone_name.is_empty():
		warnings.append(WARN_BONE_UNSET)
	elif _paper_skeleton.find_bone(bone_name) == -1:
		warnings.append(WARN_BONE_MISSING % bone_name)
	
	return warnings

func _validate_property(property: Dictionary):
	if (property.name as StringName) == &"bone_name":
		if _paper_skeleton:
			property.hint = PROPERTY_HINT_ENUM
			property.hint_string = _paper_skeleton.get_concatenated_bone_names()
#endregion
